#!/bin/bash
# Deploy fixes and restart trading system on Google Cloud VM

set -e

PROJECT="ai-quant-trading"
ZONE="us-central1-a"
VM_NAME="ai-quant-trading-vm"
VM_PATH="/opt/quant_system_clean"

echo "=========================================="
echo "DEPLOYING FIXES TO PRODUCTION"
echo "=========================================="

# Set project
echo "Setting project context..."
gcloud config set project $PROJECT
gcloud config set compute/zone $ZONE

# Copy updated files to VM
echo ""
echo "Copying updated files to VM..."

# Copy main trading system file
echo "  - Copying ai_trading_system.py..."
gcloud compute scp "ai_trading_system.py" $VM_NAME:$VM_PATH/ \
    --zone=$ZONE

# Copy final verification script
echo "  - Copying final_verification.py..."
gcloud compute scp "final_verification.py" $VM_NAME:$VM_PATH/ \
    --zone=$ZONE

# Copy fixed strategy file
echo "  - Copying trade_with_pat_orb_dual.py..."
gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/trade_with_pat_orb_dual.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

# Copy updated registry.py
echo "  - Copying registry.py..."
gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/registry.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

# Copy core order_manager and package markers
echo "  - Copying src/core/order_manager.py and __init__.py..."
gcloud compute scp \
    "src/core/order_manager.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/core/ \
    --zone=$ZONE

echo "  - Copying src/__init__.py and src/core/__init__.py..."
gcloud compute scp \
    "src/__init__.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/ \
    --zone=$ZONE

gcloud compute scp \
    "src/core/__init__.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/core/ \
    --zone=$ZONE

# Copy src/core/data_feed.py
echo "  - Copying src/core/data_feed.py..."
gcloud compute scp \
    "src/core/data_feed.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/core/ \
    --zone=$ZONE

# Copy gold scalping strategy files
echo "  - Copying gold scalping strategies..."
gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/gold_scalping_optimized.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/gold_scalping_topdown.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/gold_scalping_strict1.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

gcloud compute scp \
    "Sync folder MAC TO PC/DESKTOP_HANDOFF_PACKAGE/google-cloud-trading-system/src/strategies/gold_scalping_winrate.py" \
    $VM_NAME:$VM_PATH/google-cloud-trading-system/src/strategies/ \
    --zone=$ZONE

echo ""
echo "Files copied successfully!"

# Restart service
echo ""
echo "Restarting ai_trading.service..."
gcloud compute ssh $VM_NAME --zone=$ZONE --command="
    export PYTHONPATH=$PYTHONPATH:/opt/quant_system_clean/google-cloud-trading-system/
    sudo systemctl restart ai_trading.service
    sleep 2
    sudo systemctl status ai_trading.service --no-pager -l
"

echo ""
echo "=========================================="
echo "DEPLOYMENT COMPLETE"
echo "=========================================="
echo ""
echo "Next: Check logs to verify strategies are loading"
echo "Command: gcloud compute ssh $VM_NAME --zone=$ZONE --command='sudo journalctl -u ai_trading.service -n 50 --no-pager'"



