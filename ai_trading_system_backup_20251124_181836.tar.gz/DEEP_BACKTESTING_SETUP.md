# Deep Backtesting Trading System - Complete Setup Guide

## 🔗 Repository Information

**GitHub Repository:** https://github.com/fxgdesigns1/DEEP_BACKTESTING.git  
**Owner:** fxgdesigns1  
**Email:** fxgdesigns1@gmail.com

---

## 🔐 Sensitive Credentials (PRIVATE - DO NOT COMMIT TO GITHUB)

### Telegram Bot
- **Bot Token:** `7248728383:AAFpLNAlidybk7ed56bosfi8W_e1MaX7Oxs`
- **Chat ID:** `6100678501`

### OANDA API
- Add your OANDA credentials here when needed
- Practice Account:
- Live Account:

### Other APIs
- Marketaux API:
- News API:
- Economic Calendar API:

---

## 💻 Machine Setup Locations

### Windows Machine
- **Workspace Path:** `E:\deep_backtesting_windows1\deep_backtesting`
- **Shell:** PowerShell
- **Python:** Python 3.13+

### MacBook
- **Workspace Path:** `~/Documents/DEEP_BACKTESTING` (or your preferred location)
- **Shell:** Bash/Zsh
- **Python:** Python 3.8+

### Shared Documentation
- **Google Drive Path:** `H:\My Drive\AI Trading\Gits`
- This folder contains sensitive info NOT in GitHub

---

## 🚀 Quick Setup Instructions

### First Time Setup (Any Machine)

#### 1. Clone Repository
```bash
# Navigate to your workspace
cd /path/to/your/workspace

# Clone from GitHub
git clone https://github.com/fxgdesigns1/DEEP_BACKTESTING.git
cd DEEP_BACKTESTING

# Configure git
git config user.email "fxgdesigns1@gmail.com"
git config user.name "fxgdesigns1"
```

#### 2. Create Python Environment

**Windows:**
```powershell
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

**Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

#### 3. Create Configuration Files

```bash
# Copy templates
cp config_templates/config.yaml.template config/config.yaml
cp config_templates/settings.yaml.template config/settings.yaml
```

#### 4. Add Credentials to Config Files

Edit `config/config.yaml` and add:

```yaml
telegram:
  enabled: true
  token: "7248728383:AAFpLNAlidybk7ed56bosfi8W_e1MaX7Oxs"
  chat_id: "6100678501"

oanda:
  api_key: "YOUR_OANDA_API_KEY"
  account_id: "YOUR_ACCOUNT_ID"
  practice: true  # Set to false for live trading
  environment: "practice"

# Add other API credentials as needed
```

#### 5. Create Data Directories

```bash
mkdir -p data/MASTER_DATASET
mkdir -p backtesting_data
mkdir -p results
mkdir -p monte_carlo_results
mkdir -p optimization_results
```

---

## 🔄 Daily Workflow

### Starting Work Session

**Windows:**
```powershell
cd E:\deep_backtesting_windows1\deep_backtesting
.\venv\Scripts\activate
git pull origin main
```

**Mac:**
```bash
cd ~/Documents/DEEP_BACKTESTING
source venv/bin/activate
git pull origin main
```

### Ending Work Session (Commit Changes)

```bash
# Check what changed
git status

# Stage changes (excluding sensitive files - they're in .gitignore)
git add .

# Commit with descriptive message
git commit -m "Description of changes"

# Push to GitHub
git push origin main
```

---

## 📁 Important Files & Directories

### Configuration (LOCAL ONLY - Not in GitHub)
- `config/config.yaml` - Main configuration with credentials
- `config/settings.yaml` - Trading settings and parameters
- `PROFESSIONAL_SYSTEM/CONFIGURATION/config/` - Professional system configs

### Strategies
- `strategies/` - All trading strategies
- `strategies/LATEST_STRATEGY.json` - Current best strategy
- `strategies/ultra_selective_75wr_champion.py` - 75% win rate strategy
- `strategies/prop_firm_challenge_strategy.py` - Prop firm optimized

### Core Systems
- `high_performance_simulation_executor.py` - Main backtesting engine
- `simulation_executor.py` - Standard simulation runner
- `monte_carlo_patterns.py` - Monte Carlo analysis
- `comprehensive_strategy_optimizer.py` - Strategy optimizer

### Data Management
- `download_real_historical_data.py` - Download market data
- `fill_data_gap_real.py` - Fill data gaps
- `data_validation_script.py` - Validate data quality

### Results & Analysis
- `results/` - Backtesting results (LOCAL - not in GitHub)
- `monte_carlo_results/` - Monte Carlo analysis (LOCAL)
- `optimization_results/` - Optimization runs (LOCAL)

---

## 🎯 Common Commands

### Backtesting
```bash
# Quick backtest
python run_comprehensive_backtesting.py

# High performance backtest
python launch_high_performance.py

# Monte Carlo analysis
python monte_carlo_patterns.py

# Strategy optimization
python comprehensive_strategy_optimizer.py
```

### Monitoring
```bash
# Check system status
python check_status.py

# View results
python view_results.py

# Monitor optimization
python monitor_optimizer_progress.py
```

### Data Management
```bash
# Download fresh data
python download_real_historical_data.py

# Fill data gaps
python fill_data_gap_real.py

# Validate data
python data_validation_script.py
```

---

## 🛡️ Security Best Practices

### ✅ Safe to Commit to GitHub
- All `.py` source code files
- Strategy configurations (`.yaml` files in `strategies/`)
- Documentation (`.md` files)
- Requirements files
- Template configurations (in `config_templates/`)

### ❌ NEVER Commit to GitHub (Protected by .gitignore)
- `config/config.yaml` - Contains API keys and tokens
- `config/settings.yaml` - May contain sensitive settings
- `data/` - Large data files
- `results/` - Result files
- `*.log` - Log files
- `*.csv` - Data files
- Personal credentials or tokens

### 🔒 Sensitive Info Storage
- Keep all credentials in this Google Drive document
- Or use environment variables
- Never hardcode credentials in code

---

## 📊 System Capabilities

### Trading Features
- **Paper Trading** with isolated strategy accounts
- **Multiple Timeframes:** 1m, 5m, 15m, 1h, 4h, 1d
- **Instruments:** Forex pairs, Gold (XAU/USD), Futures
- **Risk Management:** Position sizing, stop loss, take profit
- **Win Rate Focus:** Strategies optimized for 70%+ win rates

### Analysis Tools
- **Backtesting:** Historical strategy validation
- **Monte Carlo:** Risk analysis and probability distributions
- **Optimization:** Parameter tuning and strategy improvement
- **Stress Testing:** Market condition resilience testing

### Automation
- **Telegram Alerts:** Trade signals and daily summaries
- **Schedule:** 
  - Morning briefing: 6:00 AM London time
  - End of day summary: 9:30 PM London time
- **Auto-trading:** When enabled (demo accounts only)

---

## 🌍 Timezone Settings

**User Location:** United Kingdom (London time - GMT/BST)

**Key Trading Hours (London Time):**
- Prime time: 1pm-5pm (London/NY overlap)
- London session: 8am-5pm
- Avoid: 10pm-8am (Asian session)

---

## 🔧 Troubleshooting

### Git Issues
```bash
# If you get authentication errors
git config credential.helper store

# If you need to reset to remote version
git fetch origin
git reset --hard origin/main

# If you accidentally committed sensitive files
git rm --cached config/config.yaml
git commit -m "Remove sensitive file"
git push origin main
```

### Python Environment Issues
```bash
# Recreate virtual environment
rm -rf venv
python3 -m venv venv
source venv/bin/activate  # or .\venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### Data Issues
```bash
# Redownload fresh data
python download_real_historical_data.py

# Validate data integrity
python data_validation_script.py
```

---

## 📞 Support & Resources

### Documentation Locations
- GitHub README: https://github.com/fxgdesigns1/DEEP_BACKTESTING
- This Setup Guide: `H:\My Drive\AI Trading\Gits\DEEP_BACKTESTING_SETUP.md`
- In-repo guides: `INSTALLATION_GUIDE.md`, `INTEGRATION_GUIDE.md`, `QUICK_START_GUIDE_OCT2025.md`

### Key Reports
- `GOOD_MORNING_READ_THIS_FIRST.md` - Daily startup guide
- `START_HERE_TRADING_READY.md` - Trading readiness checklist
- `MONTHLY_TRADING_ROADMAP_20251014.md` - Strategy roadmap

---

## 🎯 Current Focus

**System Status:** Production-ready for paper trading  
**Best Strategy:** 75% Win Rate Champion (`ultra_selective_75wr_champion.py`)  
**Next Steps:**
1. Set up on MacBook
2. Build web configuration dashboard
3. Sync data between machines
4. Continue strategy optimization

---

## 📝 Notes for Cursor AI

This trading system is designed for:
- **Paper trading only** (demo accounts)
- **Individual strategy isolation** - no aggregation
- **London timezone** operations
- **High win rate focus** (70%+ target)
- **Risk management** with 10% total portfolio exposure cap
- **Live data only** in trading mode (no simulated data)

All sensitive credentials are stored in this Google Drive document and in local `config/` files that are excluded from GitHub via `.gitignore`.

---

**Last Updated:** October 20, 2025  
**System Version:** Production-ready with Monte Carlo validation  
**Status:** ✅ Active Development

