# Cloud AI Trading System Access Guide

## Purpose
- Maintain and monitor the AI-driven demo trading system running on Google Cloud.
- Ensure demo-only execution with automated strategies, Telegram alerts, and OANDA practice data.
- Provide status updates, risk checks, and manual override capability when needed.

## Google Cloud Access
- **Account:** gavinw442@gmail.com
- **Project:** ai-quant-trading
- **Primary VM:** ai-quant-trading-vm (zone: us-central1-a)
- **External IP:** 35.226.221.66

### Authentication
1. Install Google Cloud SDK.
2. Run `gcloud auth login` using the account above.
3. Set context:
   ```bash
   gcloud config set account gavinw442@gmail.com
   gcloud config set project ai-quant-trading
   gcloud config set compute/zone us-central1-a
   ```

### SSH Connection
```bash
gcloud compute ssh ai-quant-trading-vm --zone=us-central1-a
```
- Default working directory on VM: `/opt/quant_system_clean`

## Trading System Credentials
- **OANDA Practice API Key:** `a3699a9d6b6d94d4e2c4c59748e73e2d-b6cbc64f16bcfb920e40f9117e66111a`
- **Base URL:** `https://api-fxpractice.oanda.com`
- **Account Configuration:** Managed via `/opt/quant_system_clean/google-cloud-trading-system/AI_QUANT_credentials/accounts.yaml`

### Active Accounts (as of Nov 2025)
- `101-004-30719775-005` → All-Weather 70WR Strategy
- `101-004-30719775-006` → GBP/USD Rank #1 Strategy
- `101-004-30719775-007` → Gold Scalping Strategy
- `101-004-30719775-008` → Momentum Trading Strategy (primary)
- `101-004-30719775-009` → GBP/USD Rank #2 Strategy
- `101-004-30719775-010` → GBP/USD Rank #3 Strategy
- `101-004-30719775-011` → Ultra Strict Forex Strategy

## Telegram Alerts
- **Bot Token:** `7248728383:AAFpLNAlidybk7ed56bosfi8W_e1MaX7Oxs`
- **Chat ID:** `6100678501`
- Commands such as `/status`, `/positions`, `/stop_trading`, `/risk 0.01` are supported.
- **Multi-Account Support:** System now manages all 7 accounts simultaneously. `/status` shows primary account; dashboard shows all accounts.

## Services on the VM
- `ai_trading.service` (systemd) runs the multi-account adaptive trading engine.
  - Loads accounts from `accounts.yaml` on startup
  - Processes all active accounts sequentially every 60 seconds
  - Each account runs its assigned strategy with config-specific risk settings
- `automated_trading.service` (backup engine) remains disabled due to config mismatch.

### Operational Checklist
1. Log in via SSH and verify services:
   ```bash
   sudo systemctl status ai_trading.service --no-pager
   ```
2. Check latest journal entries:
   ```bash
   journalctl -u ai_trading.service -n 100 --no-pager
   ```
3. Validate positions for all accounts:
   ```bash
   python3 - <<'PY'
import requests
API_KEY="a3699a9d6b6d94d4e2c4c59748e73e2d-b6cbc64f16bcfb920e40f9117e66111a"
BASE="https://api-fxpractice.oanda.com"
headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
accounts=["101-004-30719775-005","101-004-30719775-006","101-004-30719775-007","101-004-30719775-008","101-004-30719775-009","101-004-30719775-010","101-004-30719775-011"]
for acct in accounts:
    pos = requests.get(f"{BASE}/v3/accounts/{acct}/openPositions", headers=headers, timeout=10).json()
    trades = requests.get(f"{BASE}/v3/accounts/{acct}/openTrades", headers=headers, timeout=10).json()
    print(f"{acct}: {len(pos.get('positions',[]))} positions, {len(trades.get('trades',[]))} trades")
PY
   ```
4. Check multi-account status via dashboard:
   - Web: https://ai-quant-trading.uc.r.appspot.com/api/status
   - Returns JSON with all 7 active accounts and their current status
5. Verify accounts.yaml configuration:
   ```bash
   cat /opt/quant_system_clean/google-cloud-trading-system/AI_QUANT_credentials/accounts.yaml
   ```

## Notes & Restrictions
- Use demo accounts only; no production trading keys on this VM.
- **Multi-Account System:** All 7 accounts are managed by a single `ai_trading.service` instance.
- Risk per trade is configured per-account in `accounts.yaml` (typically 0.4-0.7% per account).
- Each account runs its assigned strategy independently with account-specific risk settings.
- All changes to system capacity or risk must be logged per user policy.
- Keep Playwright-based UI tests on Chromium/Firefox only.
- **Dashboard:** App Engine dashboard at https://ai-quant-trading.uc.r.appspot.com shows all 7 accounts in real-time.

