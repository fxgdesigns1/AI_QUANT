#!/usr/bin/env python3
"""
Monitoring script: alert if strategies generated signals but no trades executed
Designed to run on the VM (reads journalctl) and send Telegram alerts.
"""
import subprocess
import os
import requests
from datetime import datetime, timedelta

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "7248728383:AAFpLNAlidybk7ed56bosfi8W_e1MaX7Oxs")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "6100678501")

LOOKBACK_MINUTES = int(os.getenv("MONITOR_LOOKBACK_MIN", "10"))
SIGNAL_THRESHOLD = int(os.getenv("MONITOR_SIGNAL_THRESHOLD", "1"))

def run_journalctl(since_minutes: int) -> str:
    since = (datetime.utcnow() - timedelta(minutes=since_minutes)).strftime("%Y-%m-%d %H:%M:%S")
    cmd = f"sudo journalctl -u ai_trading.service --since '{since}' --no-pager"
    try:
        out = subprocess.check_output(cmd, shell=True, text=True, timeout=15)
        return out
    except Exception as e:
        return ""

def send_telegram(text: str):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {'chat_id': TELEGRAM_CHAT_ID, 'text': text}
        requests.post(url, data=data, timeout=10)
    except Exception:
        pass

def analyze_logs(log_text: str):
    # Map strategy -> (signals_count, executed_count)
    stats = {}
    for line in log_text.splitlines():
        if "generated" in line and "signals" in line:
            # extract strategy name
            try:
                # e.g. "Strategy 'gold_scalping_topdown' (analyze_market) generated 3 trading signals"
                parts = line.split("Strategy '")
                if len(parts) > 1:
                    rest = parts[1]
                    name = rest.split("'")[0]
                    n = 0
                    import re
                    m = re.search(r'generated (\d+)', line)
                    if m:
                        n = int(m.group(1))
                    s,e = stats.get(name, (0,0))
                    stats[name] = (s + n, e)
            except Exception:
                continue
        if "TRADE EXECUTED" in line or "✅ TRADE EXECUTED" in line or "Trades Executed:" in line:
            # Try to attribute to strategy via nearby 'Strategy:' or account logs; fallback to global
            # Simple increment global executed for now
            # If line contains Order ID mapping we ignore per-strategy attribution
            for name in list(stats.keys()):
                s,e = stats.get(name,(0,0))
                stats[name] = (s, e+1)
    return stats

def main():
    logs = run_journalctl(LOOKBACK_MINUTES)
    if not logs:
        return
    stats = analyze_logs(logs)
    alerts = []
    for strat, (signals, executed) in stats.items():
        if signals >= SIGNAL_THRESHOLD and executed == 0:
            alerts.append(f"⚠️ Strategy `{strat}` generated {signals} signal(s) in last {LOOKBACK_MINUTES}m but executed 0 trades.")
    if alerts:
        body = "ALERT - Execution Mismatch\n\n" + "\n".join(alerts) + f"\n\nTime: {datetime.utcnow().isoformat()} UTC"
        send_telegram(body)

if __name__ == '__main__':
    main()


