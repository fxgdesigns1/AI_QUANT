from typing import Any, Dict

def safe_news_integration(*args: Any, **kwargs: Any) -> Dict[str, Any]:
    """
    News integration layer wired to the intelligent cache.
    Attempts to fetch latest articles and a cached sentiment score.
    Falls back gracefully to None if caching is unavailable.
    """
    try:
        # Import locally to avoid import-time dependency if cache module is unused elsewhere
        from .news_cache import fetch_latest_articles, fetch_sentiment

        articles = fetch_latest_articles(limit=20, max_age_hours=48)
        sentiment = fetch_sentiment(window_minutes=60)
        return {
            "articles": articles,
            "sentiment": sentiment
        }
    except Exception:
        # If anything goes wrong, gracefully indicate unavailability
        return {"articles": [], "sentiment": 0.0}
