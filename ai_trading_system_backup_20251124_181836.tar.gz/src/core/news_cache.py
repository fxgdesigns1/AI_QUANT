import json
import os
import time
from typing import Any, Dict, List, Optional

# Runtime cache path (relative to repo root)
CACHE_PATH = os.path.join("runtime", "news_articles_cache.json")
DEFAULT_CACHE_DAYS = int(os.getenv("NEWS_CACHE_DAYS", "7"))
MIN_API_INTERVAL_SECONDS = int(os.getenv("NEWS_MIN_API_INTERVAL_SECONDS", "300"))

# API credentials (readonly approach: keys are loaded via env vars at runtime)
MARKETAUX_KEYS = os.getenv("MARKETAUX_KEYS", "")
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")


def _load_cache() -> Dict[str, Any]:
    if not os.path.exists(CACHE_PATH):
        return {"articles": [], "last_fetch": 0}
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Corrupted cache; start fresh
        return {"articles": [], "last_fetch": 0}


def _save_cache(cache: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def _should_fetch(last_fetch_timestamp: float) -> bool:
    if not last_fetch_timestamp:
        return True
    return (time.time() - last_fetch_timestamp) > MIN_API_INTERVAL_SECONDS


def _deduplicate_articles(existing: List[Dict[str, Any]], new_articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    existing_ids = {a.get("id") for a in existing}
    merged = list(existing)
    for art in new_articles:
        if art.get("id") not in existing_ids:
            merged.append(art)
            existing_ids.add(art.get("id"))
    return merged


def _fetch_from_marketaux(after_iso: Optional[str] = None) -> List[Dict[str, Any]]:
    # Placeholder: integrate with real Marketaux API using provided keys
    if not MARKETAUX_KEYS:
        return []
    # Attempt a simple HTTP fetch if requests is available
    try:
        import requests  # type: ignore
        headers = {"Authorization": f"Bearer {MARKETAUX_KEYS.split(',')[0].strip()}"}
        url = "https://api.marketaux.com/v1/news/latest"
        params = {"published_after": after_iso} if after_iso else {}
        resp = requests.get(url, headers=headers, params=params, timeout=10)
        if resp.ok:
            data = resp.json()
            # Normalize to a simple article dict with required fields
            articles = []
            for item in data.get("news", []) if isinstance(data, dict) else []:
                articles.append({
                    "id": str(item.get("id") or item.get("url")),
                    "title": item.get("title"),
                    "published_at": item.get("published_at"),
                    "source": item.get("source"),
                    "sentiment": item.get("sentiment", 0.0),
                    "url": item.get("url"),
                })
            return articles
    except Exception:
        pass
    return []


def _fetch_from_news_api(after_iso: Optional[str] = None) -> List[Dict[str, Any]]:
    # Placeholder: integrate with News API using NEWS_API_KEY
    if not NEWS_API_KEY:
        return []
    try:
        import requests  # type: ignore
        url = "https://newsapi.org/v2/everything"
        headers = {"Authorization": f"Bearer {NEWS_API_KEY}"}  # sometimes API uses header key
        params = {"q": "forex OR fx", "pageSize": 20}
        if after_iso:
            params["from"] = after_iso
        resp = requests.get(url, headers=headers, params=params, timeout=10)
        if resp.ok:
            data = resp.json()
            articles = []
            for a in data.get("articles", []):
                articles.append({
                    "id": a.get("url"),
                    "title": a.get("title"),
                    "published_at": a.get("publishedAt"),
                    "source": a.get("source", {}).get("name"),
                    "sentiment": a.get("sentiment", 0.0),
                    "url": a.get("url"),
                })
            return articles
    except Exception:
        pass
    return []


def fetch_latest_articles(limit: int = 20, max_age_hours: int = 48) -> List[Dict[str, Any]]:
    """
    Return latest articles from cache, fetching from sources only when needed.
    """
    cache = _load_cache()
    articles: List[Dict[str, Any]] = cache.get("articles", [])
    last_fetch = cache.get("last_fetch", 0)

    # If cache is empty or stale, try incremental fetch
    after = articles[-1]["published_at"] if articles else None
    need_api = _should_fetch(last_fetch) or (len(articles) < limit)

    new_articles: List[Dict[str, Any]] = []
    if need_api:
        new_articles = _fetch_from_marketaux(after)
        # Merge with existing
        articles = _deduplicate_articles(articles, new_articles)
        if len(articles) < limit:
            more = _fetch_from_news_api(after)
            articles = _deduplicate_articles(articles, more)

        # Persist cache
        cache["articles"] = articles[-(max(len(articles), limit)):]  # keep at least 'limit'
        cache["last_fetch"] = time.time()
        _save_cache(cache)

    # Respect max_age_hours by pruning old articles (simple approach)
    cutoff = time.time() - max_age_hours * 3600
    pruned = [a for a in articles if a.get("published_at") is None or to_timestamp(a.get("published_at")) >= cutoff]
    cache["articles"] = pruned
    _save_cache(cache)
    return pruned[-limit:]


def fetch_sentiment(window_minutes: int = 60) -> float:
    cache = _load_cache()
    articles = cache.get("articles", [])
    if not articles:
        return 0.0
    # Simple placeholder sentiment average from cached data
    total = 0.0
    count = 0
    for a in articles:
        total += float(a.get("sentiment", 0.0) or 0.0)
        count += 1
    return total / max(1, count)


def to_timestamp(dt_str: Optional[str]) -> float:
    """Convert ISO-like date string to epoch seconds; best-effort."""
    if not dt_str:
        return 0.0
    # Try common ISO formats
    from datetime import datetime
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(dt_str, fmt)
            return dt.timestamp()
        except Exception:
            continue
    return 0.0




