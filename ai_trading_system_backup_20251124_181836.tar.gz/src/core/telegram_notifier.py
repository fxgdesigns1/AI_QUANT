"""
Minimal Telegram notifier shim.
Provides the interface expected by core modules without external dependencies.
"""
from typing import Optional
import logging


logger = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, token: Optional[str] = None, chat_id: Optional[str] = None):
        self.token = token
        self.chat_id = chat_id

    def send_message(self, text: str) -> None:
        logger.info(f"[TelegramShim] {text}")


_singleton: Optional[TelegramNotifier] = None


def get_telegram_notifier() -> TelegramNotifier:
    global _singleton
    if _singleton is None:
        _singleton = TelegramNotifier()
    return _singleton


__all__ = ["TelegramNotifier", "get_telegram_notifier"]




