# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - 'heading "Error: Server Error" [level=1] [ref=e2]'
  - heading "The server encountered an error and could not complete your request. Please try again in 30 seconds." [level=2] [ref=e3]:
    - text: The server encountered an error and could not complete your request.
    - paragraph [ref=e4]: Please try again in 30 seconds.
  - heading [level=2]
```