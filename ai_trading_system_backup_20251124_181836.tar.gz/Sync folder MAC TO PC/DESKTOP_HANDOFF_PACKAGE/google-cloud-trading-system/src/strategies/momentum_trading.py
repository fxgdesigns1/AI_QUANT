#!/usr/bin/env python3
"""
Momentum Trading Strategy
Production-ready momentum trading strategy for Google Cloud deployment
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd

from ..core.order_manager import TradeSignal, OrderSide, get_order_manager
from ..core.data_feed import MarketData, get_data_feed

# News integration (optional, non-breaking)
try:
    from ..core.news_integration import safe_news_integration
    NEWS_AVAILABLE = True
except ImportError:
    NEWS_AVAILABLE = False

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class MomentumSignal:
    """Momentum trading signal"""
    instrument: str
    trend: str  # 'BULLISH', 'BEARISH', 'NEUTRAL'
    momentum_score: float  # -1 to 1
    volume_score: float  # 0 to 1
    strength: float  # 0 to 1
    timestamp: datetime
    atr: float  # Average True Range
    adx: float  # Average Directional Index

class MomentumTradingStrategy:
    """Production Momentum Trading Strategy"""
    
    def __init__(self):
        """Initialize strategy"""
        self.name = "Momentum Trading"
        # SCALED UP: Added JPY pairs (USD_JPY was the big winner!)
        self.instruments = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD', 'USD_CAD', 'NZD_USD', 
                           'EUR_JPY', 'GBP_JPY', 'AUD_JPY']
        
        # Strategy parameters - OPTIMIZED FOR HIGH-QUALITY MOMENTUM TRADES
        self.momentum_period = 14  # Period for momentum calculations
        self.volume_period = 20  # Period for volume analysis
        self.atr_period = 14  # Period for ATR calculation
        self.adx_period = 14  # Period for ADX calculation
        self.min_adx = 20  # STRONG TRENDS ONLY - quality filter
        self.min_momentum = 0.30  # SIGNIFICANT MOMENTUM REQUIRED
        self.min_volume = 0.25  # GOOD VOLUME CONFIRMATION
        self.stop_loss_atr = 1.5  # Stop loss in ATR units - reasonable room
        self.take_profit_atr = 5.0  # Take profit = 1:3.33 R:R (IMPROVED)
        self.max_trades_per_day = 60  # QUALITY focus
        self.min_trades_today = 0  # NO FORCED TRADES - only strong signals
        
        # Data storage
        self.price_history: Dict[str, List[float]] = {inst: [] for inst in self.instruments}
        self.volume_history: Dict[str, List[float]] = {inst: [] for inst in self.instruments}
        self.atr_history: Dict[str, List[float]] = {inst: [] for inst in self.instruments}
        
        # Performance tracking
        self.daily_trade_count = 0
        self.last_reset_date = datetime.now().date()
        
        # Per-instrument overrides
        self.per_instrument_overrides: Dict[str, Dict[str, float]] = {}
        
        # Relax ADX slightly as per live findings
        try:
            self.min_adx = min(self.min_adx, 15)
        except Exception:
            pass
        
        # News integration for momentum confirmation
        self.news_enabled = NEWS_AVAILABLE and safe_news_integration.enabled if NEWS_AVAILABLE else False
        if self.news_enabled:
            logger.info("✅ News integration enabled - confirming momentum with sentiment")
        else:
            logger.info("ℹ️  Trading without news integration (technical signals only)")
        
        logger.info(f"✅ {self.name} strategy initialized")
        logger.info(f"📊 Instruments: {self.instruments}")
        logger.info(f"📊 Parameters: ADX > {self.min_adx}, Momentum > {self.min_momentum}")
    
    @property
    def daily_trades(self):
        """Get daily trade count"""
        return self.daily_trade_count
    
    def _reset_daily_counters(self):
        """Reset daily counters if new day"""
        current_date = datetime.now().date()
        if current_date != self.last_reset_date:
            self.daily_trade_count = 0
            self.last_reset_date = current_date
            logger.info("🔄 Daily trade counters reset")
    
    def _calculate_atr(self, highs: List[float], lows: List[float], closes: List[float]) -> float:
        """Calculate Average True Range"""
        if len(highs) < self.atr_period + 1:
            return 0.0
        
        tr_list = []
        for i in range(1, len(highs)):
            hl = highs[i] - lows[i]
            hc = abs(highs[i] - closes[i-1])
            lc = abs(lows[i] - closes[i-1])
            tr = max(hl, hc, lc)
            tr_list.append(tr)
        
        return float(pd.Series(tr_list).rolling(window=self.atr_period).mean().iloc[-1])
    
    def _calculate_adx(self, highs: List[float], lows: List[float], closes: List[float]) -> float:
        """Calculate Average Directional Index"""
        if len(highs) < self.adx_period + 1:
            return 0.0
        
        # Calculate +DM and -DM
        plus_dm = []
        minus_dm = []
        
        for i in range(1, len(highs)):
            h_diff = highs[i] - highs[i-1]
            l_diff = lows[i-1] - lows[i]
            
            if h_diff > l_diff and h_diff > 0:
                plus_dm.append(h_diff)
            else:
                plus_dm.append(0)
            
            if l_diff > h_diff and l_diff > 0:
                minus_dm.append(l_diff)
            else:
                minus_dm.append(0)
        
        # Calculate TR
        tr_list = []
        for i in range(1, len(highs)):
            hl = highs[i] - lows[i]
            hc = abs(highs[i] - closes[i-1])
            lc = abs(lows[i] - closes[i-1])
            tr = max(hl, hc, lc)
            tr_list.append(tr)
        
        # Calculate smoothed averages
        tr_series = pd.Series(tr_list).rolling(window=self.adx_period).mean()
        plus_di = pd.Series(plus_dm).rolling(window=self.adx_period).mean() / tr_series * 100
        minus_di = pd.Series(minus_dm).rolling(window=self.adx_period).mean() / tr_series * 100
        
        # Calculate ADX
        dx = abs(plus_di - minus_di) / (plus_di + minus_di) * 100
        adx = dx.rolling(window=self.adx_period).mean()
        
        return float(adx.iloc[-1])
    
    def _calculate_momentum_score(self, prices: List[float]) -> float:
        """Calculate momentum score"""
        if len(prices) < self.momentum_period:
            return 0.0
        
        returns = pd.Series(prices).pct_change(periods=self.momentum_period)
        momentum = returns.iloc[-1]
        
        # Normalize to -1 to 1 range
        return max(min(momentum * 100, 1.0), -1.0)
    
    def _calculate_volume_score(self, volumes: List[float]) -> float:
        """Calculate volume score"""
        if len(volumes) < self.volume_period:
            return 0.0
        
        recent_volume = np.mean(volumes[-5:])  # Last 5 periods
        average_volume = np.mean(volumes[-self.volume_period:])  # Full period
        
        # Calculate volume ratio and normalize
        volume_ratio = recent_volume / average_volume if average_volume > 0 else 0
        return min(volume_ratio, 1.0)
    
    def _update_price_history(self, market_data: Dict[str, MarketData]):
        """Update price and volume history"""
        for instrument, data in market_data.items():
            if instrument in self.instruments:
                # Store mid price
                mid_price = (data.bid + data.ask) / 2
                self.price_history[instrument].append(mid_price)
                
                # Simulate volume (spread-based)
                volume = 1 / (data.ask - data.bid) if data.ask > data.bid else 0
                self.volume_history[instrument].append(volume)
                
                # Keep only necessary history
                max_length = max(self.momentum_period, self.volume_period, self.atr_period, self.adx_period) + 10
                if len(self.price_history[instrument]) > max_length:
                    self.price_history[instrument] = self.price_history[instrument][-max_length:]
                    self.volume_history[instrument] = self.volume_history[instrument][-max_length:]
    
    def _generate_momentum_signals(self, market_data: Dict[str, MarketData]) -> Dict[str, MomentumSignal]:
        """Generate momentum signals"""
        signals = {}
        
        for instrument in self.instruments:
            if instrument not in market_data or len(self.price_history[instrument]) < self.momentum_period:
                continue
            
            prices = self.price_history[instrument]
            volumes = self.volume_history[instrument]
            
            # Calculate technical indicators
            momentum_score = self._calculate_momentum_score(prices)
            volume_score = self._calculate_volume_score(volumes)
            
            # Calculate ATR and ADX
            highs = [p * (1 + 0.0001) for p in prices]  # Simulate high prices
            lows = [p * (1 - 0.0001) for p in prices]   # Simulate low prices
            atr = self._calculate_atr(highs, lows, prices)
            adx = self._calculate_adx(highs, lows, prices)
            
            # Determine trend
            trend = 'NEUTRAL'
            # Apply per-instrument overrides for thresholds when available
            min_mom = self.min_momentum
            min_adx = self.min_adx
            if instrument in self.per_instrument_overrides:
                o = self.per_instrument_overrides[instrument]
                min_mom = float(o.get('min_momentum', min_mom))
                min_adx = float(o.get('min_adx', min_adx))
            if momentum_score > min_mom and adx > min_adx:
                trend = 'BULLISH'
            elif momentum_score < -min_mom and adx > min_adx:
                trend = 'BEARISH'
            
            # Calculate overall signal strength
            strength = min(1.0, (abs(momentum_score) + volume_score + (adx/100)) / 3)
            
            signals[instrument] = MomentumSignal(
                instrument=instrument,
                trend=trend,
                momentum_score=momentum_score,
                volume_score=volume_score,
                strength=strength,
                timestamp=datetime.now(),
                atr=atr,
                adx=adx
            )
        
        return signals
    
    def _generate_trade_signals(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Generate trading signals based on momentum strategy - FORCE TRADES TODAY"""
        self._reset_daily_counters()
        
        # Check daily trade limit
        if self.daily_trade_count >= self.max_trades_per_day:
            return []
        
        # Update price history
        self._update_price_history(market_data)
        
        # Generate momentum signals
        momentum_signals = self._generate_momentum_signals(market_data)
        
        trade_signals = []
        
        # FORCE TRADES IF WE HAVEN'T HIT MINIMUM TODAY
        force_trade = self.daily_trade_count < self.min_trades_today
        
        for instrument, signal in momentum_signals.items():
            # Resolve per-instrument risk overrides
            sl_atr = self.stop_loss_atr
            tp_atr = self.take_profit_atr
            min_vol = self.min_volume
            min_mom = self.min_momentum
            if instrument in self.per_instrument_overrides:
                o = self.per_instrument_overrides[instrument]
                sl_atr = float(o.get('stop_loss_atr', sl_atr))
                tp_atr = float(o.get('take_profit_atr', tp_atr))
                min_vol = float(o.get('min_volume', min_vol))
                min_mom = float(o.get('min_momentum', min_mom))
            # If forcing trades, be more lenient with conditions
            if force_trade:
                # Force a trade with relaxed conditions
                if len(self.price_history[instrument]) > 3:
                    current_price = (market_data[instrument].bid + market_data[instrument].ask) / 2
                    
                    # Force a BUY trade
                    stop_loss = current_price * 0.995  # 0.5% stop loss
                    take_profit = current_price * 1.015  # 1.5% take profit = 1:3.0 R:R
                    
                    trade_signal = TradeSignal(
                        instrument=instrument,
                        side=OrderSide.BUY,
                        units=50000,  # 0.5 lots - OPTIMIZED (was too large)
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        strategy_name=self.name,
                        confidence=0.7  # Set confidence for forced trade
                    )
                    
                    trade_signals.append(trade_signal)
                    self.daily_trade_count += 1
                    logger.info(f"🚀 FORCING TRADE: {instrument} BUY (trade #{self.daily_trade_count})")
                    continue
            
            # Skip if signal strength is too low (unless forcing)
            if not force_trade and (signal.strength < min_mom or signal.volume_score < min_vol):
                logger.info(
                    f"⛔ {self.name} reject {instrument}: strength {signal.strength:.2f} < {min_mom:.2f} or volume {signal.volume_score:.2f} < {min_vol:.2f}"
                )
                continue
            
            if signal.trend in ['BULLISH', 'BEARISH']:
                current_price = (market_data[instrument].bid + market_data[instrument].ask) / 2
                
                # Calculate stop loss and take profit using ATR
                if signal.trend == 'BULLISH':
                    stop_loss = current_price - (signal.atr * sl_atr)
                    take_profit = current_price + (signal.atr * tp_atr)
                    side = OrderSide.BUY
                else:
                    stop_loss = current_price + (signal.atr * sl_atr)
                    take_profit = current_price - (signal.atr * tp_atr)
                    side = OrderSide.SELL
                
                    # SCALED UP: Increase position size for proven winner
                    position_size = 150000 if instrument.endswith('JPY') else 100000
                    
                    trade_signal = TradeSignal(
                        instrument=instrument,
                        side=side,
                        units=position_size,  # 1.5 lots for JPY pairs (they're winners!)
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        strategy_name=self.name,
                        confidence=signal.strength
                    )
                
                trade_signals.append(trade_signal)
                self.daily_trade_count += 1
                logger.info(f"✅ {self.name} generated {signal.trend} signal for {instrument} (confidence: {signal.strength:.2f})")
        
        # MOMENTUM ENHANCEMENT: News sentiment confirms trend direction
        if self.news_enabled and NEWS_AVAILABLE and trade_signals:
            try:
                # Check for high-impact conflicting news
                if safe_news_integration.should_pause_trading(self.instruments):
                    logger.warning("🚫 Momentum trading paused - conflicting high-impact news")
                    return []
                
                # Boost momentum signals that align with news sentiment
                news_analysis = safe_news_integration.get_news_analysis(self.instruments)
                
                for signal in trade_signals:
                    boost = safe_news_integration.get_news_boost_factor(
                        signal.side.value,
                        [signal.instrument]
                    )
                    
                    original_confidence = signal.confidence
                    signal.confidence = original_confidence * boost
                    
                    # Extra boost if momentum + news align strongly
                    if abs(news_analysis.get('overall_sentiment', 0)) > 0.3:
                        if ((signal.side.value == 'BUY' and news_analysis['overall_sentiment'] > 0) or
                            (signal.side.value == 'SELL' and news_analysis['overall_sentiment'] < 0)):
                            signal.confidence *= 1.05  # Small additional boost for alignment
                            logger.info(f"🎯 Strong momentum+news alignment: "
                                      f"{signal.instrument} {signal.side.value}")
                    
                    if boost != 1.0:
                        logger.info(f"📰 Momentum news check: {original_confidence:.2f} → "
                                  f"{signal.confidence:.2f}")
                
            except Exception as e:
                logger.warning(f"⚠️  News integration error: {e}")
        
        return trade_signals
    
    def analyze_market(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Analyze market and generate trading signals"""
        try:
            signals = self._generate_trade_signals(market_data)
            
            if signals:
                logger.info(f"🎯 {self.name} generated {len(signals)} signals")
                for signal in signals:
                    logger.info(f"   📈 {signal.instrument} {signal.side.value} - Confidence: {signal.confidence:.2f}")
            
            return signals
            
        except Exception as e:
            logger.error(f"❌ {self.name} analysis error: {e}")
            return []
    
    def get_strategy_status(self) -> Dict:
        """Get current strategy status"""
        self._reset_daily_counters()
        
        return {
            'name': self.name,
            'instruments': self.instruments,
            'daily_trades': self.daily_trade_count,
            'max_daily_trades': self.max_trades_per_day,
            'trades_remaining': self.max_trades_per_day - self.daily_trade_count,
            'parameters': {
                'momentum_period': self.momentum_period,
                'volume_period': self.volume_period,
                'atr_period': self.atr_period,
                'adx_period': self.adx_period,
                'min_adx': self.min_adx,
                'min_momentum': self.min_momentum,
                'min_volume': self.min_volume,
                'stop_loss_atr': self.stop_loss_atr,
                'take_profit_atr': self.take_profit_atr
            },
            'last_update': datetime.now().isoformat()
        }

# Global strategy instance
momentum_trading = MomentumTradingStrategy()

def get_momentum_trading_strategy() -> MomentumTradingStrategy:
    """Get the global Momentum Trading strategy instance"""
    return momentum_trading

def set_momentum_per_instrument_overrides(mapping: Dict[str, Dict[str, float]]) -> None:
    """Helper to set overrides on the global instance."""
    try:
        momentum_trading.set_per_instrument_overrides(mapping)  # type: ignore[attr-defined]
    except AttributeError:
        momentum_trading.per_instrument_overrides = mapping  # fallback
        logger.info(f"✅ Set momentum per-instrument overrides ({len(mapping)})")

# Instance method added dynamically for compatibility
def _set_per_instrument_overrides(self, mapping: Dict[str, Dict[str, float]]) -> None:
    self.per_instrument_overrides = mapping or {}
    logger.info(f"✅ {self.name} overrides updated for {len(self.per_instrument_overrides)} instruments")

# Attach method if missing
if not hasattr(momentum_trading, 'set_per_instrument_overrides'):
    setattr(MomentumTradingStrategy, 'set_per_instrument_overrides', _set_per_instrument_overrides)
