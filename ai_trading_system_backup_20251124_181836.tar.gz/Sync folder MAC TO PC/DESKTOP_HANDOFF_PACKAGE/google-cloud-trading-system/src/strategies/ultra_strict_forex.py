#!/usr/bin/env python3
"""
Ultra Strict Forex Trading Strategy
Production-ready high-precision forex trading with strict risk controls
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd

from ..core.order_manager import TradeSignal, OrderSide, get_order_manager
from ..core.data_feed import MarketData, get_data_feed

# News integration (optional, non-breaking)
try:
    from ..core.news_integration import safe_news_integration
    NEWS_AVAILABLE = True
except ImportError:
    NEWS_AVAILABLE = False

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class EMASignal:
    """EMA crossover signal"""
    instrument: str
    ema_3: float
    ema_8: float
    ema_21: float
    signal: str  # 'BUY', 'SELL', 'HOLD'
    strength: float  # 0-1
    timestamp: datetime

@dataclass
class MomentumSignal:
    """Momentum confirmation signal"""
    instrument: str
    rsi: float
    macd: float
    macd_signal: float
    momentum: str  # 'BULLISH', 'BEARISH', 'NEUTRAL'
    strength: float  # 0-1
    timestamp: datetime

class UltraStrictForexStrategy:
    """Production Ultra Strict Forex Trading Strategy"""
    
    def __init__(self):
        """Initialize strategy"""
        self.name = "Ultra Strict Forex"
        self.instruments = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD']
        
        # Strategy parameters - OPTIMIZED WITH MULTI-TIMEFRAME CONFIRMATION
        self.ema_periods = [3, 8, 21]
        self.stop_loss_pct = 0.005  # 0.5% stop loss
        self.take_profit_pct = 0.020  # 2.0% take profit = 1:4.0 R:R (IMPROVED)
        self.min_signal_strength = 0.70  # VERY HIGH - only best setups
        self.max_trades_per_day = 25  # QUALITY over quantity (reduced further)
        self.min_trades_today = 0  # NO FORCED TRADES - only high-quality setups
        # Multi-timeframe confirmation
        self.require_trend_alignment = True  # Must align with higher TF
        self.trend_lookback_long = 50  # Look back 50 bars for trend
        self.trend_lookback_short = 20  # Look back 20 bars for short trend
        
        # Data storage
        self.price_history: Dict[str, List[float]] = {inst: [] for inst in self.instruments}
        self.ema_history: Dict[str, Dict[int, List[float]]] = {
            inst: {period: [] for period in self.ema_periods} for inst in self.instruments
        }
        self.signals: List[TradeSignal] = []
        
        # Performance tracking
        self.daily_trade_count = 0
        self.last_reset_date = datetime.now().date()
        
        # Per-instrument overrides
        self.per_instrument_overrides: Dict[str, Dict[str, float]] = {}
        
        # News integration (optional, non-breaking)
        self.news_enabled = NEWS_AVAILABLE and safe_news_integration.enabled if NEWS_AVAILABLE else False
        if self.news_enabled:
            logger.info("✅ News integration enabled for quality filtering")
        else:
            logger.info("ℹ️  Trading without news integration (technical signals only)")
        
        logger.info(f"✅ {self.name} strategy initialized")
        logger.info(f"📊 Instruments: {self.instruments}")
        logger.info(f"📊 EMA periods: {self.ema_periods}")
        logger.info(f"📊 Stop loss: {self.stop_loss_pct*100:.1f}%, Take profit: {self.take_profit_pct*100:.1f}%")
    
    @property
    def daily_trades(self):
        """Get daily trade count"""
        return self.daily_trade_count
    
    def _reset_daily_counters(self):
        """Reset daily counters if new day"""
        current_date = datetime.now().date()
        if current_date != self.last_reset_date:
            self.daily_trade_count = 0
            self.last_reset_date = current_date
            logger.info("🔄 Daily trade counters reset")
    
    def _calculate_ema(self, prices: List[float], period: int) -> float:
        """Calculate Exponential Moving Average"""
        if len(prices) < period:
            return prices[-1] if prices else 0.0
        
        # Use pandas for EMA calculation
        series = pd.Series(prices)
        ema = series.ewm(span=period, adjust=False).mean()
        return float(ema.iloc[-1])
    
    def _calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """Calculate Relative Strength Index"""
        if len(prices) < period + 1:
            return 50.0  # Neutral RSI
        
        series = pd.Series(prices)
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return float(rsi.iloc[-1])
    
    def _calculate_macd(self, prices: List[float]) -> Tuple[float, float]:
        """Calculate MACD and signal line"""
        if len(prices) < 26:
            return 0.0, 0.0
        
        series = pd.Series(prices)
        ema_12 = series.ewm(span=12, adjust=False).mean()
        ema_26 = series.ewm(span=26, adjust=False).mean()
        macd = ema_12 - ema_26
        signal = macd.ewm(span=9, adjust=False).mean()
        
        return float(macd.iloc[-1]), float(signal.iloc[-1])
    
    def _check_higher_timeframe_trend(self, prices: List[float], signal_direction: str) -> bool:
        """Check if higher timeframe supports the trade direction (CRITICAL)"""
        if not self.require_trend_alignment:
            return True
        
        if len(prices) < self.trend_lookback_long:
            return False
        
        try:
            # Calculate long-term trend (simulating 1H/4H on 15min data)
            long_term_ema = self._calculate_ema(prices, self.trend_lookback_long)
            short_term_ema = self._calculate_ema(prices, self.trend_lookback_short)
            current_price = prices[-1]
            
            # Determine higher TF trend
            if current_price > long_term_ema and short_term_ema > long_term_ema:
                higher_tf_trend = 'BUY'
            elif current_price < long_term_ema and short_term_ema < long_term_ema:
                higher_tf_trend = 'SELL'
            else:
                higher_tf_trend = 'NEUTRAL'
            
            # Signal must align with higher TF
            if signal_direction == higher_tf_trend:
                logger.info(f"✅ Multi-timeframe alignment confirmed: {signal_direction}")
                return True
            else:
                logger.info(f"⏰ Multi-timeframe conflict: Signal={signal_direction}, HTF={higher_tf_trend}")
                return False
                
        except Exception as e:
            logger.warning(f"⚠️ Multi-timeframe check failed: {e}")
            return False
    
    def _update_price_history(self, market_data: Dict[str, MarketData]):
        """Update price history for all instruments"""
        for instrument, data in market_data.items():
            if instrument in self.instruments:
                # Use mid price (average of bid and ask)
                mid_price = (data.bid + data.ask) / 2
                self.price_history[instrument].append(mid_price)
                
                # Keep only last 100 prices for efficiency
                if len(self.price_history[instrument]) > 100:
                    self.price_history[instrument] = self.price_history[instrument][-100:]
    
    def _calculate_ema_signals(self) -> Dict[str, EMASignal]:
        """Calculate EMA crossover signals"""
        ema_signals = {}
        
        for instrument in self.instruments:
            if len(self.price_history[instrument]) < 8:  # Reduced from 21 to 8
                continue
            
            prices = self.price_history[instrument]
            
            # Calculate EMAs
            ema_3 = self._calculate_ema(prices, 3)
            ema_8 = self._calculate_ema(prices, 8)
            ema_21 = self._calculate_ema(prices, 21)
            
            # Determine signal
            signal = 'HOLD'
            strength = 0.0
            
            # Bullish: EMA 3 > EMA 8 > EMA 21
            if ema_3 > ema_8 > ema_21:
                signal = 'BUY'
                # Calculate strength based on separation
                strength = min(1.0, (ema_3 - ema_21) / ema_21 * 1000)
            
            # Bearish: EMA 3 < EMA 8 < EMA 21
            elif ema_3 < ema_8 < ema_21:
                signal = 'SELL'
                # Calculate strength based on separation
                strength = min(1.0, (ema_21 - ema_3) / ema_21 * 1000)
            
            ema_signals[instrument] = EMASignal(
                instrument=instrument,
                ema_3=ema_3,
                ema_8=ema_8,
                ema_21=ema_21,
                signal=signal,
                strength=strength,
                timestamp=datetime.now()
            )
        
        return ema_signals
    
    def _calculate_momentum_signals(self) -> Dict[str, MomentumSignal]:
        """Calculate momentum confirmation signals"""
        momentum_signals = {}
        
        for instrument in self.instruments:
            if len(self.price_history[instrument]) < 10:  # Reduced from 26 to 10
                continue
            
            prices = self.price_history[instrument]
            
            # Calculate RSI
            rsi = self._calculate_rsi(prices)
            
            # Calculate MACD
            macd, macd_signal = self._calculate_macd(prices)
            
            # Determine momentum
            momentum = 'NEUTRAL'
            strength = 0.0
            
            # Bullish momentum: RSI > 50, MACD > Signal
            if rsi > 50 and macd > macd_signal:
                momentum = 'BULLISH'
                strength = min(1.0, (rsi - 50) / 50 + (macd - macd_signal) / abs(macd_signal) if macd_signal != 0 else 0)
            
            # Bearish momentum: RSI < 50, MACD < Signal
            elif rsi < 50 and macd < macd_signal:
                momentum = 'BEARISH'
                strength = min(1.0, (50 - rsi) / 50 + (macd_signal - macd) / abs(macd_signal) if macd_signal != 0 else 0)
            
            momentum_signals[instrument] = MomentumSignal(
                instrument=instrument,
                rsi=rsi,
                macd=macd,
                macd_signal=macd_signal,
                momentum=momentum,
                strength=strength,
                timestamp=datetime.now()
            )
        
        return momentum_signals
    
    def _generate_trade_signals(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Generate trading signals based on strategy logic - FORCE TRADES TODAY"""
        self._reset_daily_counters()
        
        # Check daily trade limit
        if self.daily_trade_count >= self.max_trades_per_day:
            return []
        
        # Update price history
        self._update_price_history(market_data)
        
        # Calculate signals
        ema_signals = self._calculate_ema_signals()
        momentum_signals = self._calculate_momentum_signals()
        
        trade_signals = []
        
        # FORCE TRADES IF WE HAVEN'T HIT MINIMUM TODAY
        force_trade = self.daily_trade_count < self.min_trades_today
        
        for instrument in self.instruments:
            # If forcing trades, skip signal validation and force trades directly
            if force_trade:
                # Force a BUY trade if we have enough data (reduced from 3 to 2)
                if len(self.price_history[instrument]) > 2:
                    if instrument in market_data:
                        current_price = market_data[instrument].ask
                        sl_pct = self.stop_loss_pct
                        tp_pct = self.take_profit_pct
                        if instrument in self.per_instrument_overrides:
                            o = self.per_instrument_overrides[instrument]
                            sl_pct = float(o.get('stop_loss_pct', sl_pct))
                            tp_pct = float(o.get('take_profit_pct', tp_pct))
                        stop_loss = current_price * (1 - sl_pct)
                        take_profit = current_price * (1 + tp_pct)
                        
                        signal = TradeSignal(
                            instrument=instrument,
                            side=OrderSide.BUY,
                            units=100000,  # 1.0 lots for $500 risk (demo limit)
                            stop_loss=stop_loss,
                            take_profit=take_profit,
                            strategy_name=self.name,
                            confidence=0.7  # Set confidence for forced trade
                        )
                        
                        trade_signals.append(signal)
                        self.daily_trade_count += 1
                        logger.info(f"🚀 FORCING TRADE: {instrument} BUY (trade #{self.daily_trade_count})")
                        continue
                
                # Force a SELL trade if we have enough data (reduced from 4 to 2)
                elif len(self.price_history[instrument]) > 2:
                    if instrument in market_data:
                        current_price = market_data[instrument].bid
                        sl_pct = self.stop_loss_pct
                        tp_pct = self.take_profit_pct
                        if instrument in self.per_instrument_overrides:
                            o = self.per_instrument_overrides[instrument]
                            sl_pct = float(o.get('stop_loss_pct', sl_pct))
                            tp_pct = float(o.get('take_profit_pct', tp_pct))
                        stop_loss = current_price * (1 + sl_pct)
                        take_profit = current_price * (1 - tp_pct)
                        
                        signal = TradeSignal(
                            instrument=instrument,
                            side=OrderSide.SELL,
                            units=100000,  # 1.0 lots for $500 risk (demo limit)
                            stop_loss=stop_loss,
                            take_profit=take_profit,
                            strategy_name=self.name,
                            confidence=0.7  # Set confidence for forced trade
                        )
                        
                        trade_signals.append(signal)
                        self.daily_trade_count += 1
                        logger.info(f"🚀 FORCING TRADE: {instrument} SELL (trade #{self.daily_trade_count})")
                        continue
            
            # Normal signal processing (only if not forcing trades)
            if instrument not in ema_signals or instrument not in momentum_signals:
                continue
            
            ema_signal = ema_signals[instrument]
            momentum_signal = momentum_signals[instrument]
            
            # Normal signal generation (if not forcing) - LOOSENED REQUIREMENTS
            # Check if signals align and meet strength requirements
            # Apply per-instrument min strength override
            min_strength = self.min_signal_strength
            if instrument in self.per_instrument_overrides:
                o = self.per_instrument_overrides[instrument]
                min_strength = float(o.get('min_signal_strength', min_strength))
            
            # IMPROVED: Require EMA + momentum + MULTI-TIMEFRAME alignment
            if (ema_signal.signal == 'BUY' and ema_signal.strength >= min_strength and
                (momentum_signal.momentum == 'BULLISH' or momentum_signal.momentum == 'NEUTRAL')):
                
                # ENTRY IMPROVEMENT: Check multi-timeframe alignment
                if not self._check_higher_timeframe_trend(self.price_history[instrument], 'BUY'):
                    logger.info(f"⏰ Skipping {instrument} BUY: Higher TF not aligned")
                    continue
                
                # Get current price for stop loss and take profit calculation
                if instrument in market_data:
                    current_price = market_data[instrument].ask  # Use ask for buy orders
                    sl_pct = self.stop_loss_pct
                    tp_pct = self.take_profit_pct
                    if instrument in self.per_instrument_overrides:
                        o = self.per_instrument_overrides[instrument]
                        sl_pct = float(o.get('stop_loss_pct', sl_pct))
                        tp_pct = float(o.get('take_profit_pct', tp_pct))
                    stop_loss = current_price * (1 - sl_pct)
                    take_profit = current_price * (1 + tp_pct)
                    
                    signal = TradeSignal(
                        instrument=instrument,
                        side=OrderSide.BUY,
                        units=100000,  # 1.0 lots for $500 risk (demo limit)
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        strategy_name=self.name,
                        confidence=max(ema_signal.strength, 0.5)  # Use EMA strength or minimum 0.5
                    )
                    
                    trade_signals.append(signal)
                    self.daily_trade_count += 1
                    logger.info(f"✅ {self.name} generated BUY signal for {instrument} (confidence: {signal.confidence:.2f})")
            
            # IMPROVED: Require EMA + momentum + MULTI-TIMEFRAME alignment
            elif (ema_signal.signal == 'SELL' and ema_signal.strength >= min_strength and
                  (momentum_signal.momentum == 'BEARISH' or momentum_signal.momentum == 'NEUTRAL')):
                
                # ENTRY IMPROVEMENT: Check multi-timeframe alignment
                if not self._check_higher_timeframe_trend(self.price_history[instrument], 'SELL'):
                    logger.info(f"⏰ Skipping {instrument} SELL: Higher TF not aligned")
                    continue
                
                # Get current price for stop loss and take profit calculation
                if instrument in market_data:
                    current_price = market_data[instrument].bid  # Use bid for sell orders
                    sl_pct = self.stop_loss_pct
                    tp_pct = self.take_profit_pct
                    if instrument in self.per_instrument_overrides:
                        o = self.per_instrument_overrides[instrument]
                        sl_pct = float(o.get('stop_loss_pct', sl_pct))
                        tp_pct = float(o.get('take_profit_pct', tp_pct))
                    stop_loss = current_price * (1 + sl_pct)
                    take_profit = current_price * (1 - tp_pct)
                    
                    signal = TradeSignal(
                        instrument=instrument,
                        side=OrderSide.SELL,
                        units=100000,  # 1.0 lots for $500 risk (demo limit)
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        strategy_name=self.name,
                        confidence=max(ema_signal.strength, 0.5)  # Use EMA strength or minimum 0.5
                    )
                    
                    trade_signals.append(signal)
                    self.daily_trade_count += 1
                    logger.info(f"✅ {self.name} generated SELL signal for {instrument} (confidence: {signal.confidence:.2f})")
        
        # QUALITY ENHANCEMENT: News-aware signal filtering
        if self.news_enabled and NEWS_AVAILABLE and trade_signals:
            try:
                # Check if high-impact negative news should pause trading
                if safe_news_integration.should_pause_trading(self.instruments):
                    logger.warning("🚫 Trading paused due to high-impact negative news")
                    return []
                
                # Apply news sentiment boost/reduction to signals
                news_analysis = safe_news_integration.get_news_analysis(self.instruments)
                
                for signal in trade_signals:
                    # Get news boost factor for this signal
                    boost = safe_news_integration.get_news_boost_factor(
                        signal.side.value, 
                        [signal.instrument]
                    )
                    
                    # Adjust confidence with news sentiment
                    original_confidence = signal.confidence
                    signal.confidence = original_confidence * boost
                    
                    if boost != 1.0:
                        logger.info(f"📰 News adjustment for {signal.instrument}: "
                                  f"{original_confidence:.2f} → {signal.confidence:.2f} "
                                  f"(sentiment: {news_analysis.get('overall_sentiment', 0):.2f})")
                
            except Exception as e:
                logger.warning(f"⚠️  News integration error (continuing without news): {e}")
        
        return trade_signals
    
    def analyze_market(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Analyze market and generate trading signals"""
        try:
            signals = self._generate_trade_signals(market_data)
            
            if signals:
                logger.info(f"🎯 {self.name} generated {len(signals)} signals")
                for signal in signals:
                    logger.info(f"   📈 {signal.instrument} {signal.side.value} - Confidence: {signal.confidence:.2f}")
            
            return signals
            
        except Exception as e:
            logger.error(f"❌ {self.name} analysis error: {e}")
            return []
    
    def get_strategy_status(self) -> Dict:
        """Get current strategy status"""
        self._reset_daily_counters()
        
        return {
            'name': self.name,
            'instruments': self.instruments,
            'daily_trades': self.daily_trade_count,
            'max_daily_trades': self.max_trades_per_day,
            'trades_remaining': self.max_trades_per_day - self.daily_trade_count,
            'parameters': {
                'ema_periods': self.ema_periods,
                'stop_loss_pct': self.stop_loss_pct,
                'take_profit_pct': self.take_profit_pct,
                'min_signal_strength': self.min_signal_strength
            },
            'last_update': datetime.now().isoformat()
        }

# Global strategy instance
ultra_strict_forex = UltraStrictForexStrategy()

def get_ultra_strict_forex_strategy() -> UltraStrictForexStrategy:
    """Get the global Ultra Strict Forex strategy instance"""
    return ultra_strict_forex

# Instance method for overrides
def _set_per_instrument_overrides(self, mapping: Dict[str, Dict[str, float]]) -> None:
    self.per_instrument_overrides = mapping or {}
    logger.info(f"✅ {self.name} overrides updated for {len(self.per_instrument_overrides)} instruments")

if not hasattr(UltraStrictForexStrategy, 'set_per_instrument_overrides'):
    setattr(UltraStrictForexStrategy, 'set_per_instrument_overrides', _set_per_instrument_overrides)
