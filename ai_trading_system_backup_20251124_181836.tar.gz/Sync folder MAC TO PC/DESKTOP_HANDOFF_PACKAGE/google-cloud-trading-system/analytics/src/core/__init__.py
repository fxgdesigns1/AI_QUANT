# Core trading system components
