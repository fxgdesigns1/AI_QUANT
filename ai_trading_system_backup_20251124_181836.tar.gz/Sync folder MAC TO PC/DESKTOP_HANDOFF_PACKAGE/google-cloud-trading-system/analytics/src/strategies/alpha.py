#!/usr/bin/env python3
"""
Alpha Entry Strategy (EMA Crossover + Momentum Confirmation)
Demo-focused entry generator for the STRATEGY_ALPHA account.
"""

import logging
from datetime import datetime
from typing import Dict, List
from dataclasses import dataclass

import numpy as np

from ..core.order_manager import TradeSignal, OrderSide
from ..core.data_feed import MarketData


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class AlphaSignal:
    instrument: str
    direction: str  # 'LONG' | 'SHORT' | 'FLAT'
    strength: float  # 0-1
    timestamp: datetime
    ema_fast: float
    ema_mid: float
    ema_slow: float
    momentum: float


class AlphaStrategy:
    """EMA(3,8,21) crossover with simple momentum confirmation.

    Risk template (demo):
    - Stop loss: 0.20%
    - Take profit: 0.30%
    - Max daily trades: 50
    - Instruments: majors + CAD, NZD
    """

    def __init__(self):
        self.name = "Alpha EMA"
        self.instruments = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD', 'USD_CAD', 'NZD_USD']

        # Parameters
        self.ema_fast_period = 3
        self.ema_mid_period = 8
        self.ema_slow_period = 21
        self.momentum_period = 10
        self.sl_pct = 0.002  # 0.20%
        self.tp_pct = 0.003  # 0.30%
        self.max_trades_per_day = 50
        self.min_trades_today = 2

        # State
        self.price_history: Dict[str, List[float]] = {i: [] for i in self.instruments}
        self.daily_trade_count = 0
        self.last_date = datetime.now().date()

        logger.info(f"✅ {self.name} initialized | instruments: {self.instruments}")

    def _reset_daily(self):
        d = datetime.now().date()
        if d != self.last_date:
            self.daily_trade_count = 0
            self.last_date = d
            logger.info("🔄 Alpha strategy daily counters reset")

    def _ema(self, values: List[float], period: int) -> float:
        if len(values) < period:
            return float(values[-1]) if values else 0.0
        weights = np.exp(np.linspace(-1.0, 0.0, period))
        weights /= weights.sum()
        window = np.array(values[-period:])
        return float(np.dot(window, weights))

    def _momentum(self, values: List[float], period: int) -> float:
        if len(values) <= period:
            return 0.0
        old = values[-period]
        new = values[-1]
        if old == 0:
            return 0.0
        return (new - old) / old

    def _update_prices(self, market_data: Dict[str, MarketData]):
        for inst, data in market_data.items():
            if inst in self.instruments:
                mid = (data.bid + data.ask) / 2.0
                self.price_history[inst].append(mid)
                if len(self.price_history[inst]) > 200:
                    self.price_history[inst] = self.price_history[inst][-200:]

    def _generate_alpha_signals(self, market_data: Dict[str, MarketData]) -> Dict[str, AlphaSignal]:
        signals: Dict[str, AlphaSignal] = {}
        for inst in self.instruments:
            if inst not in market_data:
                continue
            prices = self.price_history[inst]
            if len(prices) < max(self.ema_slow_period, self.momentum_period) + 2:
                # Fallback: force one immediate entry on EUR_USD when starting up
                if inst == 'EUR_USD' and self.daily_trade_count == 0:
                    md = market_data[inst]
                    mid = (md.bid + md.ask) / 2.0
                    ema_fast = mid
                    ema_mid = mid
                    ema_slow = mid
                    mom = 0.0
                    signals[inst] = AlphaSignal(
                        instrument=inst,
                        direction='LONG',
                        strength=0.6,
                        timestamp=datetime.now(),
                        ema_fast=ema_fast,
                        ema_mid=ema_mid,
                        ema_slow=ema_slow,
                        momentum=mom,
                    )
                continue

            ema_fast = self._ema(prices, self.ema_fast_period)
            ema_mid = self._ema(prices, self.ema_mid_period)
            ema_slow = self._ema(prices, self.ema_slow_period)
            mom = self._momentum(prices, self.momentum_period)

            direction = 'FLAT'
            strength = 0.0

            # Bullish: fast > mid > slow and positive momentum
            if ema_fast > ema_mid > ema_slow and mom > 0:
                direction = 'LONG'
                # Scale strength with slope and momentum
                slope = (ema_fast - ema_mid) / ema_mid if ema_mid else 0
                strength = min(1.0, max(0.0, slope * 100 + mom * 50))
            # Bearish: fast < mid < slow and negative momentum
            elif ema_fast < ema_mid < ema_slow and mom < 0:
                direction = 'SHORT'
                slope = (ema_mid - ema_fast) / ema_mid if ema_mid else 0
                strength = min(1.0, max(0.0, slope * 100 + abs(mom) * 50))

            signals[inst] = AlphaSignal(
                instrument=inst,
                direction=direction,
                strength=strength,
                timestamp=datetime.now(),
                ema_fast=ema_fast,
                ema_mid=ema_mid,
                ema_slow=ema_slow,
                momentum=mom,
            )
        return signals

    def analyze_market(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        self._reset_daily()
        if self.daily_trade_count >= self.max_trades_per_day:
            return []

        self._update_prices(market_data)
        alpha_signals = self._generate_alpha_signals(market_data)
        trade_signals: List[TradeSignal] = []

        for inst, sig in alpha_signals.items():
            if sig.direction not in ('LONG', 'SHORT'):
                continue

            # Basic risk template sizing; exact units are refined by OrderManager
            side = OrderSide.BUY if sig.direction == 'LONG' else OrderSide.SELL
            # Use mid price from market_data
            md = market_data[inst]
            mid = (md.bid + md.ask) / 2.0
            if mid <= 0:
                continue

            stop_loss = mid * (1 - self.sl_pct) if side == OrderSide.BUY else mid * (1 + self.sl_pct)
            take_profit = mid * (1 + self.tp_pct) if side == OrderSide.BUY else mid * (1 - self.tp_pct)

            trade_signals.append(TradeSignal(
                instrument=inst,
                side=side,
                units=10000,
                stop_loss=stop_loss,
                take_profit=take_profit,
                strategy_name=self.name,
                confidence=min(1.0, max(0.5, sig.strength)),
            ))
            self.daily_trade_count += 1
            logger.info(f"✅ {self.name}: {inst} {sig.direction} signal | ema({sig.ema_fast:.5f},{sig.ema_mid:.5f},{sig.ema_slow:.5f}) mom={sig.momentum:.4f}")

        return trade_signals

    def get_strategy_status(self) -> Dict:
        self._reset_daily()
        return {
            'name': self.name,
            'instruments': self.instruments,
            'daily_trades': self.daily_trade_count,
            'max_daily_trades': self.max_trades_per_day,
            'params': {
                'ema_fast': self.ema_fast_period,
                'ema_mid': self.ema_mid_period,
                'ema_slow': self.ema_slow_period,
                'momentum_period': self.momentum_period,
                'sl_pct': self.sl_pct,
                'tp_pct': self.tp_pct,
            },
            'last_update': datetime.now().isoformat(),
        }


# Global instance and getter
alpha_strategy = AlphaStrategy()

def get_alpha_strategy() -> AlphaStrategy:
    return alpha_strategy


