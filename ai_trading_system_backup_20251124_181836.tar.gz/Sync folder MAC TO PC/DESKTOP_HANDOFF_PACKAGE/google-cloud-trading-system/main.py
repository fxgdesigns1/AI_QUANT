#!/usr/bin/env python3
"""
Google Cloud Trading System - Main Entry Point - FULLY INTEGRATED VERSION
Production-ready entry point with complete dashboard, WebSocket, and AI integration
"""

import os
import sys
import logging
import json
import time
import threading
import asyncio
from datetime import datetime, timedelta
import uuid
from flask import Flask, jsonify, request, render_template
from flask_socketio import SocketIO, emit
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict

# Add src to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize dashboard manager with proper error handling
dashboard_manager = None
try:
    logger.info("🔄 Initializing dashboard manager...")
    from src.dashboard.advanced_dashboard import AdvancedDashboardManager
    dashboard_manager = AdvancedDashboardManager()
    logger.info("✅ Dashboard manager initialized successfully")
except Exception as e:
    logger.error(f"❌ Failed to initialize dashboard manager: {e}")
    logger.exception("Full traceback:")
    dashboard_manager = None

# Initialize news integration
news_integration = None
try:
    logger.info("🔄 Initializing news integration...")
    from src.core.news_integration import safe_news_integration
    news_integration = safe_news_integration
    logger.info("✅ News integration initialized successfully")
except Exception as e:
    logger.error(f"❌ Failed to initialize news integration: {e}")
    logger.exception("Full traceback:")
    news_integration = None

# Initialize AI Assistant
ai_assistant = None
try:
    logger.info("🔄 Initializing AI assistant...")
    from src.dashboard.ai_assistant_api import AIAssistantAPI
    ai_assistant = AIAssistantAPI()
    logger.info("✅ AI assistant initialized successfully")
except Exception as e:
    logger.error(f"❌ Failed to initialize AI assistant: {e}")
    logger.exception("Full traceback:")
    ai_assistant = None

# Create Flask app with correct template directory
template_dir = os.path.join(os.path.dirname(__file__), 'src', 'templates')
app = Flask(__name__, template_folder=template_dir)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'your-secret-key-here')

# Initialize SocketIO with proper configuration for Google Cloud
socketio = SocketIO(app, 
                   cors_allowed_origins="*", 
                   async_mode='threading',
                   logger=False,
                   engineio_logger=False,
                   ping_timeout=60,
                   ping_interval=25)

# In-memory action store (short-lived, for confirmations)
_PENDING_ACTIONS: Dict[str, Dict[str, Any]] = {}

def _bounded(value: float, min_v: float, max_v: float) -> float:
    return max(min_v, min(max_v, value))

def _notify_telegram(text: str) -> None:
    try:
        notifier = getattr(app.config, 'TELEGRAM_NOTIFIER', None) or app.config.get('TELEGRAM_NOTIFIER')
        if notifier and hasattr(notifier, 'send_message'):
            notifier.send_message(text)
    except Exception:
        logger.warning("Telegram notifier unavailable")

@app.route('/')
def home():
    """Home route"""
    return jsonify({
        "status": "running",
        "message": "Trading system is active with corrected configurations",
        "dashboard_manager": "initialized" if dashboard_manager else "failed",
        "corrected_params": {
            "max_portfolio_risk": 0.75,
            "min_confidence_threshold": 0.5,
            "strategy_mappings": "corrected",
            "account_assignments": "aligned"
        }
    })

@app.route('/dashboard')
def dashboard():
    """Dashboard route - serves the trading dashboard"""
    try:
        if dashboard_manager:
            return render_template('dashboard_advanced.html')
        else:
            return jsonify({
                "error": "Dashboard manager not initialized",
                "message": "Please check system logs",
                "redirect": "/api/status"
            }), 503
    except Exception as e:
        logger.error(f"❌ Dashboard route error: {e}")
        return jsonify({
            "error": "Dashboard unavailable", 
            "message": str(e)
        }), 500

@app.route('/insights')
def insights_dashboard():
    """Visual insights dashboard"""
    try:
        return render_template('insights_dashboard.html')
    except Exception as e:
        logger.error(f"❌ Insights dashboard error: {e}")
        return jsonify({
            "error": "Insights dashboard unavailable",
            "message": str(e)
        }), 500

@app.route('/status')
def status_dashboard():
    """Visual status dashboard"""
    try:
        return render_template('status_dashboard.html')
    except Exception as e:
        logger.error(f"❌ Status dashboard error: {e}")
        return jsonify({
            "error": "Status dashboard unavailable",
            "message": str(e)
        }), 500

@app.route('/api/status')
def status():
    """Status route"""
    if dashboard_manager:
        try:
            system_status = dashboard_manager.get_system_status()
            return jsonify(system_status)
        except Exception as e:
            logger.error(f"❌ Failed to get system status: {e}")
            return jsonify({
                "status": "error",
                "error": str(e),
                "timestamp": str(datetime.now())
            })
    else:
        return jsonify({
            "status": "error",
            "message": "Dashboard manager not initialized",
            "timestamp": str(datetime.now())
        })

@app.route('/api/overview')
def overview():
    """Account overview route"""
    if dashboard_manager:
        try:
            overview = dashboard_manager.get_account_overview()
            return jsonify(overview)
        except Exception as e:
            logger.error(f"❌ Failed to get account overview: {e}")
            return jsonify({
                "status": "error",
                "error": str(e),
                "timestamp": str(datetime.now())
            })
    else:
        return jsonify({
            "status": "error",
            "message": "Dashboard manager not initialized",
            "timestamp": str(datetime.now())
        })

@app.route('/api/accounts')
def api_accounts():
    """Return live account statuses (read-only)."""
    try:
        status_payload = dashboard_manager.get_system_status() if dashboard_manager else {}
        return jsonify({
            'status': 'success',
            'accounts': status_payload.get('account_statuses', {}),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"❌ Accounts endpoint error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/risk')
def api_risk():
    """Return aggregated risk metrics (read-only)."""
    try:
        metrics = dashboard_manager.get_risk_metrics() if dashboard_manager else {}
        return jsonify({'status': 'success', 'risk': metrics, 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Risk endpoint error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/metrics')
def api_metrics():
    """Return trading performance metrics (read-only)."""
    try:
        status_payload = dashboard_manager.get_system_status() if dashboard_manager else {}
        return jsonify({'status': 'success', 'metrics': status_payload.get('trading_metrics', {}), 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Metrics endpoint error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/signals/recent')
def api_signals_recent():
    """Return recent signals if available (read-only fallback)."""
    try:
        # If manager exposes recent signals, return; else return empty list gracefully
        recent = []
        try:
            if hasattr(dashboard_manager, 'get_recent_signals'):
                recent = dashboard_manager.get_recent_signals() or []
        except Exception as ie:
            logger.warning(f"Signals accessor not available: {ie}")
        return jsonify({'status': 'success', 'signals': recent, 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Recent signals endpoint error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/positions')
def api_positions():
    """Return open positions if available (read-only fallback)."""
    try:
        positions = {}
        if dashboard_manager and hasattr(dashboard_manager, 'active_accounts') and hasattr(dashboard_manager, 'account_manager'):
            for account_id in dashboard_manager.active_accounts:
                try:
                    if hasattr(dashboard_manager.account_manager, 'get_open_positions'):
                        positions[account_id] = dashboard_manager.account_manager.get_open_positions(account_id) or []
                    else:
                        positions[account_id] = []
                except Exception as ie:
                    logger.warning(f"Positions fetch failed for {account_id}: {ie}")
                    positions[account_id] = []
        return jsonify({'status': 'success', 'positions': positions, 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Positions endpoint error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/logs')
def api_logs():
    """Return a basic health log note (App Engine logs are external).
    This endpoint confirms service health without exposing App Engine logs.
    """
    try:
        return jsonify({
            'status': 'success',
            'note': 'For detailed logs, use gcloud app logs tail -s default. Service health OK.',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500

# =============== SECURE ACTION ENDPOINTS (CONFIRMATION REQUIRED) ===============

@app.route('/actions/strategy', methods=['POST'])
def action_strategy():
    """Request strategy control (pause/resume/start/stop). Confirmation required."""
    payload = request.get_json(silent=True) or {}
    action = payload.get('action')
    target = payload.get('target', 'all')
    if action not in ['pause', 'resume', 'start', 'stop']:
        return jsonify({'status': 'error', 'error': 'invalid action'}), 400
    # Build preview
    preview = {
        'action': action,
        'target': target,
        'effect': f'{action} requested on {target}'
    }
    action_id = str(uuid.uuid4())
    _PENDING_ACTIONS[action_id] = {
        'type': 'strategy',
        'payload': payload,
        'created_at': datetime.now().isoformat()
    }
    return jsonify({'status': 'pending', 'confirm_required': True, 'action_id': action_id, 'preview': preview})

@app.route('/actions/risk', methods=['POST'])
def action_risk():
    """Request bounded risk parameter changes. Confirmation required."""
    payload = request.get_json(silent=True) or {}
    account_id = payload.get('account_id')
    changes = payload.get('changes', {})
    if not account_id:
        return jsonify({'status': 'error', 'error': 'account_id required'}), 400
    # Bound deltas
    bounded = {}
    if 'max_risk_per_trade' in changes:
        bounded['max_risk_per_trade'] = _bounded(float(changes['max_risk_per_trade']), 0.0, 0.05)
    if 'max_positions' in changes:
        bounded['max_positions'] = int(_bounded(int(changes['max_positions']), 1, 10))
    if 'daily_trade_limit' in changes:
        bounded['daily_trade_limit'] = int(_bounded(int(changes['daily_trade_limit']), 1, 200))
    if 'max_portfolio_risk' in changes:
        bounded['max_portfolio_risk'] = _bounded(float(changes['max_portfolio_risk']), 0.1, 0.9)
    preview = {'account_id': account_id, 'changes': bounded}
    action_id = str(uuid.uuid4())
    _PENDING_ACTIONS[action_id] = {
        'type': 'risk',
        'payload': {'account_id': account_id, 'changes': bounded},
        'created_at': datetime.now().isoformat()
    }
    return jsonify({'status': 'pending', 'confirm_required': True, 'action_id': action_id, 'preview': preview})

@app.route('/actions/orders', methods=['POST'])
def action_orders():
    """Request order/position actions (e.g., close positions by filter). Confirmation required."""
    payload = request.get_json(silent=True) or {}
    op = payload.get('op')
    if op not in ['close_positions', 'cancel_orders']:
        return jsonify({'status': 'error', 'error': 'invalid op'}), 400
    preview = {'op': op, 'filter': payload.get('filter', {})}
    action_id = str(uuid.uuid4())
    _PENDING_ACTIONS[action_id] = {
        'type': 'orders',
        'payload': payload,
        'created_at': datetime.now().isoformat()
    }
    return jsonify({'status': 'pending', 'confirm_required': True, 'action_id': action_id, 'preview': preview})

@app.route('/actions/confirm', methods=['POST'])
def action_confirm():
    """Confirm and execute a pending action with guardrails and alerts."""
    data = request.get_json(silent=True) or {}
    action_id = data.get('action_id')
    if not action_id or action_id not in _PENDING_ACTIONS:
        return jsonify({'status': 'error', 'error': 'invalid action_id'}), 400
    entry = _PENDING_ACTIONS.pop(action_id)
    a_type = entry['type']
    payload = entry['payload']
    # Default to dry-run off only if explicitly allowed via env
    live_allowed = os.getenv('ALLOW_LIVE_ACTIONS', 'false').lower() == 'true'
    executed = False
    details = {}
    try:
        if not live_allowed:
            details = {'note': 'Live actions disabled. Set ALLOW_LIVE_ACTIONS=true to enable.'}
        else:
            if a_type == 'strategy' and dashboard_manager:
                # Best-effort: pause/resume by toggling a kill switch if available
                action = payload.get('action')
                target = payload.get('target', 'all')
                # Expose a simple flag on app for global pause
                if action == 'pause':
                    app.config['GLOBAL_TRADING_PAUSED'] = True
                elif action in ['resume', 'start']:
                    app.config['GLOBAL_TRADING_PAUSED'] = False
                # stop == pause for safety
                executed = True
                details = {'result': 'strategy state set', 'paused': app.config.get('GLOBAL_TRADING_PAUSED', False), 'target': target}
            elif a_type == 'risk' and dashboard_manager and hasattr(dashboard_manager, 'order_manager'):
                # Update per-account OrderManager limits in-place (bounded earlier)
                om = dashboard_manager.order_manager
                acct = payload.get('account_id')
                changes = payload.get('changes', {})
                per_mgr = om.get_order_manager(acct) if hasattr(om, 'get_order_manager') else None
                if not per_mgr:
                    raise RuntimeError(f'No order manager for {acct}')
                for key, val in changes.items():
                    if hasattr(per_mgr, key):
                        setattr(per_mgr, key, type(getattr(per_mgr, key))(val))
                executed = True
                details = {'result': 'order manager limits updated', 'account_id': acct, 'applied': changes}
            elif a_type == 'orders' and dashboard_manager and hasattr(dashboard_manager, 'order_manager'):
                om = dashboard_manager.order_manager
                op = payload.get('op')
                flt = payload.get('filter', {})
                effected = []
                # Close positions by instrument and optional account
                if op == 'close_positions':
                    instrument = flt.get('instrument')
                    target_acct = flt.get('account_id')
                    accounts = [target_acct] if target_acct else list(getattr(dashboard_manager, 'active_accounts', []))
                    for acct in accounts:
                        try:
                            if instrument and hasattr(om, 'close_position'):
                                ok = om.close_position(acct, instrument, reason='AI assistant manual close')
                                effected.append({'account_id': acct, 'instrument': instrument, 'closed': ok})
                        except Exception as ce:
                            effected.append({'account_id': acct, 'instrument': instrument, 'error': str(ce)})
                executed = True
                details = {'result': 'orders processed', 'op': op, 'effected': effected}
        # Alert & audit
        _notify_telegram(f"✅ Action confirmed: {a_type} {payload} | executed={executed}")
        logger.info(f"ACTION CONFIRMED: type={a_type} payload={payload} executed={executed}")
        return jsonify({'status': 'ok', 'executed': executed, 'details': details, 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Action execution error: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500
@app.route('/api/trades/count')
def trade_count():
    """Trade count route"""
    return jsonify({
        "count": 0,
        "timestamp": str(datetime.now())
    })

@app.route('/api/health')
def health():
    """Health check route"""
    return jsonify({
        "status": "ok",
        "timestamp": str(datetime.now()),
        "dashboard_manager": "initialized" if dashboard_manager else "failed"
    })

# Safe task endpoint to run a one-shot market update and signal execution
@app.route('/tasks/full_scan', methods=['POST'])
def full_scan():
    if request.method != 'POST':
        return jsonify({"ok": False, "error": "POST required"}), 405
    
    if dashboard_manager is None:
        logger.error("❌ Dashboard manager not available for full scan")
        return jsonify({"ok": False, "error": "dashboard manager unavailable"}), 503
    
    try:
        logger.info("🔄 Starting PROGRESSIVE market scan... [VERSION: 2025-10-01-06:30]")
        logger.info(f"📊 Dashboard manager available: {dashboard_manager is not None}")
        
        # First try normal scan
        results = dashboard_manager.execute_trading_signals()
        logger.info(f"📊 Normal scan completed, results type: {type(results)}")
        
        # Check if any trades were executed
        total_trades = 0
        if isinstance(results, dict):
            for acc, res in results.items():
                if isinstance(res, dict) and 'executed_trades' in res:
                    total_trades += len(res.get('executed_trades', []))
        
        logger.info(f"📊 Total trades from normal scan: {total_trades}")
        logger.info(f"📊 Will enter progressive scan: {total_trades == 0}")
        
        # If no trades found, run progressive relaxation
        if total_trades == 0:
            logger.info("🔍 No trades found with normal criteria - running progressive relaxation...")
            try:
                from progressive_trading_scanner import ProgressiveTradingScanner
                scanner = ProgressiveTradingScanner()
                progressive_results = scanner.run_progressive_scan(max_attempts=3)  # Limit to 3 levels
                
                if progressive_results.get('success') and progressive_results.get('total_trades', 0) > 0:
                    logger.info(f"✅ Progressive scan found {progressive_results.get('total_trades', 0)} trades!")
                    results = progressive_results
                    total_trades = progressive_results.get('total_trades', 0)
                else:
                    logger.info("⚠️ Progressive scan also found no trades")
            except Exception as prog_err:
                logger.warning(f"⚠️ Progressive scan failed: {prog_err}")
        
        # Telegram confirmation (ALWAYS SEND - critical feature)
        try:
            from src.core.telegram_notifier import get_telegram_notifier
            notifier = getattr(dashboard_manager, 'telegram_notifier', None) or get_telegram_notifier()
            
            # ALWAYS log notification attempt
            logger.info(f"📱 Attempting Telegram notification (enabled: {getattr(notifier, 'enabled', False)})")
            
            if notifier and getattr(notifier, 'enabled', False):
                # Build detailed multi-account summary
                if total_trades > 0:
                    summary_lines = [f"🎯 <b>PROGRESSIVE SCAN - {total_trades} TRADES EXECUTED</b>"]
                else:
                    summary_lines = [f"📊 <b>SCAN COMPLETE - NO OPPORTUNITIES</b>"]
                
                summary_lines.append(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
                summary_lines.append("")
                
                if isinstance(results, dict):
                    for acc, res in results.items():
                        if isinstance(res, dict):
                            executed = res.get('executed_trades', [])
                            if executed:
                                summary_lines.append(f"✅ {acc[-3:]}: {len(executed)} trades")
                            else:
                                summary_lines.append(f"⚪ {acc[-3:]}: 0 trades")
                
                if total_trades == 0:
                    summary_lines.append("")
                    summary_lines.append("💡 No opportunities met criteria")
                    summary_lines.append("🔄 Next scan: every hour")
                
                message = "\n".join(summary_lines) + "\n\n#ScanUpdate #AutoScan"
                
                # Force send message (bypass rate limiting for scan updates)
                success = notifier.send_message(message, "scan_update")
                logger.info(f"✅ Telegram notification sent: {success}")
            else:
                logger.error("❌ Telegram notifier not enabled!")
                logger.error(f"   Token present: {bool(os.getenv('TELEGRAM_TOKEN'))}")
                logger.error(f"   Chat ID present: {bool(os.getenv('TELEGRAM_CHAT_ID'))}")
        except Exception as notify_err:
            logger.error(f"❌ Telegram notify failed: {notify_err}")
            logger.exception("Full notification error traceback:")

        logger.info(f"✅ Progressive full scan completed: {total_trades} total trades")
        return jsonify({
            "ok": True, 
            "results": results,
            "total_trades": total_trades,
            "scan_type": "progressive" if total_trades > 0 else "normal",
            "timestamp": str(datetime.now())
        })
        
    except Exception as e:
        logger.error(f"❌ Full scan error: {e}")
        logger.exception("Full traceback:")
        return jsonify({"ok": False, "error": str(e)}), 500

# Public scan trigger with token auth (for manual triggers)
@app.route('/tasks/full_scan_public', methods=['POST'])
def full_scan_public():
    token = request.headers.get('X-Scan-Token') or request.args.get('token')
    expected = os.environ.get('SCAN_TRIGGER_TOKEN')
    if not expected or token != expected:
        return jsonify({"ok": False, "error": "unauthorized"}), 401

    if dashboard_manager is None:
        return jsonify({"ok": False, "error": "dashboard manager unavailable"}), 503

    # Telegram: announce scan start
    try:
        from src.core.telegram_notifier import get_telegram_notifier
        notifier = getattr(dashboard_manager, 'telegram_notifier', None) or get_telegram_notifier()
        if notifier and getattr(notifier, 'enabled', False):
            notifier.send_message("🔍 Manual scan started\n#ScanUpdate")
    except Exception:
        pass

    try:
        results = dashboard_manager.execute_trading_signals()
        # Telegram: announce completion summary
        try:
            from src.core.telegram_notifier import get_telegram_notifier
            notifier = getattr(dashboard_manager, 'telegram_notifier', None) or get_telegram_notifier()
            if notifier and getattr(notifier, 'enabled', False):
                summary_lines = ["✅ Manual scan completed"]
                if isinstance(results, dict):
                    for acc, res in results.items():
                        executed = res.get('executed_trades', []) if isinstance(res, dict) else []
                        summary_lines.append(f"• {acc}: {len(executed)} trades")
                notifier.send_message("\n".join(summary_lines) + "\n#ScanUpdate")
        except Exception:
            pass

        return jsonify({"ok": True, "results": results, "timestamp": str(datetime.now())})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

# Progressive trading scanner endpoint
@app.route('/tasks/progressive_scan', methods=['POST'])
def progressive_scan():
    """Progressive trading scanner that relaxes criteria until trades are found"""
    try:
        logger.info("🔄 Starting progressive trading scan...")
        
        # Import and run progressive scanner
        from progressive_trading_scanner import ProgressiveTradingScanner
        
        scanner = ProgressiveTradingScanner()
        results = scanner.run_progressive_scan()
        
        logger.info(f"✅ Progressive scan completed: {results}")
        
        return jsonify({
            "ok": True,
            "progressive_scan_results": results,
            "timestamp": str(datetime.now())
        })
        
    except Exception as e:
        logger.error(f"❌ Progressive scan error: {e}")
        logger.exception("Full traceback:")
        return jsonify({"ok": False, "error": str(e)}), 500

# Telegram connection test
@app.route('/api/telegram/test')
def telegram_test():
    try:
        from src.core.telegram_notifier import get_telegram_notifier
        notifier = get_telegram_notifier()
        ok = notifier.test_connection() if getattr(notifier, 'enabled', False) else False
        if ok:
            notifier.send_message("📡 Telegram test OK\n#SystemStatus")
        return jsonify({"ok": ok})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route('/api/news')
def get_news():
    """Get news data endpoint"""
    try:
        if not news_integration:
            return jsonify({"error": "News integration not available"}), 503
        
        # Get news data for major currency pairs
        currency_pairs = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD']
        news_data = asyncio.run(news_integration.get_news_data(currency_pairs))
        
        # Normalize shape for dashboard JS which expects news_data.news_items
        normalized = {"news_items": news_data if isinstance(news_data, list) else []}
        return jsonify({
            "status": "success",
            "news_count": len(normalized["news_items"]),
            "news_data": normalized,
            "timestamp": str(datetime.now())
        })
        
    except Exception as e:
        logger.error(f"❌ News API error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/news/analysis')
def get_news_analysis():
    """Get news analysis endpoint"""
    try:
        if not news_integration:
            return jsonify({"error": "News integration not available"}), 503
        
        # Get news analysis for major currency pairs
        currency_pairs = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD']
        analysis = news_integration.get_news_analysis(currency_pairs)
        
        return jsonify({
            "status": "success",
            "analysis": analysis,
            "timestamp": str(datetime.now())
        })
        
    except Exception as e:
        logger.error(f"❌ News analysis error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/insights')
def api_insights():
    """Unified insights endpoint for dashboard with real data."""
    try:
        insights = {
            "overall_sentiment": 0.0,
            "market_impact": "neutral",
            "trading_recommendation": "hold",
            "confidence": 0.0,
            "key_events": [],
            "risk_factors": [],
            "opportunities": [],
            "summary": "Monitoring markets",
            "focus": [],
            "regimes": {},
            "risk_level": "low"
        }
        
        # Get AI insights from dashboard
        if dashboard_manager:
            status = dashboard_manager.get_system_status()
            trade_phase = status.get('trade_phase', '')
            
            # Set summary from trade phase
            insights['summary'] = trade_phase or "AI monitoring all instruments"
            
            # Extract sentiment
            if 'BULLISH' in trade_phase.upper():
                insights['overall_sentiment'] = 0.6
                insights['market_impact'] = 'moderate'
                insights['trading_recommendation'] = 'buy'
                insights['opportunities'] = ['Gold', 'EUR/USD']
                insights['confidence'] = 0.75
            elif 'BEARISH' in trade_phase.upper():
                insights['overall_sentiment'] = -0.6
                insights['market_impact'] = 'moderate'
                insights['trading_recommendation'] = 'sell'
                insights['risk_factors'] = ['Downside risk']
                insights['confidence'] = 0.75
            else:
                insights['overall_sentiment'] = 0.17
                insights['trading_recommendation'] = status.get('ai_recommendation', 'HOLD').lower()
                insights['confidence'] = 0.65
            
            # Get market regimes
            market_data = dashboard_manager.get_market_data()
            if market_data:
                for instrument, data in list(market_data.items())[:4]:
                    regime = data.get('regime', 'unknown')
                    insights['regimes'][instrument] = regime
                    if regime == 'trending':
                        insights['focus'].append(instrument)
            
            # Get upcoming news
            upcoming = status.get('upcoming_news', [])
            if upcoming:
                insights['key_events'] = [news.get('event', '') for news in upcoming[:3]]
        
        return jsonify({
            "status": "success",
            "insights": insights,
            "timestamp": str(datetime.now())
        })
    except Exception as e:
        logger.error(f"❌ Insights error: {e}")
        return jsonify({
            "status": "success",
            "insights": {
                "overall_sentiment": 0.0,
                "market_impact": "neutral",
                "trading_recommendation": "hold",
                "confidence": 0.0,
                "summary": "System active",
                "focus": [],
                "regimes": {},
                "risk_level": "low"
            },
            "timestamp": str(datetime.now())
        })

# Minimal AI assistant endpoints for Playwright tests
@app.route('/ai/health')
def ai_health():
    return jsonify({"status": "healthy"})

@app.route('/ai/interpret', methods=['POST'])
def ai_interpret():
    """Intelligent AI assistant for trading system analysis and recommendations."""
    try:
        import requests
        from urllib.parse import urljoin

        def fetch_live_status() -> Dict[str, Any]:
            try:
                base = request.host_url  # e.g., https://ai-quant-trading.uc.r.appspot.com/
                url = urljoin(base, '/api/status')
                r = requests.get(url, timeout=4)
                if r.ok and r.headers.get('content-type','').startswith('application/json'):
                    return r.json()
            except Exception:
                pass
            # Fallback to in-process status
            try:
                return dashboard_manager.get_system_status() if dashboard_manager else {}
            except Exception:
                return {}

        payload = request.get_json(silent=True) or {}
        text = (payload.get('text') or payload.get('message') or '').lower().strip()
        
        if not text:
            return jsonify({"reply": "Hello! I'm your AI trading assistant. I can help you analyze market conditions, check account status, review trading performance, and provide insights. What would you like to know?"})
        
        # Grab freshest status used by the dashboard
        live_status: Dict[str, Any] = fetch_live_status()
        system_status = live_status or {}
        market_payload = system_status.get('market_data')
        
        # Build normalized market map: pair -> fields
        normalized_market: Dict[str, Any] = {}
        if isinstance(market_payload, dict):
            for key, val in market_payload.items():
                if isinstance(val, dict):
                    # account -> {pair: fields}
                    inner_vals = list(val.values())
                    if inner_vals and isinstance(inner_vals[0], dict) and 'bid' in inner_vals[0]:
                        for pair, fields in val.items():
                            normalized_market[pair] = fields
                    # else: ignore
                # else: ignore
        # Also consider direct flat map from data feed
        if not normalized_market and dashboard_manager:
            try:
                direct = dashboard_manager.get_market_data()
                if isinstance(direct, dict):
                    for pair, fields in direct.items():
                        if isinstance(fields, dict) and 'bid' in fields:
                            normalized_market[pair] = fields
            except Exception:
                pass
        
        risk_metrics = dashboard_manager.get_risk_metrics() if dashboard_manager else {}
        
        # Account analysis
        if any(word in text for word in ['account', 'balance', 'profit', 'loss', 'performance']):
            accounts = system_status.get('account_statuses', {})
            total_balance = sum(acc.get('balance', 0) for acc in accounts.values())
            total_unrealized = sum(acc.get('unrealized_pl', 0) for acc in accounts.values())
            active_trades = sum((acc.get('open_trade_count') or acc.get('open_trades') or 0) for acc in accounts.values())
            
            reply = f"📊 Account Summary\n• Total Balance: ${total_balance:,.2f}\n• Unrealized P&L: ${total_unrealized:,.2f}\n• Active Trades: {active_trades}\n• Active Accounts: {len(accounts)}\n\n"
            for acc_id, acc in accounts.items():
                reply += f"{acc.get('account_name', acc_id)} — Bal: ${acc.get('balance', 0):,.2f}, P&L: ${acc.get('unrealized_pl', 0):,.2f}, Trades: {(acc.get('open_trade_count') or acc.get('open_trades') or 0)}\n"
            return jsonify({"reply": reply})
        
        # Market analysis
        elif any(word in text for word in ['market', 'price', 'trend', 'regime', 'spread']):
            # Prefer the same structure used by /api/status
            normalized: Dict[str, Any] = {}
            try:
                status_market = system_status.get('market_data') if isinstance(system_status, dict) else None
                if status_market:
                    # status_market may be {accountId: {PAIR: data}}
                    for maybe_account, value in status_market.items():
                        if isinstance(value, dict):
                            # If value looks like instrument map
                            sample_keys = list(value.keys())
                            if sample_keys and isinstance(value[sample_keys[0]], dict) and 'bid' in value[sample_keys[0]]:
                                for pair, data in value.items():
                                    normalized[pair] = data
                # Fallback to direct feed if nothing collected
                if not normalized and market_data:
                    # market_data may be {PAIR: data}
                    for pair, data in market_data.items():
                        if isinstance(data, dict) and 'bid' in data:
                            normalized[pair] = data
            except Exception:
                normalized = {}

            if normalized:
                priority = ['XAU_USD','EUR_USD','GBP_USD','USD_JPY','AUD_USD','NZD_USD','USD_CAD']
                # compute strength score: higher vol and tighter spread are better for trending; for ranging, prefer lower vol
                def strength(pair, d):
                    regime = d.get('regime','unknown')
                    spread = float(d.get('spread',0) or 0)
                    vol = float(d.get('volatility_score',0) or 0)
                    # normalize spread to pips-like scale
                    pip_spread = spread * 10000.0
                    if pair.endswith('JPY'):
                        pip_spread = spread * 100.0
                    if pair.startswith('XAU_'):
                        pip_spread = spread  # already in dollars
                    if regime == 'trending':
                        return max(0.0, vol*1.2 - pip_spread*0.02)
                    if regime == 'ranging':
                        return max(0.0, (1.0-vol)*1.0 - pip_spread*0.01)
                    return 0.1 - pip_spread*0.01
                
                # filter to priority universe first
                filtered = {p: normalized[p] for p in priority if p in normalized}
                # if some are missing, append any other available pairs
                for p, d in normalized.items():
                    if p not in filtered:
                        filtered[p] = d
                # build lines with ranking
                scored = [(strength(p, d), p, d) for p, d in filtered.items()]
                scored.sort(reverse=True, key=lambda x: (p in priority, x[0]))
                lines: List[str] = ["📈 Market Analysis\n"]
                focus = []
                for score, pair, d in scored[:7]:
                    regime = d.get('regime','unknown')
                    spread = float(d.get('spread',0) or 0)
                    vol = float(d.get('volatility_score',0) or 0)
                    bias = 'trend-follow' if regime == 'trending' else 'mean-revert' if regime == 'ranging' else 'observe'
                    lines.append(f"• {pair}: {regime}, spread {spread:.5f}, vol {vol:.2f}, bias {bias}")
                    focus.append(pair)
                lines.append("")
                lines.append(f"Focus: {', '.join(focus[:4])}")
                return jsonify({"reply": "\n".join(lines)})
            else:
                # Honest response: no per-instrument data currently available
                data_feed = system_status.get('data_feed_status', 'unknown')
                last_update = system_status.get('last_update', 'unknown')
                reply = (
                    "📈 **Market Analysis:**\n"
                    "No per-instrument market data is available right now.\n"
                    f"Data feed status: {data_feed}. Last system update: {last_update}.\n"
                    "I will report details as soon as live ticks are available."
                )
                
                return jsonify({"reply": reply})
        
        # Risk analysis
        elif any(word in text for word in ['risk', 'exposure', 'drawdown', 'sharpe']):
            if risk_metrics:
                reply = "⚠️ Risk Analysis\n"
                reply += f"• Risk Level: {risk_metrics.get('risk_level', 'unknown')}\n"
                reply += f"• Portfolio Risk: {risk_metrics.get('portfolio_risk', 0):.2%}\n"
                reply += f"• Max Drawdown: {risk_metrics.get('max_drawdown', 0):.2%}\n"
                reply += f"• Sharpe Ratio: {risk_metrics.get('sharpe_ratio', 0):.2f}\n"
            else:
                reply = "⚠️ Risk Analysis\nRisk metrics not available at the moment."
            return jsonify({"reply": reply})
        
        # Intent-driven trading commands
        elif any(word in text for word in ['layer', 'add', 'reduce', 'risk', 'trailing', 'stop', 'lock', 'profit', 'take', 'close', 'buy', 'sell']):
            return _handle_trading_intent(text, normalized_market, system_status)
        
        # Trading signals and recommendations
        elif any(word in text for word in ['signal', 'recommendation']):
            # Simple heuristic using normalized_market
            lines: List[str] = ["🎯 Trading Recommendations\n"]
            if normalized_market:
                for pair, d in normalized_market.items():
                    regime = d.get('regime', 'unknown')
                    vol = float(d.get('volatility_score', 0) or 0)
                    if regime == 'trending':
                        lines.append(f"• {pair}: trend-follow setups; watch momentum (vol {vol:.2f})")
                    elif regime == 'ranging':
                        lines.append(f"• {pair}: mean-reversion levels; fade extremes (vol {vol:.2f})")
                    else:
                        lines.append(f"• {pair}: unclear regime; wait for confirmation (vol {vol:.2f})")
            else:
                lines.append("No live ticks available for recommendations.")
            lines.append("\nRisk: size small, use stops, monitor correlation.")
            return jsonify({"reply": "\n".join(lines)})
        
        # System status
        elif any(word in text for word in ['status', 'health', 'system', 'online']):
            reply = "🟢 System Status\n"
            reply += f"• System: {system_status.get('system_status', 'unknown')}\n"
            reply += f"• Data Feed: {system_status.get('data_feed_status', 'unknown')}\n"
            reply += f"• Live Mode: {system_status.get('live_data_mode', False)}\n"
            reply += f"• Active Accounts: {system_status.get('active_accounts', 0)}\n"
            reply += f"• Last Update: {system_status.get('last_update', 'unknown')}\n"
            return jsonify({"reply": reply})
        
        # Help and commands
        elif any(word in text for word in ['help', 'commands', 'what can you do']):
            reply = (
                "🤖 Commands\n"
                "• Account analysis\n"
                "• Market analysis\n"
                "• Risk assessment\n"
                "• Trading recommendations\n"
                "• System status\n"
            )
            return jsonify({"reply": reply})
        
        # Default response
        else:
            reply = (
                f"I understand you're asking about '{text}'.\n"
                "Ask about accounts, market, risk, signals, or system status."
            )
            return jsonify({"reply": reply})
            
    except Exception as e:
        logger.error(f"❌ AI assistant error: {e}")
        return jsonify({"reply": f"Sorry, I encountered an error: {str(e)}. Please try again."}), 500

def _handle_trading_intent(text: str, market_data: Dict[str, Any], system_status: Dict[str, Any]) -> Dict[str, Any]:
    """Handle natural language trading commands with intent parsing"""
    try:
        import re
        import uuid
        
        # Extract pairs mentioned
        pairs_mentioned = []
        for pair in ['XAU_USD', 'EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD', 'NZD_USD', 'USD_CAD']:
            if pair.lower().replace('_', '') in text.lower().replace('_', '').replace(' ', ''):
                pairs_mentioned.append(pair)
        
        # If no specific pairs, default to major USD pairs
        if not pairs_mentioned:
            pairs_mentioned = ['EUR_USD', 'GBP_USD', 'USD_JPY']
        
        # Parse intent
        intent = None
        size = None
        side = None
        
        # Layer in positions
        if any(word in text for word in ['layer', 'add', 'scale']):
            intent = 'layer_in'
            # Extract size (default 0.25% if not specified)
            size_match = re.search(r'(\d+(?:\.\d+)?)\s*%', text)
            size = float(size_match.group(1)) / 100 if size_match else 0.0025
            # Infer side from context or default to BUY
            side = 'BUY' if any(word in text for word in ['buy', 'long']) else 'SELL' if any(word in text for word in ['sell', 'short']) else 'BUY'
        
        # Reduce risk
        elif any(word in text for word in ['reduce', 'cut', 'lower']):
            intent = 'reduce_risk'
            # Extract percentage (default 20% if not specified)
            size_match = re.search(r'(\d+(?:\.\d+)?)\s*%', text)
            size = float(size_match.group(1)) / 100 if size_match else 0.20
        
        # Trailing stop
        elif any(word in text for word in ['trailing', 'trail']):
            intent = 'trailing_stop'
            # Extract ATR multiplier (default 0.6 if not specified)
            atr_match = re.search(r'(\d+(?:\.\d+)?)\s*atr', text.lower())
            size = float(atr_match.group(1)) if atr_match else 0.6
        
        # Lock profits
        elif any(word in text for word in ['lock', 'take', 'profit']):
            intent = 'lock_profits'
            # Extract percentage (default 30% if not specified)
            size_match = re.search(r'(\d+(?:\.\d+)?)\s*%', text)
            size = float(size_match.group(1)) / 100 if size_match else 0.30
        
        if not intent:
            return jsonify({"reply": "I understand you want to trade, but I need clearer intent. Try:\n• 'Layer in 0.25% on EUR_USD'\n• 'Reduce risk by 20%'\n• 'Set trailing stop 0.6 ATR on XAU_USD'\n• 'Lock 30% profits on EUR_USD'"})
        
        # Generate preview
        confirmation_id = str(uuid.uuid4())
        
        if intent == 'layer_in':
            preview = f"📈 Layer In Position\n• Pairs: {', '.join(pairs_mentioned)}\n• Side: {side}\n• Size: {size:.2%} of account\n• Risk: ~{size*100:.1f}% per position"
        elif intent == 'reduce_risk':
            preview = f"⚠️ Reduce Risk\n• Pairs: {', '.join(pairs_mentioned)}\n• Reduction: {size:.1%}\n• Action: Close {size:.1%} of positions"
        elif intent == 'trailing_stop':
            preview = f"🔄 Set Trailing Stop\n• Pairs: {', '.join(pairs_mentioned)}\n• Distance: {size} ATR\n• Type: Trailing stop loss"
        elif intent == 'lock_profits':
            preview = f"💰 Lock Profits\n• Pairs: {', '.join(pairs_mentioned)}\n• Take: {size:.1%} of profits\n• Action: Partial close at market"
        
        # Store intent for confirmation
        if not hasattr(app, 'pending_confirmations'):
            app.pending_confirmations = {}
        
        app.pending_confirmations[confirmation_id] = {
            'intent': intent,
            'pairs': pairs_mentioned,
            'size': size,
            'side': side,
            'timestamp': datetime.now().isoformat(),
            'user_text': text
        }
        
        reply = f"{preview}\n\n⚠️ LIVE ACTION REQUIRES CONFIRMATION\nType 'CONFIRM {confirmation_id}' to execute, or 'CANCEL {confirmation_id}' to abort."
        
        return jsonify({
            "reply": reply,
            "requires_confirmation": True,
            "confirmation_id": confirmation_id,
            "preview": {
                "summary": preview,
                "intent": intent,
                "pairs": pairs_mentioned,
                "size": size,
                "side": side
            },
            "live_guard": True
        })
        
    except Exception as e:
        logger.error(f"❌ Intent parsing error: {e}")
        return jsonify({"reply": f"Intent parsing failed: {str(e)}. Please try rephrasing your command."})

@app.route('/ai/confirm', methods=['POST'])
def ai_confirm():
    """Handle AI action confirmations"""
    try:
        payload = request.get_json(silent=True) or {}
        confirmation_id = payload.get('confirmation_id')
        confirm = payload.get('confirm', False)
        
        if not confirmation_id or not hasattr(app, 'pending_confirmations'):
            return jsonify({"status": "error", "message": "No pending confirmation found"}), 400
        
        pending = app.pending_confirmations.get(confirmation_id)
        if not pending:
            return jsonify({"status": "error", "message": "Confirmation expired or not found"}), 400
        
        if not confirm:
            # Cancel action
            del app.pending_confirmations[confirmation_id]
            return jsonify({"status": "cancelled", "message": "Action cancelled"})
        
        # Execute confirmed action
        try:
            result = _execute_trading_action(pending)
            
            # Send Telegram notification
            if dashboard_manager and dashboard_manager.telegram_notifier:
                message = f"🤖 AI Action Executed: {pending['intent']} on {', '.join(pending['pairs'])}"
                dashboard_manager.telegram_notifier.send_message(message)
            
            # Clean up
            del app.pending_confirmations[confirmation_id]
            
            return jsonify({
                "status": "executed",
                "result": result,
                "message": f"Action executed: {pending['intent']}"
            })
            
        except Exception as e:
            logger.error(f"❌ Action execution failed: {e}")
            return jsonify({
                "status": "error", 
                "message": f"Execution failed: {str(e)}"
            }), 500
            
    except Exception as e:
        logger.error(f"❌ Confirmation error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

def _execute_trading_action(action: Dict[str, Any]) -> Dict[str, Any]:
    """Execute the confirmed trading action"""
    try:
        intent = action['intent']
        pairs = action['pairs']
        size = action['size']
        side = action.get('side', 'BUY')
        
        results = {}
        
        if intent == 'layer_in':
            # Add positions
            for pair in pairs:
                try:
                    # Get account with lowest current exposure
                    best_account = min(dashboard_manager.active_accounts, 
                                    key=lambda acc: dashboard_manager.account_manager.get_account_status(acc).get('margin_used', 0))
                    
                    # Calculate position size (simplified)
                    account_status = dashboard_manager.account_manager.get_account_status(best_account)
                    balance = account_status.get('balance', 100000)
                    position_size = balance * size
                    
                    # Create market order
                    order = {
                        'instrument': pair,
                        'side': side,
                        'units': int(position_size / 1000),  # Simplified units
                        'type': 'MARKET',
                        'timeInForce': 'FOK'
                    }
                    
                    result = dashboard_manager.order_manager.execute_trades(best_account, [order])
                    results[pair] = result
                    
                except Exception as e:
                    results[pair] = {'error': str(e)}
        
        elif intent == 'reduce_risk':
            # Close percentage of positions
            for account_id in dashboard_manager.active_accounts:
                try:
                    # Get open positions and close percentage
                    positions = dashboard_manager.order_manager.get_open_positions(account_id)
                    close_count = max(1, int(len(positions) * size))
                    
                    for i, position in enumerate(positions[:close_count]):
                        close_order = {
                            'instrument': position['instrument'],
                            'side': 'SELL' if position['side'] == 'BUY' else 'BUY',
                            'units': position['units'],
                            'type': 'MARKET',
                            'timeInForce': 'FOK'
                        }
                        result = dashboard_manager.order_manager.execute_trades(account_id, [close_order])
                        results[f"{account_id}_{position['instrument']}"] = result
                        
                except Exception as e:
                    results[account_id] = {'error': str(e)}
        
        elif intent == 'trailing_stop':
            # Set trailing stops (simplified - would need ATR calculation)
            for account_id in dashboard_manager.active_accounts:
                try:
                    positions = dashboard_manager.order_manager.get_open_positions(account_id)
                    for position in positions:
                        if position['instrument'] in pairs:
                            # Calculate trailing stop distance (simplified)
                            stop_distance = 0.01  # 1% simplified
                            
                            stop_order = {
                                'instrument': position['instrument'],
                                'side': 'SELL' if position['side'] == 'BUY' else 'BUY',
                                'units': position['units'],
                                'type': 'STOP',
                                'price': position['entry_price'] * (1 - stop_distance) if position['side'] == 'BUY' else position['entry_price'] * (1 + stop_distance),
                                'timeInForce': 'GTC'
                            }
                            result = dashboard_manager.order_manager.execute_trades(account_id, [stop_order])
                            results[f"{account_id}_{position['instrument']}"] = result
                            
                except Exception as e:
                    results[account_id] = {'error': str(e)}
        
        elif intent == 'lock_profits':
            # Partial close for profit taking
            for account_id in dashboard_manager.active_accounts:
                try:
                    positions = dashboard_manager.order_manager.get_open_positions(account_id)
                    for position in positions:
                        if position['instrument'] in pairs and position.get('unrealized_pl', 0) > 0:
                            # Close percentage of profitable position
                            close_units = int(position['units'] * size)
                            if close_units > 0:
                                close_order = {
                                    'instrument': position['instrument'],
                                    'side': 'SELL' if position['side'] == 'BUY' else 'BUY',
                                    'units': close_units,
                                    'type': 'MARKET',
                                    'timeInForce': 'FOK'
                                }
                                result = dashboard_manager.order_manager.execute_trades(account_id, [close_order])
                                results[f"{account_id}_{position['instrument']}"] = result
                                
                except Exception as e:
                    results[account_id] = {'error': str(e)}
        
        return {
            'intent': intent,
            'pairs': pairs,
            'results': results,
            'timestamp': datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Action execution error: {e}")
        raise e


@app.route('/api/trade_ideas')
def api_trade_ideas():
    """Generate trade ideas from AI insights + market analysis."""
    try:
        ideas: List[Dict[str, Any]] = []
        
        if dashboard_manager:
            # Get AI insights
            status = dashboard_manager.get_system_status()
            trade_phase = status.get('trade_phase', '')
            ai_rec = status.get('ai_recommendation', 'HOLD')
            
            # Get market data
            flat_market: Dict[str, Any] = dashboard_manager.get_market_data()
            
            # Generate ideas based on AI phase
            if 'BULLISH' in trade_phase.upper() and 'BUY' in ai_rec.upper():
                for instrument, md in list(flat_market.items())[:4]:
                    if md.get('spread', 999) < 2.0:
                        ideas.append({
                            'instrument': instrument,
                            'action': 'BUY',
                            'confidence': 75,
                            'reason': 'AI Phase: Bullish conditions - buy opportunities'
                        })
            
            elif 'BEARISH' in trade_phase.upper():
                for instrument, md in list(flat_market.items())[:4]:
                    if md.get('spread', 999) < 2.0:
                        ideas.append({
                            'instrument': instrument,
                            'action': 'SELL',
                            'confidence': 70,
                            'reason': 'AI Phase: Bearish conditions - selling pressure'
                        })
            
            else:
                # Neutral - check fundamentals + regimes
                # Gold fundamental check
                try:
                    from src.core.economic_indicators import get_economic_indicators
                    econ = get_economic_indicators()
                    if econ.enabled:
                        gold_score = econ.get_gold_fundamental_score()
                        if gold_score.get('score', 0) > 0.15:
                            ideas.append({
                                'instrument': 'XAU_USD',
                                'action': 'BUY',
                                'confidence': 80,
                                'reason': f"Gold fundamentals: {gold_score.get('recommendation', 'BUY')}"
                            })
                except:
                    pass
                
                # Regime-based ideas
                for instrument, md in flat_market.items():
                    regime = md.get('regime', 'unknown')
                    spread = md.get('spread', 0.0)
                    vol = md.get('volatility_score', 0.0)
                    
                    if regime == 'trending' and spread < 2.0 and vol > 0.3:
                        ideas.append({
                            'instrument': instrument,
                            'action': 'Follow Trend',
                            'confidence': int(vol * 80),
                            'reason': 'Trending - momentum trade'
                        })
                    elif regime == 'ranging' and spread < 1.5:
                        ideas.append({
                            'instrument': instrument,
                            'action': 'Range Trade',
                            'confidence': 60,
                            'reason': 'Ranging - mean reversion'
                        })
            
            ideas = ideas[:6]  # Limit to 6
        
        return jsonify({'status': 'success', 'ideas': ideas, 'timestamp': datetime.now().isoformat()})
    except Exception as e:
        logger.error(f"❌ Trade ideas error: {e}")
        return jsonify({'status': 'success', 'ideas': [], 'timestamp': datetime.now().isoformat()})

# WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info("🔌 Client connected to WebSocket")
    emit('status', {'msg': 'Connected to trading dashboard', 'timestamp': datetime.now().isoformat()})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info("🔌 Client disconnected from WebSocket")

@socketio.on('request_update')
def handle_update_request():
    """Handle update request from client"""
    try:
        if dashboard_manager:
            # Emit system status
            emit('systems_update', dashboard_manager.get_system_status())
            
            # Emit market data
            emit('market_update', dashboard_manager.get_market_data())
            
            # Emit news data
            if news_integration:
                try:
                    currency_pairs = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD']
                    news_data = asyncio.run(news_integration.get_news_data(currency_pairs))
                    emit('news_update', news_data)
                    # Emit AI insights with trade phase and upcoming news
                    try:
                        full_status = dashboard_manager.get_system_status()
                        ai_insights = {
                            'trade_phase': full_status.get('trade_phase', 'Monitoring markets'),
                            'upcoming_news': full_status.get('upcoming_news', []),
                            'ai_recommendation': full_status.get('ai_recommendation', 'HOLD'),
                            'timestamp': datetime.now().isoformat()
                        }
                        emit('news_impact_update', ai_insights)
                        logger.info(f"✅ Emitted AI insights: {ai_insights.get('trade_phase')}")
                    except Exception as e:
                        logger.error(f"❌ News impact emit error: {e}")
                except Exception as e:
                    logger.error(f"❌ News update error: {e}")
                    emit('news_update', [])
            
            # Emit AI assistant status
            if ai_assistant:
                try:
                    ai_status = ai_assistant.get_status()
                    emit('ai_update', ai_status)
                except Exception as e:
                    logger.error(f"❌ AI assistant update error: {e}")
                    emit('ai_update', {"status": "unavailable"})
            
            # Emit risk metrics
            emit('risk_update', dashboard_manager.get_risk_metrics())
            
        else:
            emit('error', {'msg': 'Dashboard manager not available'})
            
    except Exception as e:
        logger.error(f"❌ WebSocket update error: {e}")
        emit('error', {'msg': str(e)})

@socketio.on('ai_chat')
def handle_ai_chat(data):
    """Handle AI chat messages"""
    try:
        if not ai_assistant:
            emit('ai_response', {'error': 'AI assistant not available'})
            return
        
        message = data.get('message', '')
        if not message:
            emit('ai_response', {'error': 'No message provided'})
            return
        
        # Process AI chat
        response = ai_assistant.process_message(message)
        emit('ai_response', response)
        
    except Exception as e:
        logger.error(f"❌ AI chat error: {e}")
        emit('ai_response', {'error': str(e)})

# Background update thread
def update_dashboard():
    """Update dashboard data periodically"""
    while True:
        try:
            logger.info(f"🔄 Updating dashboard data - {datetime.now()}")
            
            if dashboard_manager:
                # Create event loop for async operations
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Run updates - use existing methods
                try:
                    # Update system status
                    system_status = dashboard_manager.get_system_status()
                    
                    # Update market data
                    market_data = dashboard_manager.get_market_data()
                    
                    # Update risk metrics
                    risk_metrics = dashboard_manager.get_risk_metrics()
                    
                except Exception as e:
                    logger.error(f"❌ Dashboard update error: {e}")
                
                # Emit updates via WebSocket
                socketio.emit('systems_update', dashboard_manager.get_system_status())
                socketio.emit('market_update', dashboard_manager.get_market_data())
                socketio.emit('risk_update', dashboard_manager.get_risk_metrics())
                
                # Emit news updates
                if news_integration:
                    try:
                        currency_pairs = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD']
                        news_data = asyncio.run(news_integration.get_news_data(currency_pairs))
                        socketio.emit('news_update', news_data)
                        # Emit AI insights with trade phase and upcoming news
                        try:
                            full_status = dashboard_manager.get_system_status()
                            ai_insights = {
                                'trade_phase': full_status.get('trade_phase', 'Monitoring markets'),
                                'upcoming_news': full_status.get('upcoming_news', []),
                                'ai_recommendation': full_status.get('ai_recommendation', 'HOLD'),
                                'timestamp': datetime.now().isoformat()
                            }
                            socketio.emit('news_impact_update', ai_insights)
                        except Exception as e:
                            logger.error(f"❌ News impact update error: {e}")
                    except Exception as e:
                        logger.error(f"❌ News update error: {e}")
                
                # Emit AI assistant updates
                if ai_assistant:
                    try:
                        ai_status = ai_assistant.get_status()
                        socketio.emit('ai_update', ai_status)
                    except Exception as e:
                        logger.error(f"❌ AI assistant update error: {e}")
                
                # Close event loop
                loop.close()
            
            # Wait before next update
            time.sleep(15)
            
        except Exception as e:
            logger.error(f"❌ Dashboard update error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    # Get port from environment (required for Google Cloud)
    port = int(os.environ.get('PORT', 8080))
    
    logger.info("🚀 Starting Google Cloud Trading System - FULLY INTEGRATED")
    logger.info("=" * 60)
    logger.info("✅ WebSocket support enabled")
    logger.info("✅ Dashboard manager initialized")
    logger.info("✅ News integration enabled")
    logger.info("✅ AI assistant enabled")
    logger.info("=" * 60)
    
    # Start dashboard updates in background
    update_thread = threading.Thread(target=update_dashboard, daemon=True)
    update_thread.start()
    
    logger.info(f"🌐 Starting server on port {port}")
    logger.info("✅ Dashboard updates started in background")
    
    # Start Flask app with SocketIO - production configuration
    socketio.run(app, host='0.0.0.0', port=port, debug=False, allow_unsafe_werkzeug=True)