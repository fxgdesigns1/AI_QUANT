import os
from dotenv import load_dotenv
import oandapyV20
import oandapyV20.endpoints.accounts as accounts
import json

# Get the absolute path to the oanda_config.env file
env_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'oanda_config.env'))
print(f"Looking for config file at: {env_path}")

# Load environment variables from oanda_config.env
load_dotenv(dotenv_path=env_path)

# Get credentials from environment
api_key = os.getenv('OANDA_API_KEY')
account_id = os.getenv('PRIMARY_ACCOUNT') # Using primary account for the check

print(f"Attempting to connect with:")
print(f"API Key: ...{api_key[-4:] if api_key else 'Not Found'}")
print(f"Account ID: {account_id if account_id else 'Not Found'}")

if not api_key or not account_id:
    print("\n❌ ERROR: OANDA_API_KEY or PRIMARY_ACCOUNT not found in oanda_config.env")
    exit(1)

client = oandapyV20.API(access_token=api_key, environment="practice")
r = accounts.AccountSummary(accountID=account_id)

try:
    response = client.request(r)
    print("\n✅ SUCCESS: OANDA connection successful!")
    print("\nAccount Summary:")
    print(json.dumps(response, indent=2))
except oandapyV20.exceptions.V20Error as e:
    print(f"\n❌ FAILED: OANDA connection failed. Error: {e}")
    print("\nPlease verify your OANDA_API_KEY and PRIMARY_ACCOUNT in oanda_config.env")
