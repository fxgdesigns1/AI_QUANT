#!/usr/bin/env python3
"""
Gold Scalping Strategy - OPTIMIZED VERSION
Maximum 10 trades per day with ultra high quality filters
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd

from src.core.order_manager import TradeSignal, OrderSide, get_order_manager
from ..core.data_feed import MarketData, get_data_feed

# News integration (optional, non-breaking)
try:
    from ..core.news_integration import safe_news_integration
    NEWS_AVAILABLE = True
except ImportError:
    NEWS_AVAILABLE = False

# Learning & Honesty System (NEW OCT 21, 2025)
try:
    from ..core.loss_learner import get_loss_learner
    from ..core.early_trend_detector import get_early_trend_detector
    from ..core.honesty_reporter import get_honesty_reporter
    LEARNING_AVAILABLE = True
except ImportError:
    LEARNING_AVAILABLE = False
    logger.warning("⚠️ Learning system not available")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ScalpingSignal:
    """Gold scalping signal"""
    instrument: str
    signal: str  # 'BUY', 'SELL', 'HOLD'
    strength: float  # 0-1
    timestamp: datetime
    price_level: float
    volatility: float
    spread: float

class GoldScalpingStrategy:
    """OPTIMIZED Gold Scalping Strategy - MAX 10 TRADES/DAY"""
    
    def __init__(self):
        """Initialize optimized strategy"""
        self.name = "Gold Scalping - Optimized"
        self.instruments = ['XAU_USD']
        
        # ===============================================
        # BALANCED STRATEGY PARAMETERS (OPTIMIZED OCT 23, 2025)
        # ===============================================
        self.stop_loss_pips = 10.3           # Monte Carlo tuned: ~10.3 pips stop loss
        self.take_profit_pips = 44.5         # Tuned R:R ≈ 1:4.3
        self.min_signal_strength = 0.70      # BALANCED: 70% (relaxed from 85% to catch more setups)
        self.max_trades_per_day = 23         # Tuned cap from Monte Carlo
        self.min_trades_today = 0            # NO FORCED TRADES - only high-quality setups
        self.base_units = 10                 # Default 0.1 lot position sizing
        
        # ===============================================
        # ENHANCED VOLATILITY AND SPREAD FILTERS
        # ===============================================
        self.min_volatility = 0.000162       # Tuned minimum realised volatility
        self.max_spread = 0.81               # Tuned spread ceiling
        self.min_atr_for_entry = 1.46        # Tuned ATR gate
        self.volatility_lookback = 20        # Look back 20 periods for volatility
        
        # ===============================================
        # BALANCED QUALITY FILTERS (OPTIMIZED OCT 23, 2025)
        # ===============================================
        self.max_daily_quality_trades = 8    # Still cap retained
        self.quality_score_threshold = 0.75  # RELAXED: 75% (was 90% - too strict)
        self.daily_trade_ranking = False     # Tuned: take every compliant setup
        self.require_multiple_confirmations = False
        self.min_confirmations = 1           # Single confirmation sufficient when enabled
        
        # ===============================================
        # ENHANCED ENTRY CONDITIONS
        # ===============================================
        self.only_trade_london_ny = False    # DISABLED: Trade all sessions to get more opportunities
        self.london_session_start = 7        # 07:00 UTC
        self.london_session_end = 16         # 16:00 UTC
        self.ny_session_start = 13           # 13:00 UTC
        self.ny_session_end = 21             # 21:00 UTC
        self.session_time_guard_enabled = True
        self.session_start_hour = 10
        self.session_start_minute = 30
        self.session_end_hour = 14
        self.session_end_minute = 30
        self.pause_after_hour = 15
        self.pause_after_hours = True
        self.after_hours_risk_multiplier = 0.2
        self.min_time_between_trades_minutes = 0   # Tuned: allow consecutive trades
        self.require_pullback = False        # Tuned: allow clean breakouts without pullback
        self.pullback_ema_period = 21        # Must pull back to 21 EMA
        self.pullback_threshold = 0.00014    # Tuned pullback tolerance when enabled
        
        # ===============================================
        # BREAKOUT CONFIGURATION - ULTRA STRICT
        # ===============================================
        self.breakout_lookback = 15          # Look back 15 periods
        self.breakout_threshold = 0.00126    # Tuned breakout strength requirement
        self.require_volume_spike = True     # Volume confirmation required
        self.volume_spike_multiplier = 1.68  # Tuned volume spike factor
        
        # ===============================================
        # EARLY CLOSURE SYSTEM
        # ===============================================
        self.early_close_profit_pct = 0.0015    # Close at +0.15% profit
        self.early_close_loss_pct = -0.0025     # Close at -0.25% loss
        self.max_hold_time_minutes = 90         # Max 1.5 hours hold
        self.trailing_stop_enabled = True       # Enable trailing stops
        self.trailing_stop_distance = 0.0008    # 0.08% trailing distance
        
        # ===============================================
        # DATA STORAGE
        # ===============================================
        self.price_history: Dict[str, List[float]] = {inst: [] for inst in self.instruments}
        self.signals: List[TradeSignal] = []
        self.daily_signals = []  # Store all signals for ranking
        self.selected_trades = []  # Quality trades selected
        
        # ===============================================
        # PERFORMANCE TRACKING
        # ===============================================
        self.daily_trade_count = 0
        self.last_reset_date = datetime.now().date()
        self.last_trade_time = None  # Track time between trades
        self.last_rejection_reason = "No signals generated yet."
        
        # ===============================================
        # NEWS INTEGRATION
        # ===============================================
        self.news_enabled = NEWS_AVAILABLE and safe_news_integration.enabled if NEWS_AVAILABLE else False
        if self.news_enabled:
            logger.info("✅ News integration enabled for quality filtering")
        else:
            logger.info("ℹ️  Trading without news integration (technical signals only)")
        
        # ===============================================
        # LEARNING & HONESTY SYSTEM (NEW OCT 21, 2025)
        # ===============================================
        self.learning_enabled = False
        if LEARNING_AVAILABLE:
            try:
                self.loss_learner = get_loss_learner(strategy_name=self.name)
                self.early_trend = get_early_trend_detector()
                self.honesty = get_honesty_reporter(strategy_name=self.name)
                self.learning_enabled = True
                logger.info("✅ Loss learning ENABLED - Learns from mistakes")
                logger.info("✅ Early trend detection ENABLED - Catches moves early")
                logger.info("✅ Brutal honesty reporting ENABLED - No sugar-coating")
            except Exception as e:
                logger.warning(f"⚠️ Could not initialize learning system: {e}")
                self.loss_learner = None
                self.early_trend = None
                self.honesty = None
        else:
            self.loss_learner = None
            self.early_trend = None
            self.honesty = None
        
        logger.info(f"✅ {self.name} strategy initialized")
        logger.info(f"📊 Instruments: {self.instruments}")
        logger.info(f"📊 Max trades/day: {self.max_trades_per_day}")
        logger.info(f"📊 R:R ratio: 1:{self.take_profit_pips/self.stop_loss_pips:.1f}")
    
    @property
    def daily_trades(self):
        """Get daily trade count"""
        return self.daily_trade_count
    
    def _reset_daily_counters(self):
        """Reset daily counters if new day"""
        current_date = datetime.now().date()
        if current_date != self.last_reset_date:
            self.daily_trade_count = 0
            self.last_reset_date = current_date
            self.daily_signals = []  # Reset daily signals
            self.last_trade_time = None
            logger.info("🔄 Daily counters reset")
    
    def _is_london_or_ny_session(self) -> bool:
        """Check if current time is London or NY session"""
        now = datetime.now()
        current_hour = now.hour
        
        # London session: 07:00-16:00 UTC
        london_session = self.london_session_start <= current_hour < self.london_session_end
        
        # NY session: 13:00-21:00 UTC
        ny_session = self.ny_session_start <= current_hour < self.ny_session_end
        
        return london_session or ny_session

    def _session_window_state(self) -> Tuple[bool, float]:
        """
        Determine if we are within the allowed 10:30–14:30 GMT window and
        what risk multiplier to apply. After 15:00 GMT entries are paused by
        default, but an optional risk reduction mode can be enabled.
        """
        if not self.session_time_guard_enabled:
            return True, 1.0

        now = datetime.utcnow()
        minutes = now.hour * 60 + now.minute

        window_start = self.session_start_hour * 60 + self.session_start_minute
        window_end = self.session_end_hour * 60 + self.session_end_minute
        pause_cutoff = self.pause_after_hour * 60

        if window_start <= minutes <= window_end:
            return True, 1.0

        # After-hours handling (>= pause cutoff)
        if minutes >= pause_cutoff:
            if self.pause_after_hours:
                return False, 0.0
            return True, max(0.0, min(1.0, self.after_hours_risk_multiplier))

        # Outside the active window (before start or after end but before pause cutoff)
        return False, 0.0
    
    def _can_trade_now(self) -> bool:
        """Check if enough time has passed since last trade"""
        if self.last_trade_time is None:
            return True
        
        time_since_last = datetime.now() - self.last_trade_time
        return time_since_last.total_seconds() >= (self.min_time_between_trades_minutes * 60)
    
    def _check_pullback_to_ema(self, prices: List[float]) -> bool:
        """Check if price has pulled back to EMA"""
        if len(prices) < self.pullback_ema_period:
            return False
        
        # Calculate EMA
        df = pd.Series(prices)
        ema = df.ewm(span=self.pullback_ema_period).mean().iloc[-1]
        current_price = prices[-1]
        
        # Check if price is near EMA (within threshold)
        pullback_distance = abs(current_price - ema) / ema
        return pullback_distance <= self.pullback_threshold
    
    def _check_breakout(self, prices: List[float]) -> Tuple[bool, str]:
        """Check for breakout patterns"""
        if len(prices) < self.breakout_lookback:
            return False, 'HOLD'
        
        recent_prices = prices[-self.breakout_lookback:]
        current_price = recent_prices[-1]
        low_price = min(recent_prices[:-1])  # Exclude current price
        high_price = max(recent_prices[:-1])
        
        # Check for upward breakout
        if current_price > high_price * (1 + self.breakout_threshold):
            return True, 'BUY'
        
        # Check for downward breakout
        if current_price < low_price * (1 - self.breakout_threshold):
            return True, 'SELL'
        
        return False, 'HOLD'
    
    def _calculate_atr(self, prices: List[float], period: int = 14) -> float:
        """Calculate Average True Range"""
        if len(prices) < period:
            return 0.0
        
        df = pd.Series(prices)
        high = df
        low = df
        close = df.shift(1)
        
        tr1 = high - low
        tr2 = abs(high - close)
        tr3 = abs(low - close)
        
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = true_range.rolling(window=period).mean().iloc[-1]
        
        return atr if not pd.isna(atr) else 0.0
    
    def _select_best_daily_trades(self, signals: List[TradeSignal]) -> List[TradeSignal]:
        """Select only the best trades for the day"""
        if not self.daily_trade_ranking:
            return signals
        
        # Add to daily signals
        self.daily_signals.extend(signals)
        
        # Sort by confidence and strength (highest first)
        self.daily_signals.sort(key=lambda x: (x.confidence, x.strength), reverse=True)
        
        # Select top quality trades
        best_trades = self.daily_signals[:self.max_daily_quality_trades]
        
        logger.info(f"🎯 Selected {len(best_trades)} best trades from {len(self.daily_signals)} signals")
        
        return best_trades
    
    def _update_price_history(self, market_data: Dict[str, MarketData]):
        """Update price history for all instruments"""
        for instrument, data in market_data.items():
            if instrument in self.instruments:
                # Use mid price (average of bid and ask)
                mid_price = (data.bid + data.ask) / 2
                self.price_history[instrument].append(mid_price)
                
                # Keep only last 100 prices for efficiency
                if len(self.price_history[instrument]) > 100:
                    self.price_history[instrument] = self.price_history[instrument][-100:]
    
    def _generate_trade_signals(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Generate optimized trade signals with enhanced quality filters"""
        self._reset_daily_counters()
        
        # Check daily trade limit
        if self.daily_trade_count >= self.max_trades_per_day:
            return []
        
        # Session-specific guardrail (10:30–14:30 GMT by default)
        session_allowed, risk_multiplier = self._session_window_state()
        if not session_allowed:
            self.last_rejection_reason = "Outside approved gold scalping window."
            logger.info("⏰ Skipping trade: outside approved gold scalping window")
            return []
        if risk_multiplier <= 0:
            self.last_rejection_reason = "Post-cutoff risk multiplier is zero."
            logger.info("⏰ Skipping trade: post-cutoff risk multiplier zeroed")
            return []
        
        # Update price history
        self._update_price_history(market_data)
        
        trade_signals = []
        
        # Session filter
        if self.only_trade_london_ny and not self._is_london_or_ny_session():
            self.last_rejection_reason = "Outside London/NY sessions."
            logger.info("⏰ Skipping trade: outside London/NY sessions")
            return []
        
        # Time between trades filter
        if not self._can_trade_now():
            self.last_rejection_reason = f"Minimum {self.min_time_between_trades_minutes}min gap required."
            logger.info(f"⏰ Skipping trade: minimum {self.min_time_between_trades_minutes}min gap required")
            return []
        
        for instrument in self.instruments:
            if instrument not in market_data or len(self.price_history[instrument]) < 20:
                continue
            
            current_data = market_data[instrument]
            prices = self.price_history[instrument]
            
            # Spread filter
            spread = current_data.ask - current_data.bid
            if spread > self.max_spread:
                self.last_rejection_reason = f"Spread too wide ({spread:.3f})."
                logger.info(f"⏰ Skipping {instrument}: spread too wide ({spread:.3f})")
                continue
            
            # Volatility filter
            recent_prices = prices[-self.volatility_lookback:]
            volatility = np.std(recent_prices) / np.mean(recent_prices)
            if volatility < self.min_volatility:
                self.last_rejection_reason = f"Volatility too low ({volatility:.6f})."
                logger.info(f"⏰ Skipping {instrument}: volatility too low ({volatility:.6f})")
                continue
            
            # ATR filter
            atr = self._calculate_atr(prices)
            if atr < self.min_atr_for_entry:
                self.last_rejection_reason = f"ATR too low ({atr:.2f})."
                logger.info(f"⏰ Skipping {instrument}: ATR too low ({atr:.2f})")
                continue
            
            # Check for breakout
            is_breakout, breakout_direction = self._check_breakout(prices)
            if not is_breakout:
                self.last_rejection_reason = "No breakout detected."
                continue
            
            # Pullback requirement
            if self.require_pullback and not self._check_pullback_to_ema(prices):
                self.last_rejection_reason = "Waiting for pullback."
                logger.info(f"⏰ Waiting for pullback on {instrument}")
                continue
            
            # Multiple confirmations check
            confirmations = 0
            if volatility >= self.min_volatility:
                confirmations += 1
            if atr >= self.min_atr_for_entry:
                confirmations += 1
            if spread <= self.max_spread:
                confirmations += 1
            
            if confirmations < self.min_confirmations:
                self.last_rejection_reason = "Not enough confirmations."
                continue
            
            # Score signal quality components
            quality_score = self._estimate_signal_quality(volatility, atr, spread)
            confidence = max(self.min_signal_strength, min(1.0, volatility * 12))
            volume_score = min(1.0, max(0.1, volatility / max(self.min_volatility, 1e-6) * 0.5))
            adx_estimate = max(18.0, min(50.0, 22.0 + (atr / max(self.min_atr_for_entry, 1e-6)) * 6.5))
            momentum_estimate = min(1.5, max(0.05, volatility * 25))

            # Generate trade signal
            if breakout_direction == 'BUY':
                pip_size = 0.1 if instrument.startswith('XAU') else 0.0001
                units = max(1, int(round(self.base_units * risk_multiplier)))
                trade_signal = TradeSignal(
                    instrument=instrument,
                    side=OrderSide.BUY,
                    units=units,
                    entry_price=current_data.ask,
                    stop_loss=current_data.ask - (self.stop_loss_pips * pip_size),
                    take_profit=current_data.ask + (self.take_profit_pips * pip_size),
                    confidence=confidence,
                    strength=min(1.0, atr / 5.0),  # Scale ATR to strength
                    quality_score=quality_score,
                    metadata={
                        'volatility': volatility,
                        'atr': atr,
                        'spread': spread,
                        'volume_score': volume_score,
                        'adx': adx_estimate,
                        'momentum': momentum_estimate,
                        'session_risk_multiplier': risk_multiplier,
                    },
                    timestamp=datetime.now(),
                    strategy_name=self.name
                )
                setattr(trade_signal, 'volume_score', volume_score)
                setattr(trade_signal, 'adx', adx_estimate)
                setattr(trade_signal, 'momentum', momentum_estimate)
                trade_signals.append(trade_signal)
                logger.info(f"✅ BUY signal generated for {instrument}: volatility={volatility:.6f}, ATR={atr:.2f}")
            
            elif breakout_direction == 'SELL':
                pip_size = 0.1 if instrument.startswith('XAU') else 0.0001
                units = max(1, int(round(self.base_units * risk_multiplier)))
                trade_signal = TradeSignal(
                    instrument=instrument,
                    side=OrderSide.SELL,
                    units=units,
                    entry_price=current_data.bid,
                    stop_loss=current_data.bid + (self.stop_loss_pips * pip_size),
                    take_profit=current_data.bid - (self.take_profit_pips * pip_size),
                    confidence=confidence,
                    strength=min(1.0, atr / 5.0),
                    quality_score=quality_score,
                    metadata={
                        'volatility': volatility,
                        'atr': atr,
                        'spread': spread,
                        'volume_score': volume_score,
                        'adx': adx_estimate,
                        'momentum': momentum_estimate,
                        'session_risk_multiplier': risk_multiplier,
                    },
                    timestamp=datetime.now(),
                    strategy_name=self.name
                )
                setattr(trade_signal, 'volume_score', volume_score)
                setattr(trade_signal, 'adx', adx_estimate)
                setattr(trade_signal, 'momentum', momentum_estimate)
                trade_signals.append(trade_signal)
                logger.info(f"✅ SELL signal generated for {instrument}: volatility={volatility:.6f}, ATR={atr:.2f}")
        
        # Quality filtering and ranking
        if trade_signals:
            trade_signals = self._select_best_daily_trades(trade_signals)
            self.daily_trade_count += len(trade_signals)
            self.last_trade_time = datetime.now()  # Update last trade time
        
            logger.info(f"🚀 Dispatching {len(trade_signals)} quality trades")
            return trade_signals
 
        return []

    def _estimate_signal_quality(self, volatility: float, atr: float, spread: float) -> float:
        """Estimate a 0-100 quality score for a signal using core metrics."""
        vol_component = min(40.0, max(0.0, (volatility / max(self.min_volatility, 1e-6)) * 20.0))
        atr_component = min(40.0, max(0.0, (atr / max(self.min_atr_for_entry, 1e-6)) * 20.0))
        spread_component = max(0.0, min(20.0, (self.max_spread - spread) / max(self.max_spread, 1e-6) * 20.0))
        raw_score = vol_component + atr_component + spread_component
        return min(100.0, raw_score)
    
    def is_strategy_active(self) -> bool:
        """Check if strategy is active"""
        return True  # Always active
    
    def is_trading_hours(self, current_time: Optional[datetime] = None) -> bool:
        """Check if current time is within trading hours"""
        if current_time is None:
            current_time = datetime.now()
        
        # Gold trades 24/7
        return True
    
    def analyze_market(self, market_data: Dict[str, MarketData]) -> List[TradeSignal]:
        """Analyze market and generate trading signals"""
        try:
            signals = self._generate_trade_signals(market_data)
            
            if signals:
                logger.info(f"🎯 {self.name} generated {len(signals)} signals")
                for signal in signals:
                    logger.info(f"   📈 {signal.instrument} {signal.side.value} - Confidence: {signal.confidence:.2f}")
            
            return signals
            
        except Exception as e:
            logger.error(f"❌ {self.name} analysis error: {e}")
            return []
    
    def get_strategy_status(self) -> Dict:
        """Get current strategy status"""
        self._reset_daily_counters()
        
        return {
            'name': self.name,
            'instruments': self.instruments,
            'daily_trades': self.daily_trade_count,
            'max_daily_trades': self.max_trades_per_day,
            'trades_remaining': self.max_trades_per_day - self.daily_trade_count,
            'parameters': {
                'stop_loss_pips': self.stop_loss_pips,
                'take_profit_pips': self.take_profit_pips,
                'min_signal_strength': self.min_signal_strength,
                'min_volatility': self.min_volatility,
                'max_spread': self.max_spread
            },
            'last_update': datetime.now().isoformat()
        }

    def get_status(self) -> Dict:
        """Get current strategy status and last rejection reason."""
        return {
            "name": self.name,
            "last_rejection_reason": self.last_rejection_reason,
            "indicators": {
                "volatility": self.min_volatility,
                "spread": self.max_spread,
                "atr": self.min_atr_for_entry,
                "breakout_threshold": self.breakout_threshold,
            }
        }


    def record_trade_result(self, trade_info: Dict, result: str, pnl: float):
        """Record trade result for learning system (NEW OCT 21, 2025)"""
        if not self.learning_enabled or not self.loss_learner:
            return
        
        if result == 'LOSS':
            self.loss_learner.record_loss(
                instrument=trade_info.get('instrument', 'UNKNOWN'),
                regime=trade_info.get('regime', 'UNKNOWN'),
                adx=trade_info.get('adx', 0.0),
                momentum=trade_info.get('momentum', 0.0),
                volume=trade_info.get('volume', 0.0),
                pnl=pnl,
                conditions=trade_info.get('conditions', {})
            )
        else:
            self.loss_learner.record_win(trade_info.get('instrument', 'UNKNOWN'), pnl)
    
    def get_learning_summary(self) -> Dict:
        """Get learning system performance summary"""
        if not self.learning_enabled or not self.loss_learner:
            return {'enabled': False}
        return {
            'enabled': True,
            'performance': self.loss_learner.get_performance_summary(),
            'avoidance_patterns': self.loss_learner.get_avoidance_list()
        }



    def generate_signals(self, market_data):
        """Generate trading signals based on market data"""
        signals = []
        
        try:
            # Use analyze_market to get signals
            if hasattr(self, 'analyze_market'):
                analysis = self.analyze_market(market_data)
                if analysis and isinstance(analysis, list):
                    signals.extend(analysis)
                elif analysis and hasattr(analysis, 'signals'):
                    signals.extend(analysis.signals)
            
            # If no signals from analyze_market, try to generate basic signals
            if not signals and hasattr(self, 'instruments'):
                for instrument in self.instruments:
                    if instrument in market_data:
                        price_data = market_data[instrument]
                        if price_data and len(price_data) > 5:
                            # Generate a basic signal for testing
                            from src.core.order_manager import TradeSignal, Side
                            signal = TradeSignal(
                                instrument=instrument,
                                side=Side.BUY,  # Basic buy signal for testing
                                entry_price=price_data.bid,
                                stop_loss=price_data.bid * 0.999,  # 0.1% stop loss
                                take_profit=price_data.bid * 1.002,  # 0.2% take profit
                                confidence=0.5,
                                strategy=self.name
                            )
                            signals.append(signal)
                            break  # Only one signal for testing
            
        except Exception as e:
            print(f'Error generating signals in {self.name}: {e}')
        
        return signals
# Global strategy instance
gold_scalping = GoldScalpingStrategy()

def get_gold_scalping_strategy() -> GoldScalpingStrategy:
    """Get the global Gold Scalping strategy instance"""
    return gold_scalping
