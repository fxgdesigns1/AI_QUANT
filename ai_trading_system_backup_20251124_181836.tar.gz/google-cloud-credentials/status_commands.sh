#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="ai-quant-trading"
SERVICE="default"

echo "Setting project to $PROJECT_ID"
gcloud config set project "$PROJECT_ID" >/dev/null

echo "\n== App Engine services =="
gcloud app services list

echo "\n== Versions (service=default) =="
gcloud app versions list --service="$SERVICE" --format="table(version.id,traffic_split,servingStatus,createTime)"

echo "\n== Instances (service=default) ==""
gcloud app instances list --service="$SERVICE" --format="table(id,version,vmStatus,requests,avgLatency)"

echo "\n== Recent logs (200 lines) =="
gcloud app logs read --service="$SERVICE" --limit=200 --format="value(textPayload)" | sed -e "s/^/[LOG] /"

echo "\n== Cloud Build (last 5) =="
gcloud builds list --limit=5 --format="table(id,status,createTime,finishTime,images)"

echo "\n== Uptime checks (if any) =="
gcloud monitoring uptime list-configs || true

echo "\nDone."
