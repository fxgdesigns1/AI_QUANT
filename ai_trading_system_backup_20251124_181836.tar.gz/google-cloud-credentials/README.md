# Google Cloud Access Guide (No Secrets)

This folder contains non-sensitive information and commands to access and manage your Google Cloud project safely without storing credentials in the repo.

Project context
- Project ID: ai-quant-trading
- Region: us-central1
- App Engine URL: https://ai-quant-trading.uc.r.appspot.com
- Active service: default

What this folder includes
- context.json: Non-sensitive project metadata and URLs
- status_commands.sh: Read-only commands to check status and logs

How to sign in (interactive)
1) gcloud auth login
2) gcloud config set project ai-quant-trading
3) Optional (Application Default Credentials for local tools): gcloud auth application-default login

Recommended security
- Enable 2-Step Verification on your Google account
- Keep recovery methods updated (phone, backup codes)
- Use least-privilege roles for service accounts
- Avoid committing service account keys; prefer Workload Identity or user auth

Service account (optional, only if needed)
- Create in Console: IAM & Admin > Service Accounts
- Grant minimal roles needed (e.g., App Engine Viewer/Deployer)
- If downloading a key: store the JSON key outside Git; restrict permissions (chmod 600)

Health endpoints
- Root dashboard: /
- Status JSON: /api/status (observed 200 responses in logs)

Troubleshooting
- List services: gcloud app services list
- List versions: gcloud app versions list --service=default
- Instances: gcloud app instances list --service=default
- Logs: gcloud app logs read --service=default --limit=200

Note
This directory intentionally contains no secrets. Keep any keys or tokens in your password manager or a secure secrets store.


