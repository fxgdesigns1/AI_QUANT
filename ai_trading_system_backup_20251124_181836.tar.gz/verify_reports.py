import requests
import os
from dotenv import load_dotenv

# --- IMPORTANT ---
# This script assumes it is run from the project's root directory
# and that the main system's oanda_config.env is available.
# We load it to get the correct Telegram credentials.
CONFIG_PATH = "/Users/mac/quant_system_clean/google-cloud-trading-system/oanda_config.env"
if os.path.exists(CONFIG_PATH):
    load_dotenv(dotenv_path=CONFIG_PATH)
else:
    print("❌ ERROR: Main configuration file not found. Cannot get Telegram credentials.")
    exit(1)

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def send_telegram_message(message):
    """Sends a message to Telegram."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("❌ ERROR: Telegram credentials not found in the environment config.")
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    params = {'chat_id': TELEGRAM_CHAT_ID, 'text': message, 'parse_mode': 'Markdown'}
    try:
        response = requests.post(url, data=params)
        response.raise_for_status()
        print(f"✅ Message sent successfully.")
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to send message: {e}")

def generate_placeholder_summary(period):
    """Generates a sample summary for verification purposes."""
    # In the real system, this data would be calculated from trade history.
    if period == 'daily':
        return "Performance summary for the last day:\n- Trades: 5\n- Win Rate: 80%\n- P&L: +$1,250"
    elif period == 'weekly':
        return "Performance summary for the last week:\n- Trades: 25\n- Win Rate: 75%\n- P&L: +$5,800"
    elif period == 'monthly':
        return "Performance summary for the last month:\n- Trades: 110\n- Win Rate: 78%\n- P&L: +$22,300"
    return "No data."

def run_verification():
    """Sends one of each report type to Telegram."""
    print("--- Verifying Reporting System ---")
    
    # Send Daily Briefing
    daily_summary = generate_placeholder_summary('daily')
    daily_title = "📈 Daily Performance Briefing (Verification)"
    send_telegram_message(f"{daily_title}\n\n{daily_summary}")

    # Send Weekly Briefing
    weekly_summary = generate_placeholder_summary('weekly')
    weekly_title = "📊 Weekly Performance Briefing (Verification)"
    send_telegram_message(f"{weekly_title}\n\n{weekly_summary}")

    # Send Monthly Briefing
    monthly_summary = generate_placeholder_summary('monthly')
    monthly_title = "🏆 Monthly Performance Briefing (Verification)"
    send_telegram_message(f"{monthly_title}\n\n{monthly_summary}")

    print("--- Verification Complete. If successful, check Telegram. ---")

if __name__ == "__main__":
    run_verification()
