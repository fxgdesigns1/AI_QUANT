#!/usr/bin/env python3
"""
News aggregation utilities ported from the temporary prototype.

Used by the dashboard for economic calendar awareness and Marketaux usage
tracking.  The implementation remains synchronous (requests) because the
providers' SDKs are HTTP-based and the dashboard refresh cycle runs in a
threaded background loop.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class NewsEvent:
    def __init__(
        self,
        time_utc: datetime,
        country: str,
        title: str,
        impact: str,
        currency: str,
        forecast: Optional[float],
        actual: Optional[float],
    ):
        self.time_utc = time_utc
        self.country = country
        self.title = title
        self.impact = impact
        self.currency = currency
        self.forecast = forecast
        self.actual = actual


class NewsManager:
    def __init__(self) -> None:
        self.tradingeconomics_key = os.getenv("TRADINGECONOMICS_KEY", "")
        self.finnhub_key = os.getenv("FINNHUB_KEY", "")
        self.marketaux_keys = self._load_marketaux_keys()
        self.marketaux_key = self.marketaux_keys[0] if self.marketaux_keys else ""
        self._marketaux_index = 0
        self.newsapi_key = os.getenv("NEWSAPI_KEY", "")
        self.cached_events: List[NewsEvent] = []
        self.last_refresh: Optional[datetime] = None
        self.last_sentiment: Optional[Dict[str, Any]] = None
        self.last_sentiment_time: Optional[datetime] = None
        self.sentiment_cache_ttl = max(1, int(os.getenv("MARKETAUX_CACHE_TTL_MINUTES", "2")))
        status_path_env = os.getenv("MARKETAUX_STATUS_PATH")
        if status_path_env:
            self.marketaux_snapshot_path = Path(status_path_env)
        else:
            runtime_root = Path(os.getenv("RUNTIME_DIR", Path.cwd() / "runtime"))
            self.marketaux_snapshot_path = runtime_root / "marketaux_usage.json"
        self.marketaux_stats: Dict[str, Dict[str, Any]] = {}
        self.marketaux_alerts: List[Dict[str, Any]] = []
        
        # Enhanced persistent article cache (keep articles for 7 days)
        self.article_cache_ttl_days = int(os.getenv("NEWS_CACHE_DAYS", "7"))
        runtime_root = Path(os.getenv("RUNTIME_DIR", Path.cwd() / "runtime"))
        self.article_cache_path = runtime_root / "news_articles_cache.json"
        self.article_cache: Dict[str, Dict[str, Any]] = {}  # Key: article URL/ID, Value: article data
        self.last_api_call_time: Optional[datetime] = None
        self.min_api_call_interval_seconds = int(os.getenv("NEWS_MIN_API_INTERVAL_SECONDS", "300"))  # 5 min default
        
        # Legacy cache for backward compatibility
        self.last_articles: List[Dict[str, Any]] = []
        self.last_articles_time: Optional[datetime] = None
        
        self._load_article_cache()
        # Optional cap for maximum articles fetched in a single call (environment-driven)
        max_fetch_articles_env = os.getenv("NEWS_FETCH_MAX_ARTICLES", "")
        try:
            self._max_fetch_articles_cap = int(max_fetch_articles_env) if max_fetch_articles_env else 1000
        except Exception:
            self._max_fetch_articles_cap = 1000
        # Log the cap for observability
        logger.info(f"News fetch cap set to {self._max_fetch_articles_cap} articles per call")
        self._initialize_marketaux_stats()

    def _fetch_articles_with_published_after(self, limit: int, published_after: datetime, max_age_hours: int = 24) -> List[Dict[str, Any]]:
        """
        Internal helper to fetch articles from Marketaux with an explicit published_after timestamp.
        Returns newly cached articles (not already present in cache).
        """
        new_articles: List[Dict[str, Any]] = []
        if not self.marketaux_keys:
            return new_articles
        key = self._next_marketaux_key()
        if not key:
            return new_articles
        try:
            url = (
                "https://api.marketaux.com/v1/news/all?"
                f"filter_entities=true&limit={limit}&sort=published_desc&"
                f"published_after={published_after.strftime('%Y-%m-%dT%H:%M:%S')}&"
                "language=en&countries=us,gb,eu&"
                "query=forex OR currency OR gold"
            )
            response = requests.get(url, timeout=10, params={"api_token": key})
            if response.status_code == 200:
                payload = response.json().get("data", [])
                now = datetime.utcnow()
                for entry in payload:
                    article_id = entry.get("uuid") or entry.get("url") or entry.get("title", "")
                    if article_id and article_id not in self.article_cache:
                        sentiment_score = None
                        for key_name in ("overall_sentiment_score", "sentiment_score", "sentiment"):
                            val = entry.get(key_name)
                            if isinstance(val, (int, float)):
                                sentiment_score = float(val)
                                break
                        if sentiment_score is None:
                            label = (entry.get("overall_sentiment_label") or entry.get("sentiment_label") or "").lower()
                            if label in ("bullish", "positive"):
                                sentiment_score = 0.6
                            elif label in ("bearish", "negative"):
                                sentiment_score = -0.6
                            else:
                                sentiment_score = 0.0
                        entities = entry.get("entities", []) or []
                        symbols = entry.get("symbols") or entry.get("tickers") or []
                        if isinstance(symbols, list):
                            for sym in symbols:
                                entities.append({"symbol": sym, "name": sym})
                        article_data = {
                            "title": entry.get("title"),
                            "summary": entry.get("summary"),
                            "published_at": entry.get("published_at"),
                            "url": entry.get("url"),
                            "source": entry.get("source"),
                            "sentiment": sentiment_score if isinstance(sentiment_score, (int, float)) else None,
                            "sentiment_score": sentiment_score,
                            "sentiment_label": (entry.get("overall_sentiment_label") or entry.get("sentiment_label")),
                            "entities": entities,
                            "cached_at": now.isoformat(),
                        }
                        self.article_cache[article_id] = article_data
                        new_articles.append(article_data)
                self._save_article_cache()
                self.last_api_call_time = datetime.utcnow()
                self._record_marketaux_usage(key, 200, f"ok ({len(payload)} articles, {len(new_articles)} new)", len(payload))
            else:
                try:
                    detail_raw = response.json()
                except ValueError:
                    detail_raw = response.text
                detail_str = self._detail_to_str(detail_raw)
                self._record_marketaux_usage(key, response.status_code, detail_str, 0)
        except Exception as exc:
            self._record_marketaux_usage(key, None, str(exc), 0)
        return new_articles

    def fetch_latest_articles_staggered(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Fetch articles in multiple staggered segments within the current window to generate denser sentiment signals.
        Each segment dict can include:
          - offset_minutes: int (how far back from now to start this slice)
          - limit: int (articles to fetch in this slice)
          - max_age_hours: int (optional)
        Returns combined cached articles within the usual window rules.
        """
        from datetime import datetime, timedelta
        now = datetime.utcnow()
        total_new: List[Dict[str, Any]] = []
        for segment in segments:
            offset = int(segment.get("offset_minutes", 0))
            limit = int(segment.get("limit", 30))
            max_age_hours = int(segment.get("max_age_hours", 24))
            published_after = now - timedelta(minutes=offset)
            new_for_segment = self._fetch_articles_with_published_after(limit, published_after, max_age_hours)
            total_new.extend(new_for_segment)
        # Return a merged view from the cache for the window (use the largest max_age_hours requested)
        max_window = max((int(s.get("max_age_hours", 24)) for s in segments), default=24)
        return self._get_cached_articles_in_window(max_age_hours=max_window)

    def _simple_sentiment_from_text(self, title: str, summary: str) -> float:
        """
        Lightweight lexical sentiment fallback when provider sentiment is absent.
        Returns a score in [-1.0, 1.0].
        """
        try:
            text = f"{title} {summary}".lower()
            if not text.strip():
                return 0.0
            positive = [
                "rally", "gain", "gains", "bull", "bullish", "optimism", "optimistic",
                "beat", "beats", "strong", "strength", "surge", "surges", "expands",
                "hawkish", "risk-on", "advance", "advances"
            ]
            negative = [
                "fall", "falls", "drop", "drops", "bear", "bearish", "pessimism", "pessimistic",
                "miss", "misses", "weak", "weakness", "slump", "slumps", "contracts",
                "dovish", "risk-off", "decline", "declines"
            ]
            score = 0
            for w in positive:
                if w in text:
                    score += 1
            for w in negative:
                if w in text:
                    score -= 1
            if score == 0:
                return 0.0
            # Normalize softly
            return max(-1.0, min(1.0, score / 5.0))
        except Exception:
            return 0.0

    def _load_marketaux_keys(self) -> List[str]:
        keys_env = os.getenv("MARKETAUX_KEYS", "")
        keys: List[str] = []
        if keys_env:
            for part in keys_env.replace(";", ",").split(","):
                token = part.strip()
                if token:
                    keys.append(token)
        single = os.getenv("MARKETAUX_KEY", "").strip()
        if single and single not in keys:
            keys.append(single)
        return keys

    def _load_article_cache(self) -> None:
        """Load persistent article cache from disk."""
        try:
            if self.article_cache_path.exists():
                data = json.loads(self.article_cache_path.read_text(encoding="utf-8"))
                self.article_cache = data.get("articles", {})
                # Clean old articles (older than cache TTL)
                self._clean_old_articles()
                logger.info(f"Loaded {len(self.article_cache)} cached articles from disk")
            else:
                logger.info("No existing article cache found, starting fresh")
        except Exception as exc:
            logger.warning(f"Failed to load article cache: {exc}")
            self.article_cache = {}

    def _save_article_cache(self) -> None:
        """Save article cache to disk."""
        try:
            self.article_cache_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "updated_at": datetime.utcnow().isoformat(),
                "article_count": len(self.article_cache),
                "articles": self.article_cache,
            }
            tmp_path = self.article_cache_path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp_path.replace(self.article_cache_path)
        except Exception as exc:
            logger.warning(f"Failed to save article cache: {exc}")

    def _clean_old_articles(self) -> None:
        """Remove articles older than cache TTL."""
        now = datetime.utcnow()
        cutoff = now - timedelta(days=self.article_cache_ttl_days)
        removed = 0
        for article_id in list(self.article_cache.keys()):
            article = self.article_cache[article_id]
            try:
                published_str = article.get("published_at") or article.get("cached_at")
                if published_str:
                    published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                    if published < cutoff:
                        del self.article_cache[article_id]
                        removed += 1
            except Exception:
                # If we can't parse date, keep the article for safety
                continue
        if removed > 0:
            logger.info(f"Cleaned {removed} old articles from cache")

    def _get_latest_cached_article_date(self) -> Optional[datetime]:
        """Get the publication date of the most recent cached article."""
        latest = None
        for article in self.article_cache.values():
            try:
                published_str = article.get("published_at")
                if published_str:
                    published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                    if latest is None or published > latest:
                        latest = published
            except Exception:
                continue
        return latest

    def _should_make_api_call(self) -> bool:
        """Check if enough time has passed since last API call."""
        if self.last_api_call_time is None:
            return True
        elapsed = (datetime.utcnow() - self.last_api_call_time).total_seconds()
        return elapsed >= self.min_api_call_interval_seconds

    def _initialize_marketaux_stats(self) -> None:
        active_keys = set(self.marketaux_keys)
        for stale_key in list(self.marketaux_stats.keys()):
            if stale_key not in active_keys:
                self.marketaux_stats.pop(stale_key, None)
        for key in self.marketaux_keys:
            if key not in self.marketaux_stats:
                self.marketaux_stats[key] = {
                    "last_status": "unused",
                    "last_status_code": None,
                    "last_message": "",
                    "last_used": None,
                    "success_count": 0,
                    "error_count": 0,
                    "total_calls": 0,
                    "last_data_count": 0,
                    "usage_limit": False,
                    "throttled": False,
                    "notified_usage_limit": False,
                }
        self._write_marketaux_snapshot()

    def _next_marketaux_key(self) -> Optional[str]:
        if not self.marketaux_keys:
            return None
        key = self.marketaux_keys[self._marketaux_index]
        self._marketaux_index = (self._marketaux_index + 1) % len(self.marketaux_keys)
        self.marketaux_key = key
        return key

    @staticmethod
    def _mask_key(key: str) -> str:
        if len(key) <= 8:
            return key
        return f"{key[:4]}…{key[-4:]}"

    @staticmethod
    def _detail_to_str(detail: Any) -> str:
        """Convert API response details to string for logging."""
        if detail is None:
            return ""
        if isinstance(detail, (dict, list)):
            try:
                return json.dumps(detail, ensure_ascii=False)
            except Exception:
                return str(detail)
        return str(detail)

    def _record_marketaux_usage(self, key: str, status_code: Optional[int], message: str, data_count: int) -> None:
        stats = self.marketaux_stats.setdefault(
            key,
            {
                "last_status": "unused",
                "last_status_code": None,
                "last_message": "",
                "last_used": None,
                "success_count": 0,
                "error_count": 0,
                "total_calls": 0,
                "last_data_count": 0,
                "usage_limit": False,
                "throttled": False,
                "notified_usage_limit": False,
            },
        )

        stats["total_calls"] += 1
        stats["last_used"] = datetime.utcnow().isoformat()
        stats["last_status_code"] = status_code
        stats["last_message"] = message
        stats["last_data_count"] = data_count

        if status_code == 200:
            stats["last_status"] = "ok"
            stats["success_count"] += 1
            stats["usage_limit"] = False
            stats["throttled"] = False
            stats["notified_usage_limit"] = False
        elif status_code in (402, 403):
            stats["last_status"] = "usage_limit"
            stats["error_count"] += 1
            stats["usage_limit"] = True
            stats["throttled"] = False
            # Only send alert ONCE per key until it recovers
            if not stats.get("notified_usage_limit"):
                self.marketaux_alerts.append(
                    {
                        "key": key,
                        "masked_key": self._mask_key(key),
                        "status": "usage_limit",
                        "status_code": status_code,
                        "message": message,
                        "timestamp": stats["last_used"],
                    }
                )
                stats["notified_usage_limit"] = True
        elif status_code == 429:
            stats["last_status"] = "throttled"
            stats["error_count"] += 1
            stats["usage_limit"] = False
            stats["throttled"] = True
            # Only send throttle alerts occasionally, not every time
            if not stats.get("notified_usage_limit"):
                self.marketaux_alerts.append(
                    {
                        "key": key,
                        "masked_key": self._mask_key(key),
                        "status": "throttled",
                        "status_code": status_code,
                        "message": message,
                        "timestamp": stats["last_used"],
                    }
                )
                stats["notified_usage_limit"] = True
        elif status_code is None:
            stats["last_status"] = "exception"
            stats["error_count"] += 1
        else:
            stats["last_status"] = "error"
            stats["error_count"] += 1

        self._write_marketaux_snapshot()

    def _write_marketaux_snapshot(self) -> None:
        try:
            payload = {"updated_at": datetime.utcnow().isoformat(), "keys": []}
            for key, stats in self.marketaux_stats.items():
                payload["keys"].append(
                    {
                        "key": key,
                        "masked_key": self._mask_key(key),
                        "last_status": stats["last_status"],
                        "last_status_code": stats["last_status_code"],
                        "last_message": stats["last_message"],
                        "last_used": stats["last_used"],
                        "total_calls": stats["total_calls"],
                        "success_count": stats["success_count"],
                        "error_count": stats["error_count"],
                        "last_data_count": stats["last_data_count"],
                        "usage_limit": stats["usage_limit"],
                        "throttled": stats["throttled"],
                    }
                )
            snapshot_dir = self.marketaux_snapshot_path.parent
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = self.marketaux_snapshot_path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            tmp_path.replace(self.marketaux_snapshot_path)
        except Exception as exc:
            logger.warning("Marketaux snapshot write failed: %s", exc)

    def get_marketaux_usage_summary(self) -> List[Dict[str, Any]]:
        summary: List[Dict[str, Any]] = []
        for key, stats in self.marketaux_stats.items():
            summary.append(
                {
                    "key": self._mask_key(key),
                    "raw_key": key,
                    "status": stats["last_status"],
                    "status_code": stats["last_status_code"],
                    "last_used": stats["last_used"],
                    "message": stats["last_message"],
                    "total_calls": stats["total_calls"],
                    "success_count": stats["success_count"],
                    "error_count": stats["error_count"],
                    "last_data_count": stats["last_data_count"],
                    "usage_limit": stats["usage_limit"],
                    "throttled": stats["throttled"],
                }
            )
        summary.sort(key=lambda item: item["raw_key"])
        return summary

    def pop_marketaux_alerts(self) -> List[Dict[str, Any]]:
        alerts = list(self.marketaux_alerts)
        self.marketaux_alerts.clear()
        return alerts

    def is_enabled(self) -> bool:
        """Check if any news sources are configured (backward compatibility)."""
        return bool(
            self.tradingeconomics_key 
            or self.finnhub_key 
            or self.marketaux_keys 
            or self.newsapi_key
        )

    def refresh_calendar(self) -> None:
        events: List[NewsEvent] = []
        now = datetime.utcnow()
        start = (now - timedelta(hours=1)).strftime("%Y-%m-%d")
        end = (now + timedelta(days=1)).strftime("%Y-%m-%d")

        if self.tradingeconomics_key:
            try:
                te_url = (
                    f"https://api.tradingeconomics.com/calendar?d1={start}&d2={end}&format=json&c={self.tradingeconomics_key}"
                )
                response = requests.get(te_url, timeout=10)
                if response.status_code == 200:
                    for event in response.json():
                        try:
                            when = datetime.strptime(event.get("Date", ""), "%Y-%m-%dT%H:%M:%S")
                            events.append(
                                NewsEvent(
                                    time_utc=when,
                                    country=event.get("Country", ""),
                                    title=event.get("Event", ""),
                                    impact=(event.get("Importance", "") or "").lower(),
                                    currency=event.get("Currency", ""),
                                    forecast=self._to_float(event.get("Forecast")),
                                    actual=self._to_float(event.get("Actual")),
                                )
                            )
                        except Exception:
                            continue
            except Exception as exc:
                logger.warning("TradingEconomics calendar fetch failed: %s", exc)

        if self.finnhub_key:
            try:
                fh_url = f"https://finnhub.io/api/v1/calendar/economic?from={start}&to={end}&token={self.finnhub_key}"
                response = requests.get(fh_url, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    for event in data.get("economicCalendar", []):
                        try:
                            date_str = event.get("time", "") or f"{event.get('date','')} 12:00:00"
                            when = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                            events.append(
                                NewsEvent(
                                    time_utc=when,
                                    country=event.get("country", ""),
                                    title=event.get("event", ""),
                                    impact=(event.get("impact", "") or "").lower(),
                                    currency=event.get("currency", ""),
                                    forecast=self._to_float(event.get("estimate")),
                                    actual=self._to_float(event.get("actual")),
                                )
                            )
                        except Exception:
                            continue
            except Exception as exc:
                logger.warning("Finnhub calendar fetch failed: %s", exc)

        self.cached_events = sorted(events, key=lambda evt: evt.time_utc)
        self.last_refresh = datetime.utcnow()

    @staticmethod
    def _to_float(value: Any) -> Optional[float]:
        try:
            if value is None:
                return None
            return float(value)
        except Exception:
            return None

    def get_upcoming_events(
        self,
        within_minutes: int = 360,
        include_impacts: Optional[List[str]] = None,
    ) -> List[NewsEvent]:
        if self.last_refresh is None or (datetime.utcnow() - self.last_refresh) > timedelta(minutes=5):
            self.refresh_calendar()
        impacts = [impact.lower() for impact in (include_impacts or ["high", "importance:high", "medium", "importance:medium"])]
        now = datetime.utcnow()
        horizon = now + timedelta(minutes=within_minutes)
        upcoming: List[NewsEvent] = []
        for event in self.cached_events:
            if event.time_utc < now or event.time_utc > horizon:
                continue
            impact = (event.impact or "").lower()
            if impacts and not any(level in impact for level in impacts):
                continue
            upcoming.append(event)
        return upcoming

    def get_upcoming_high_impact(self, within_minutes: int = 60) -> List[NewsEvent]:
        """Get upcoming high-impact events (backward compatibility)."""
        return self.get_upcoming_events(
            within_minutes=within_minutes,
            include_impacts=["high", "importance:high"]
        )

    def _all_keys_exhausted(self) -> bool:
        """Check if all Marketaux keys are at usage limit."""
        if not self.marketaux_keys:
            return True
        return all(
            self.marketaux_stats.get(key, {}).get("usage_limit", False)
            for key in self.marketaux_keys
        )

    def fetch_latest_articles(self, limit: int = 10, max_age_hours: int = 24, force_api: bool = False, stagger_index: int = 0, stagger_step_minutes: int = 60) -> List[Dict[str, Any]]:
        """
        Fetch articles with intelligent caching strategy:
        1. First check persistent cache (up to 7 days old)
        2. Only call API if: sufficient time passed AND we need newer articles
        3. Only fetch articles published AFTER our latest cached article
        4. Deduplicate and merge with existing cache
        """
        now = datetime.utcnow()
        # Apply staggered time window if requested to increase signal density
        if stagger_index and stagger_step_minutes:
            offset_minutes = stagger_index * stagger_step_minutes
            # We'll apply the offset to the calculated published_after window
            # (the api call will reflect this offset below after its calculation)
            # Note: actual offset application is done on published_after after it's computed
            _STAGGER_APPLY = offset_minutes
        else:
            _STAGGER_APPLY = 0
        # Enforce per-call cap if a higher limit was requested
        if hasattr(self, "_max_fetch_articles_cap"):
            limit = min(limit, self._max_fetch_articles_cap)
        
        # Step 1: Get articles from persistent cache
        cached_articles = self._get_cached_articles_in_window(max_age_hours)
        
        # Step 2: Decide if we need to call API
        should_call_api = (
            (force_api or self._should_make_api_call()) and 
            not self._all_keys_exhausted() and
            len(cached_articles) < limit  # Only if we don't have enough cached
        )
        
        if not should_call_api:
            reason = (
                "keys exhausted" if self._all_keys_exhausted() 
                else f"recent API call ({(now - self.last_api_call_time).total_seconds():.0f}s ago)" 
                if self.last_api_call_time
                else "cache sufficient"
            )
            logger.info(f"Using {len(cached_articles)} cached articles ({reason})")
            return cached_articles[:limit]
        
        # Step 3: Determine what time range to fetch (only NEW articles)
        latest_cached = self._get_latest_cached_article_date()
        if latest_cached:
            # Fetch only articles newer than our latest cached article
            published_after = latest_cached - timedelta(minutes=5)  # 5 min overlap for safety
            if _STAGGER_APPLY:
                published_after -= timedelta(minutes=_STAGGER_APPLY)
            logger.info(f"Fetching articles published after {published_after.isoformat()}")
        else:
            # No cache, fetch last 24 hours
            published_after = now - timedelta(hours=max_age_hours)
            if _STAGGER_APPLY:
                published_after -= timedelta(minutes=_STAGGER_APPLY)
            logger.info("No cached articles, fetching last 24 hours")

        # Step 4: Make API call for NEW articles only
        new_articles_count = 0
        if self.marketaux_keys:
            attempts = len(self.marketaux_keys)
            for _ in range(attempts):
                key = self._next_marketaux_key()
                if not key:
                    break
                # Skip this key if it's at usage limit
                if self.marketaux_stats.get(key, {}).get("usage_limit", False):
                    continue
                try:
                    url = (
                        "https://api.marketaux.com/v1/news/all?"
                        f"filter_entities=true&limit={limit}&sort=published_desc&"
                        f"published_after={published_after.strftime('%Y-%m-%dT%H:%M:%S')}&"
                        "language=en&countries=us,gb,eu,jp&"
                        "topics=forex,fx,currency,currencies,foreign%20exchange&"
                        "query=EURUSD OR GBPUSD OR USDJPY OR XAUUSD OR forex OR currency OR dollar OR euro OR sterling OR yen OR gold"
                    )
                    response = requests.get(url, timeout=10, params={"api_token": key})
                    if response.status_code == 200:
                        payload = response.json().get("data", [])
                        # Add new articles to persistent cache
                        for entry in payload:
                            article_id = entry.get("uuid") or entry.get("url") or entry.get("title", "")
                            if article_id and article_id not in self.article_cache:
                                # Normalize sentiment fields from various Marketaux shapes
                                sentiment_score = None
                                for key_name in ("overall_sentiment_score", "sentiment_score", "sentiment"):
                                    val = entry.get(key_name)
                                    if isinstance(val, (int, float)):
                                        sentiment_score = float(val)
                                        break
                                if sentiment_score is None:
                                    label = (entry.get("overall_sentiment_label") or entry.get("sentiment_label") or "").lower()
                                    if label in ("bullish", "positive"):
                                        sentiment_score = 0.6
                                    elif label in ("bearish", "negative"):
                                        sentiment_score = -0.6
                                    elif label in ("neutral", ""):
                                        sentiment_score = 0.0
                                entities = entry.get("entities", []) or []
                                # Some payloads expose tickers/symbols separately
                                symbols = entry.get("symbols") or entry.get("tickers") or []
                                if isinstance(symbols, list):
                                    for sym in symbols:
                                        entities.append({"symbol": sym, "name": sym})
                                article_data = {
                                    "title": entry.get("title"),
                                    "summary": entry.get("summary"),
                                    "published_at": entry.get("published_at"),
                                    "url": entry.get("url"),
                                    "source": entry.get("source"),
                                    "sentiment": sentiment_score if isinstance(sentiment_score, (int, float)) else None,
                                    "sentiment_score": sentiment_score,
                                    "sentiment_label": (entry.get("overall_sentiment_label") or entry.get("sentiment_label")),
                                    "entities": entities,
                                    "cached_at": now.isoformat(),
                                }
                                self.article_cache[article_id] = article_data
                                new_articles_count += 1
                        
                        self._save_article_cache()
                        self.last_api_call_time = now
                        self._record_marketaux_usage(key, 200, f"ok ({len(payload)} articles, {new_articles_count} new)", len(payload))
                        logger.info(f"API call successful: {len(payload)} articles fetched, {new_articles_count} new, {len(self.article_cache)} total cached")
                        break
                    else:
                        try:
                            detail_raw = response.json()
                        except ValueError:
                            detail_raw = response.text
                        detail_str = self._detail_to_str(detail_raw)
                        self._record_marketaux_usage(key, response.status_code, detail_str, 0)
                        continue
                except Exception as exc:
                    self._record_marketaux_usage(key, None, str(exc), 0)
                    continue

        # Optional fallback provider: NewsAPI if Marketaux yielded nothing new
        if new_articles_count == 0 and self.newsapi_key:
            try:
                na_url = (
                    "https://newsapi.org/v2/everything?"
                    "language=en&sortBy=publishedAt&"
                    f"pageSize={limit}&"
                    "q=(EURUSD OR GBPUSD OR USDJPY OR XAUUSD OR forex OR currency OR dollar OR euro OR sterling OR yen OR gold)"
                )
                resp = requests.get(na_url, timeout=10, headers={"X-Api-Key": self.newsapi_key})
                if resp.status_code == 200:
                    items = resp.json().get("articles", [])
                    for entry in items:
                        article_id = entry.get("url") or entry.get("title", "")
                        if article_id and article_id not in self.article_cache:
                            published_at = entry.get("publishedAt")
                            # Basic lexical sentiment from title/description
                            title = entry.get("title") or ""
                            summary = entry.get("description") or ""
                            sentiment_score = self._simple_sentiment_from_text(title, summary)
                            entities = []
                            article_data = {
                                "title": title,
                                "summary": summary,
                                "published_at": published_at,
                                "url": entry.get("url"),
                                "source": (entry.get("source") or {}).get("name"),
                                "sentiment": sentiment_score,
                                "sentiment_score": sentiment_score,
                                "sentiment_label": None,
                                "entities": entities,
                                "cached_at": now.isoformat(),
                            }
                            self.article_cache[article_id] = article_data
                            new_articles_count += 1
                    if new_articles_count > 0:
                        self._save_article_cache()
                        logger.info(f"NewsAPI fallback added {new_articles_count} new articles to cache")
                else:
                    logger.info(f"NewsAPI fallback returned {resp.status_code}")
            except Exception as exc:
                logger.warning(f"NewsAPI fallback failed: {exc}")

        # Step 5: Return merged results from cache (now includes any new articles)
        final_articles = self._get_cached_articles_in_window(max_age_hours)
        logger.info(f"Returning {len(final_articles[:limit])} articles (cache: {len(self.article_cache)})")
        
        # Update legacy cache for backward compatibility
        self.last_articles = final_articles[:limit]
        self.last_articles_time = now
        return final_articles[:limit]

    def _get_cached_articles_in_window(self, max_age_hours: int) -> List[Dict[str, Any]]:
        """Get articles from cache that are within the time window."""
        now = datetime.utcnow()
        cutoff = now - timedelta(hours=max_age_hours)
        articles = []
        
        for article in self.article_cache.values():
            try:
                published_str = article.get("published_at")
                if published_str:
                    published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                    if published >= cutoff:
                        articles.append(article)
            except Exception:
                # If we can't parse date, include it anyway
                articles.append(article)
        
        # Sort by published date, newest first
        articles.sort(
            key=lambda x: x.get("published_at", ""), 
            reverse=True
        )
        return articles

    def fetch_sentiment(self, window_minutes: int = 60) -> Optional[Dict[str, Any]]:
        """
        Fetch sentiment from CACHED articles - no API call needed!
        This uses the persistent article cache, so it's free and fast.
        """
        try:
            now = datetime.utcnow()
            # Use 30 minute cache for calculated sentiment
            ttl = 30
            if self.last_sentiment and self.last_sentiment_time and (now - self.last_sentiment_time) < timedelta(minutes=ttl):
                return self.last_sentiment

            # Calculate sentiment from cached articles
            total_score = 0.0
            total_count = 0
            entities: Dict[str, int] = {"USD": 0, "EUR": 0, "GBP": 0, "JPY": 0, "XAU": 0}
            
            # Get articles from cache within the window
            window_hours = window_minutes / 60.0
            cached_articles = self._get_cached_articles_in_window(max_age_hours=int(window_hours) + 1)
            
            cutoff = now - timedelta(minutes=window_minutes)
            articles_used = 0
            
            for article in cached_articles:
                try:
                    # Check if article is within time window
                    published_str = article.get("published_at")
                    if published_str:
                        published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                        # Normalize to naive UTC for comparison
                        if published.tzinfo is not None:
                            published = published.replace(tzinfo=None)
                        if published < cutoff:
                            continue
                    
                    # Extract sentiment score
                    score = article.get("sentiment")
                    if isinstance(score, (int, float)):
                        total_score += float(score)
                        total_count += 1
                    else:
                        # Fallback: compute a simple sentiment from text if provider score absent
                        fallback = self._simple_sentiment_from_text(article.get("title", "") or "", article.get("summary", "") or "")
                        if fallback != 0.0:
                            total_score += fallback
                            total_count += 1
                    
                    # Count entity mentions
                    for ent in article.get("entities") or []:
                        text = f"{(ent.get('symbol') or '').upper()} {(ent.get('name') or '').upper()}"
                        if "USD" in text:
                            entities["USD"] += 1
                        if "EUR" in text:
                            entities["EUR"] += 1
                        if "GBP" in text:
                            entities["GBP"] += 1
                        if "JPY" in text:
                            entities["JPY"] += 1
                        if "GOLD" in text or "XAU" in text:
                            entities["XAU"] += 1
                    # Also scan title/summary for common FX tokens
                    ts = f"{article.get('title','')} {article.get('summary','')}".upper()
                    if any(tok in ts for tok in ("USD", "DOLLAR")):
                        entities["USD"] += 1
                    if "EUR" in ts:
                        entities["EUR"] += 1
                    if "GBP" in ts or "STERLING" in ts:
                        entities["GBP"] += 1
                    if "JPY" in ts or "YEN" in ts:
                        entities["JPY"] += 1
                    if "GOLD" in ts or "XAU" in ts:
                        entities["XAU"] += 1
                    
                    articles_used += 1
                except Exception:
                    continue
            
            # If we had zero usable cached articles in the requested window,
            # perform a one-off live fetch to populate the cache and retry.
            if articles_used == 0:
                logger.info(f"No cached articles in {window_minutes}min window; fetching fresh articles to populate cache")
                window_hours = max(1, int((window_minutes + 59) // 60) + 1)  # round up and add buffer
                try:
                    self.fetch_latest_articles(limit=20, max_age_hours=window_hours, force_api=True)
                except Exception as exc:
                    logger.warning(f"Live fetch to populate cache failed: {exc}")
                # Recompute from refreshed cache
                total_score = 0.0
                total_count = 0
                entities = {"USD": 0, "EUR": 0, "GBP": 0, "JPY": 0, "XAU": 0}
                articles_used = 0
                cached_articles = self._get_cached_articles_in_window(max_age_hours=window_hours)
                for article in cached_articles:
                    try:
                        published_str = article.get("published_at")
                        if published_str:
                            published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                            if published.tzinfo is not None:
                                published = published.replace(tzinfo=None)
                            if published < cutoff:
                                continue
                        score = article.get("sentiment")
                        if isinstance(score, (int, float)):
                            total_score += float(score)
                            total_count += 1
                        else:
                            fallback = self._simple_sentiment_from_text(article.get("title", "") or "", article.get("summary", "") or "")
                            if fallback != 0.0:
                                total_score += fallback
                                total_count += 1
                        for ent in article.get("entities") or []:
                            text = f"{(ent.get('symbol') or '').upper()} {(ent.get('name') or '').upper()}"
                            if "USD" in text:
                                entities["USD"] += 1
                            if "EUR" in text:
                                entities["EUR"] += 1
                            if "GBP" in text:
                                entities["GBP"] += 1
                            if "JPY" in text:
                                entities["JPY"] += 1
                            if "GOLD" in text or "XAU" in text:
                                entities["XAU"] += 1
                        ts = f"{article.get('title','')} {article.get('summary','')}".upper()
                        if any(tok in ts for tok in ("USD", "DOLLAR")):
                            entities["USD"] += 1
                        if "EUR" in ts:
                            entities["EUR"] += 1
                        if "GBP" in ts or "STERLING" in ts:
                            entities["GBP"] += 1
                        if "JPY" in ts or "YEN" in ts:
                            entities["JPY"] += 1
                        if "GOLD" in ts or "XAU" in ts:
                            entities["XAU"] += 1
                        articles_used += 1
                    except Exception:
                        continue

            avg = (total_score / max(1, total_count)) if total_count else 0.0
            snapshot = {
                "status": "cached" if articles_used > 0 else "no-data",
                "avg_score": avg,
                "count": total_count,
                "entities": entities,
                "articles_analyzed": articles_used,
                "window_minutes": window_minutes,
            }
            self.last_sentiment = snapshot
            self.last_sentiment_time = now
            
            logger.info(f"Sentiment calculated from {articles_used} cached articles (window: {window_minutes}min)")
            return snapshot
        except Exception as exc:
            logger.warning(f"Sentiment calculation failed: {exc}")
            return None

    def fetch_dense_sentiment(self,
                              rounds: int = 4,
                              batch_size: int = 25,
                              window_minutes: int = 120,
                              batch_interval_minutes: int = 30,
                              force_api: bool = True) -> Optional[Dict[str, Any]]:
        """
        Dense fetch orchestrator:
        - Executes multiple staggered fetches within the target window to increase signal density.
        - Merges results into the cache (deduplicated) and recomputes sentiment for the window.
        Returns the latest sentiment snapshot for the window.
        """
        now = datetime.utcnow()
        for i in range(max(1, rounds)):
            after = now - timedelta(minutes=i * batch_interval_minutes)
            # Expand the age window a bit for each batch to ensure coverage
            max_age_hours = max(1, int(window_minutes / 60)) + 1
            try:
                self.fetch_latest_articles(limit=batch_size, max_age_hours=max_age_hours,
                                           force_api=force_api,
                                           explicit_published_after=after)
            except Exception:
                # best-effort: continue to next batch
                pass
        # After all batches, recompute sentiment for the full window
        return self.fetch_sentiment(window_minutes=window_minutes)

