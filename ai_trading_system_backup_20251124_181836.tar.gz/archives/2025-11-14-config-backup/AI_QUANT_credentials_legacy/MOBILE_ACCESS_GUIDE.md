# 📱 MOBILE & MULTI-DEVICE ACCESS GUIDE

**Updated:** October 21, 2025  
**Your Trading System:** AI Quant Trading System  
**GitHub Repo:** AI_QUANT (fxgdesigns1@gmail.com)

---

## 🌍 ACCESS FROM ANYWHERE

### ✅ What's Set Up:

1. **Google Drive Sync** - All credentials sync across devices
2. **Google Cloud Secret Manager** - Secure cloud credential storage  
3. **SSH Access** - Direct server access from anywhere
4. **Web Dashboard** - Browser-based monitoring

---

## 📍 WHERE EVERYTHING IS STORED

### 1. Google Drive (Auto-Syncs)
```
Location: Google Drive > AI Trading > Gits > AI_QUANT_credentials
```

**Files Here:**
- `COMPLETE_CREDENTIALS_ALL.json` - All API keys
- `COMPLETE_CREDENTIALS_READABLE.txt` - Human-readable
- `accounts.yaml` - OANDA account config
- `UPLOAD_ALL_SECRETS.sh` - Upload to Secret Manager
- `MOBILE_ACCESS_GUIDE.md` - This file

**Access:**
- **Desktop:** Automatic via Google Drive File Stream
- **Mobile:** Google Drive app
- **Web:** https://drive.google.com → AI Trading/Gits/AI_QUANT_credentials

### 2. Google Cloud Secret Manager (Secure Cloud)
```
Project: YOUR_PROJECT_ID
Console: https://console.cloud.google.com/security/secret-manager
```

**28 Secrets Stored:**
- OANDA API keys & accounts
- Telegram bot credentials  
- SSH access info
- All news API keys (18 keys)
- Flask secrets

---

## 🚀 QUICK START - NEW DEVICE

### On ANY Device (Mac, Linux, Mobile Terminal):

#### Step 1: Get Google Cloud SDK
```bash
# Mac/Linux
curl https://sdk.cloud.google.com | bash

# Or download from:
# https://cloud.google.com/sdk/docs/install
```

#### Step 2: Authenticate
```bash
gcloud auth login
gcloud auth application-default login
```

#### Step 3: Set Your Project
```bash
export GOOGLE_CLOUD_PROJECT="your-project-id"
```

#### Step 4: Access Any Credential
```bash
# Get OANDA API key
gcloud secrets versions access latest --secret=oanda-api-key

# Get Telegram token  
gcloud secrets versions access latest --secret=telegram-bot-token

# Get SSH connection
gcloud secrets versions access latest --secret=ssh-connection-string
```

---

## 📱 MOBILE ACCESS (iOS/Android)

### Option 1: Web Dashboard (Easiest)
```
Your Trading Dashboard: http://13.50.52.91:8080

Features:
- View all accounts
- See live trades
- Check P&L
- Monitor signals
```

**Access from mobile browser:**
1. Open browser on phone
2. Go to: `http://13.50.52.91:8080`
3. Bookmark for quick access

### Option 2: Termux (Android) or iSH (iOS)

**Android (Termux):**
```bash
# Install Termux from F-Droid
pkg install python git openssh
pkg install google-cloud-sdk

# Clone and run
git clone https://github.com/YOUR_USERNAME/AI_QUANT.git
cd AI_QUANT
python main.py
```

**iOS (iSH Shell):**
```bash
# Install iSH from App Store
apk add python3 py3-pip git openssh

# Clone and run
git clone https://github.com/YOUR_USERNAME/AI_QUANT.git
cd AI_QUANT
python3 main.py
```

### Option 3: SSH to Server
```bash
# From any device with SSH
ssh -i ~/.ssh/n8n-key.pem ubuntu@13.50.52.91

# Once connected:
cd /path/to/trading/system
python3 main.py
```

---

## 💻 ACCESS FROM ANOTHER COMPUTER

### First Time Setup:

#### 1. Install Google Drive
```
Download: https://www.google.com/drive/download/
Sign in: fxgdesigns1@gmail.com
```

#### 2. Wait for Sync
```
Credentials will appear at:
~/Google Drive/My Drive/AI Trading/Gits/AI_QUANT_credentials/
```

#### 3. Clone GitHub Repo
```bash
git clone https://github.com/YOUR_USERNAME/AI_QUANT.git
cd AI_QUANT
```

#### 4. Link Credentials
```bash
# Create symlink to Google Drive credentials
ln -s "$HOME/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials/accounts.yaml" \
      google-cloud-trading-system/accounts.yaml
```

#### 5. Run System
```bash
cd google-cloud-trading-system
python3 main.py
```

---

## 🔑 UPLOAD CREDENTIALS TO SECRET MANAGER

**Only need to do this ONCE (from any device):**

```bash
cd ~/Google\ Drive/My\ Drive/AI\ Trading/Gits/AI_QUANT_credentials/
./UPLOAD_ALL_SECRETS.sh
```

This uploads all 28 secrets to Google Cloud.

---

## 🌐 WEB ACCESS LINKS

### Google Cloud Console
```
https://console.cloud.google.com/
```

**Pages You Need:**

1. **Secret Manager:**
   ```
   https://console.cloud.google.com/security/secret-manager
   ```
   View/edit all credentials

2. **Compute Engine (if using VM):**
   ```
   https://console.cloud.google.com/compute/instances
   ```
   Start/stop servers

3. **Cloud Storage:**
   ```
   https://console.cloud.google.com/storage
   ```
   Backup files

### Google Drive
```
https://drive.google.com/drive/folders/AI_Trading
```
Direct link to your synced credentials

### GitHub Repository
```
https://github.com/YOUR_USERNAME/AI_QUANT
```
Your code repository

### Trading Dashboard
```
http://13.50.52.91:8080
```
Live trading dashboard (if server running)

---

## 🔐 RETRIEVE CREDENTIALS ON NEW DEVICE

### Via gcloud CLI:
```bash
# Single credential
gcloud secrets versions access latest --secret=oanda-api-key

# All credentials (JSON)
gcloud secrets versions access latest \
  --secret=trading-system-complete-credentials > credentials.json
```

### Via Python (in your code):
```python
from src.core.secret_manager import get_credentials_manager

credentials = get_credentials_manager()
api_key = credentials.get('OANDA_API_KEY')
```

### Via Google Drive:
```bash
# Credentials auto-sync to all devices
cat ~/Google\ Drive/My\ Drive/AI\ Trading/Gits/AI_QUANT_credentials/COMPLETE_CREDENTIALS_READABLE.txt
```

---

## 🎯 COMMON TASKS FROM MOBILE

### Check System Status
```bash
ssh ubuntu@13.50.52.91
cd trading-system
tail -f logs/trading_system.log
```

### View Account Balance
```bash
# Via gcloud
gcloud secrets versions access latest --secret=oanda-api-key

# Then use OANDA mobile app
# Or access via web dashboard
```

### Get Live Signals
```bash
# Telegram notifications sent to your phone automatically
# Chat ID: 6100678501
# You'll get alerts for all trades
```

### Emergency Stop
```bash
ssh ubuntu@13.50.52.91
pkill -f "python3 main.py"
```

---

## 📊 MONITORING FROM MOBILE

### 1. Telegram Alerts (Auto)
- All trades → Your phone
- Chat ID: 6100678501
- No setup needed

### 2. Web Dashboard
- Open: http://13.50.52.91:8080
- Works on any mobile browser
- Real-time updates

### 3. OANDA Mobile App
- Download OANDA fxTrade app
- Login with your account
- See all positions live

---

## 🔧 TROUBLESHOOTING

### Can't Access Credentials?
```bash
# Re-authenticate
gcloud auth login
gcloud auth application-default login
```

### Google Drive Not Syncing?
```bash
# Check sync status
ls -la ~/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My\ Drive/AI\ Trading/

# Force sync (restart Google Drive app)
```

### Forgot Project ID?
```bash
# List your projects
gcloud projects list

# Set active project
gcloud config set project YOUR_PROJECT_ID
```

---

## 📱 RECOMMENDED MOBILE APPS

### Essential:
- **Google Drive** - Access credentials
- **Telegram** - Get trade alerts  
- **OANDA fxTrade** - Monitor accounts
- **Termux (Android)** or **iSH (iOS)** - Terminal access

### Optional:
- **GitHub Mobile** - View/edit code
- **Google Cloud Console** - Manage cloud resources

---

## 🎯 QUICK REFERENCE CARD

```
═══════════════════════════════════════════════════════
📱 MOBILE QUICK ACCESS
═══════════════════════════════════════════════════════

Credentials (Google Drive):
https://drive.google.com → AI Trading/Gits/AI_QUANT_credentials

Credentials (Secret Manager):
https://console.cloud.google.com/security/secret-manager

Trading Dashboard:
http://13.50.52.91:8080

SSH Access:
ssh -i ~/.ssh/n8n-key.pem ubuntu@13.50.52.91

Get API Key:
gcloud secrets versions access latest --secret=oanda-api-key

Telegram Alerts:
Automatic to Chat ID: 6100678501

═══════════════════════════════════════════════════════
```

---

## ✅ CHECKLIST - NEW DEVICE SETUP

- [ ] Install Google Drive (auto-sync credentials)
- [ ] Install Google Cloud SDK (`gcloud`)
- [ ] Authenticate: `gcloud auth login`
- [ ] Set project: `export GOOGLE_CLOUD_PROJECT=YOUR_ID`
- [ ] Test access: `gcloud secrets list`
- [ ] Install Telegram (get alerts)
- [ ] Bookmark dashboard: `http://13.50.52.91:8080`
- [ ] Clone GitHub repo (if coding)
- [ ] Link credentials via symlink
- [ ] Test run: `python3 main.py`

---

## 🚀 YOU'RE ALL SET!

**Everything is now accessible from:**
✅ Your Mac  
✅ Your mobile phone  
✅ Any other computer  
✅ Anywhere with internet

**Credentials are stored in:**
✅ Google Drive (syncs automatically)  
✅ Google Cloud Secret Manager (secure cloud)  
✅ Local backup (API_KEY_LOCATION.txt)

**No more lost credentials. Access from anywhere.** 🌍

---

**Questions?** Check the troubleshooting section above or view credentials directly from Google Drive on your phone.


