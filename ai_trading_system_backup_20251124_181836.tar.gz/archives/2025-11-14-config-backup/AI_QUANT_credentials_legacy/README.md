# 🔐 AI_QUANT Credentials Folder

## ⚠️ SECURITY WARNING
**This folder contains sensitive trading credentials. NEVER share these files!**

---

## 📂 What This Folder Is For

This Google Drive folder stores all sensitive credentials for your AI_QUANT trading system:

- **OANDA API keys** - Access to your trading accounts
- **Account IDs** - Your OANDA account identifiers
- **News API keys** - Market news feed credentials
- **Telegram credentials** - Bot notifications
- **Google Cloud credentials** - Cloud deployment keys

---

## 🔗 How It Works

### The Setup:
```
Your Computer                           This Google Drive Folder
─────────────────────────────────       ────────────────────────────────
AI_QUANT/                               AI_QUANT_credentials/
└── accounts.yaml (symlink) ──────────> └── accounts.yaml (actual file)
                                            ├── API keys
                                            ├── Account IDs
                                            └── Settings
```

### Benefits:
- ✅ **Synced** - Available on all your computers automatically
- ✅ **Secure** - Never committed to GitHub
- ✅ **Backed up** - Google Drive handles backups
- ✅ **Private** - Only you can access this folder

---

## 📝 Files You'll Create Here

### 1. accounts.yaml (REQUIRED)
Your main OANDA account configuration.

**How to create:**
```bash
# Copy template from the repository
cp ~/quant_system_clean/google-cloud-trading-system/accounts.yaml.template \
   "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials/accounts.yaml"

# Or run the setup script which does this automatically:
cd ~/quant_system_clean
./SETUP_AI_QUANT.sh
```

**What to include:**
```yaml
accounts:
  - id: "101-004-XXXXXXXX-XXX"        # Your OANDA account ID
    name: "My Demo Account"
    strategy: "adaptive_momentum"
    instruments:
      - EUR_USD
      - GBP_USD
      - XAU_USD
    risk_settings:
      max_risk_per_trade: 0.02
      max_portfolio_risk: 0.10
      max_positions: 5
    active: true

api:
  oanda:
    api_key: "YOUR-OANDA-API-KEY-HERE"
    account_id: "101-004-XXXXXXXX-XXX"
    environment: "practice"  # or "live"
```

**Where to get OANDA credentials:**
1. Sign up at https://www.oanda.com
2. Go to "Manage API Access"
3. Generate API token
4. Note your account ID

---

### 2. oanda_config.env (OPTIONAL)
Environment variables for OANDA API.

**Create:**
```env
OANDA_API_KEY=your-api-key-here
OANDA_ACCOUNT_ID=101-004-XXXXXXXX-XXX
OANDA_ENVIRONMENT=practice
```

---

### 3. news_api_config.env (OPTIONAL)
News and market data APIs.

**Create:**
```env
NEWS_API_KEY=your-news-api-key
MARKETAUX_API_KEY=your-marketaux-key
ALPHA_VANTAGE_KEY=your-alpha-vantage-key
```

**Where to get API keys:**
- NewsAPI: https://newsapi.org
- Marketaux: https://www.marketaux.com
- Alpha Vantage: https://www.alphavantage.co

---

### 4. telegram_config.env (OPTIONAL)
Telegram bot for trade notifications.

**Create:**
```env
TELEGRAM_BOT_TOKEN=7248728383:AAFpLNAlidybk7ed56bosfi8W_e1MaX7Oxs
TELEGRAM_CHAT_ID=6100678501
```

**How to get Telegram credentials:**
1. Message @BotFather on Telegram
2. Create a new bot: `/newbot`
3. Get your bot token
4. Get your chat ID: Message your bot, then visit:
   `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`

---

### 5. google_cloud_credentials.json (OPTIONAL)
Google Cloud Platform deployment credentials.

**How to get:**
1. Go to https://console.cloud.google.com
2. Create a new project
3. Enable required APIs
4. Create service account
5. Download JSON key
6. Save it in this folder

---

## 🚀 Initial Setup

### First Time Setup:

1. **Run the setup script** (it does everything automatically):
   ```bash
   cd ~/quant_system_clean
   ./SETUP_AI_QUANT.sh
   ```

2. **Edit accounts.yaml** in this folder:
   ```bash
   open "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials/accounts.yaml"
   ```

3. **Add your OANDA credentials** (replace all placeholders)

4. **Save and close** - Google Drive will sync automatically

5. **Test the connection:**
   ```bash
   cd ~/quant_system_clean/google-cloud-trading-system
   python3 src/main.py --test
   ```

---

## 🌍 Using on Multiple Computers

### On Your Mac:
Files sync automatically via Google Drive.

### On a New Computer:

1. **Install Google Drive for Desktop**
2. **Sign in** with fxgdesigns1@gmail.com
3. **Wait for sync** (this folder will download)
4. **Clone the repository:**
   ```bash
   git clone https://github.com/fxgdesigns1/AI_QUANT.git
   cd AI_QUANT
   ```
5. **Run setup script:**
   ```bash
   ./SETUP_AI_QUANT.sh
   ```
6. **Done!** Credentials are automatically linked

---

## 🔧 Troubleshooting

### "File not found" errors?

**Check if Google Drive is syncing:**
```bash
ls -la "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials/"
```

If empty, Google Drive might not be synced yet:
1. Open Google Drive app
2. Check sync status (icon in menu bar)
3. Make files "Available offline"

### "Symlink broken" errors?

**Recreate the symbolic link:**
```bash
cd ~/quant_system_clean
./SETUP_AI_QUANT.sh
```

### "Invalid credentials" when testing?

1. **Check accounts.yaml** - Make sure you replaced ALL placeholders
2. **Verify OANDA API key** - Log into OANDA and regenerate if needed
3. **Check account ID format** - Should be: `XXX-XXX-XXXXXXXX-XXX`
4. **Confirm environment** - `practice` for demo, `live` for real trading

---

## 📊 File Checklist

- [ ] `accounts.yaml` - Created and configured
- [ ] `oanda_config.env` - (Optional) Created
- [ ] `news_api_config.env` - (Optional) Created
- [ ] `telegram_config.env` - (Optional) Created
- [ ] `google_cloud_credentials.json` - (Optional) Created
- [ ] All placeholders replaced with real values
- [ ] Files syncing to Google Drive
- [ ] Symbolic links created in project
- [ ] Trading system tested and working

---

## 🔒 Security Best Practices

### ✅ DO:
- ✅ Use **strong passwords** for Google account
- ✅ Enable **2FA** on Google account
- ✅ Enable **2FA** on OANDA account
- ✅ Use **demo accounts** for testing
- ✅ Keep this folder **private** (don't share)
- ✅ Regularly **review** API key usage
- ✅ **Revoke** old API keys when not needed

### ❌ DON'T:
- ❌ NEVER share credentials in chat/email
- ❌ NEVER commit credentials to GitHub
- ❌ NEVER post credentials in screenshots
- ❌ NEVER use production credentials for testing
- ❌ NEVER share your Google Drive link
- ❌ NEVER disable security features

---

## 💾 Backup Strategy

### Automatic Backups:
- ✅ **Google Drive** - Continuous sync
- ✅ **Version History** - Google Drive keeps old versions

### Manual Backup (Optional):
```bash
# Create timestamped backup
DATE=$(date +%Y%m%d_%H%M%S)
cp -r "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials" \
      "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_backups/backup_$DATE"
```

### Recovering Old Versions:
1. Right-click file in Google Drive
2. "Version history"
3. Select previous version
4. "Restore"

---

## 🎯 Quick Commands

### View this folder:
```bash
open "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials"
```

### Edit accounts:
```bash
nano "/Users/mac/Library/CloudStorage/GoogleDrive-fxgdesigns1@gmail.com/My Drive/AI Trading/Gits/AI_QUANT_credentials/accounts.yaml"
```

### Test configuration:
```bash
cd ~/quant_system_clean/google-cloud-trading-system
python3 src/main.py --test
```

### Check symlink:
```bash
ls -la ~/quant_system_clean/google-cloud-trading-system/accounts.yaml
```

---

## 📚 More Documentation

See the main repository for complete documentation:
- `AI_QUANT_README.md` - Quick start guide
- `CREDENTIALS_SETUP.md` - Complete credentials documentation
- `SETUP_GUIDE.md` - Technical setup instructions
- `README.md` - Project overview

---

## 📞 Support

**Repository:** https://github.com/fxgdesigns1/AI_QUANT  
**Documentation:** See files above  
**Issues:** Open an issue on GitHub

---

## ✨ Summary

**This folder:**
- 📂 Stores your credentials securely
- ☁️ Syncs across all your devices
- 🔒 Never appears in GitHub
- 💾 Backed up automatically
- 🔗 Linked to your project

**Your credentials are safe and accessible!** 🎉

---

**Last Updated:** October 21, 2025  
**Repository:** AI_QUANT  
**Owner:** fxgdesigns1@gmail.com

