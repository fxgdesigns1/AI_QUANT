#!/usr/bin/env python3
import os
import time
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional

import requests

logger = logging.getLogger(__name__)


class NewsEvent:
    def __init__(self, time_utc: datetime, country: str, title: str, impact: str, currency: str, forecast: Optional[float], actual: Optional[float]):
        self.time_utc = time_utc
        self.country = country
        self.title = title
        self.impact = impact  # e.g., high/medium/low
        self.currency = currency
        self.forecast = forecast
        self.actual = actual


class NewsManager:
    """
    Fetches economic calendars from TradingEconomics and Finnhub and provides
    a simple interface for event halts and surprise scoring.
    Only activates if API keys are available; otherwise, becomes a no-op.
    """

    def __init__(self) -> None:
        self.tradingeconomics_key = os.getenv("TRADINGECONOMICS_KEY", "")
        self.finnhub_key = os.getenv("FINNHUB_KEY", "")
        self.marketaux_keys = self._load_marketaux_keys()
        self.marketaux_key = self.marketaux_keys[0] if self.marketaux_keys else ""
        self._marketaux_index = 0
        self.newsapi_key = os.getenv("NEWSAPI_KEY", "")      # reserved for sentiment (phase 2)
        self.cached_events: List[NewsEvent] = []
        self.last_refresh: Optional[datetime] = None
        self.last_sentiment: Optional[Dict[str, Any]] = None
        self.last_sentiment_time: Optional[datetime] = None
        self.sentiment_cache_ttl = max(1, int(os.getenv("MARKETAUX_CACHE_TTL_MINUTES", "2")))
        self.marketaux_snapshot_path = Path(
            os.getenv("MARKETAUX_STATUS_PATH", "/opt/quant_system_clean/runtime/marketaux_usage.json")
        )
        self.marketaux_stats: Dict[str, Dict[str, Any]] = {}
        self.marketaux_alerts: List[Dict[str, Any]] = []
        self._initialize_marketaux_stats()

    def _load_marketaux_keys(self) -> List[str]:
        keys_env = os.getenv("MARKETAUX_KEYS", "")
        keys: List[str] = []
        if keys_env:
            for part in keys_env.replace(';', ',').split(','):
                token = part.strip()
                if token:
                    keys.append(token)
        single = os.getenv("MARKETAUX_KEY", "").strip()
        if single and single not in keys:
            keys.append(single)
        return keys

    def _initialize_marketaux_stats(self) -> None:
        """Ensure marketaux stats structure matches active keys."""
        active_keys = set(self.marketaux_keys)
        for stale_key in list(self.marketaux_stats.keys()):
            if stale_key not in active_keys:
                self.marketaux_stats.pop(stale_key, None)
        for key in self.marketaux_keys:
            if key not in self.marketaux_stats:
                self.marketaux_stats[key] = {
                    "last_status": "unused",
                    "last_status_code": None,
                    "last_message": "",
                    "last_used": None,
                    "success_count": 0,
                    "error_count": 0,
                    "total_calls": 0,
                    "last_data_count": 0,
                    "usage_limit": False,
                    "throttled": False,
                    "notified_usage_limit": False,
                }
        self._write_marketaux_snapshot()

    def _next_marketaux_key(self) -> Optional[str]:
        if not self.marketaux_keys:
            return None
        key = self.marketaux_keys[self._marketaux_index]
        self._marketaux_index = (self._marketaux_index + 1) % len(self.marketaux_keys)
        self.marketaux_key = key
        return key

    @staticmethod
    def _mask_key(key: str) -> str:
        if len(key) <= 8:
            return key
        return f"{key[:4]}…{key[-4:]}"

    @staticmethod
    def _detail_to_str(detail: Any) -> str:
        if detail is None:
            return ""
        if isinstance(detail, (dict, list)):
            try:
                return json.dumps(detail, ensure_ascii=False)
            except Exception:
                return str(detail)
        return str(detail)

    def _record_marketaux_usage(self, key: str, status_code: Optional[int], message: str, data_count: int) -> None:
        stats = self.marketaux_stats.setdefault(
            key,
            {
                "last_status": "unused",
                "last_status_code": None,
                "last_message": "",
                "last_used": None,
                "success_count": 0,
                "error_count": 0,
                "total_calls": 0,
                "last_data_count": 0,
                "usage_limit": False,
                "throttled": False,
                "notified_usage_limit": False,
            },
        )

        stats["total_calls"] += 1
        stats["last_used"] = datetime.utcnow().isoformat()
        stats["last_status_code"] = status_code
        stats["last_message"] = message
        stats["last_data_count"] = data_count

        if status_code == 200:
            stats["last_status"] = "ok"
            stats["success_count"] += 1
            stats["usage_limit"] = False
            stats["throttled"] = False
            stats["notified_usage_limit"] = False
        elif status_code in (402, 403):
            stats["last_status"] = "usage_limit"
            stats["error_count"] += 1
            stats["usage_limit"] = True
            stats["throttled"] = False
            if not stats.get("notified_usage_limit"):
                self.marketaux_alerts.append(
                    {
                        "key": key,
                        "masked_key": self._mask_key(key),
                        "status": "usage_limit",
                        "status_code": status_code,
                        "message": message,
                        "timestamp": stats["last_used"],
                    }
                )
                stats["notified_usage_limit"] = True
        elif status_code == 429:
            stats["last_status"] = "throttled"
            stats["error_count"] += 1
            stats["usage_limit"] = False
            stats["throttled"] = True
            self.marketaux_alerts.append(
                {
                    "key": key,
                    "masked_key": self._mask_key(key),
                    "status": "throttled",
                    "status_code": status_code,
                    "message": message,
                    "timestamp": stats["last_used"],
                }
            )
        elif status_code is None:
            stats["last_status"] = "exception"
            stats["error_count"] += 1
        else:
            stats["last_status"] = "error"
            stats["error_count"] += 1

        self._write_marketaux_snapshot()

    def _write_marketaux_snapshot(self) -> None:
        try:
            payload = {
                "updated_at": datetime.utcnow().isoformat(),
                "keys": [],
            }
            for key, stats in self.marketaux_stats.items():
                payload["keys"].append(
                    {
                        "key": key,
                        "masked_key": self._mask_key(key),
                        "last_status": stats["last_status"],
                        "last_status_code": stats["last_status_code"],
                        "last_message": stats["last_message"],
                        "last_used": stats["last_used"],
                        "total_calls": stats["total_calls"],
                        "success_count": stats["success_count"],
                        "error_count": stats["error_count"],
                        "last_data_count": stats["last_data_count"],
                        "usage_limit": stats["usage_limit"],
                        "throttled": stats["throttled"],
                    }
                )

            snapshot_dir = self.marketaux_snapshot_path.parent
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = self.marketaux_snapshot_path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            tmp_path.replace(self.marketaux_snapshot_path)
        except Exception as exc:
            logger.warning(f"Marketaux snapshot write failed: {exc}")

    def get_marketaux_usage_summary(self, mask_keys: bool = True) -> List[Dict[str, Any]]:
        summary: List[Dict[str, Any]] = []
        for key, stats in self.marketaux_stats.items():
            summary.append(
                {
                    "key": key if not mask_keys else self._mask_key(key),
                    "raw_key": key,
                    "status": stats["last_status"],
                    "status_code": stats["last_status_code"],
                    "last_used": stats["last_used"],
                    "message": stats["last_message"],
                    "total_calls": stats["total_calls"],
                    "success_count": stats["success_count"],
                    "error_count": stats["error_count"],
                    "last_data_count": stats["last_data_count"],
                    "usage_limit": stats["usage_limit"],
                    "throttled": stats["throttled"],
                }
            )
        summary.sort(key=lambda item: item["raw_key"])
        return summary

    def pop_marketaux_alerts(self) -> List[Dict[str, Any]]:
        alerts = list(self.marketaux_alerts)
        self.marketaux_alerts.clear()
        return alerts

    def is_enabled(self) -> bool:
        return bool(self.tradingeconomics_key or self.finnhub_key)

    def refresh_calendar(self) -> None:
        try:
            events: List[NewsEvent] = []
            now = datetime.utcnow()
            start = (now - timedelta(hours=1)).strftime('%Y-%m-%d')
            end = (now + timedelta(days=1)).strftime('%Y-%m-%d')

            # TradingEconomics
            if self.tradingeconomics_key:
                try:
                    te_url = f"https://api.tradingeconomics.com/calendar?d1={start}&d2={end}&format=json&c={self.tradingeconomics_key}"
                    r = requests.get(te_url, timeout=10)
                    if r.status_code == 200:
                        for e in r.json():
                            try:
                                t = datetime.strptime(e.get('Date', ''), '%Y-%m-%dT%H:%M:%S')
                                impact = (e.get('Importance', '') or '').lower()
                                events.append(
                                    NewsEvent(
                                        time_utc=t,
                                        country=e.get('Country', ''),
                                        title=e.get('Event', ''),
                                        impact=impact,
                                        currency=e.get('Currency', ''),
                                        forecast=self._to_float(e.get('Forecast')),
                                        actual=self._to_float(e.get('Actual')),
                                    )
                                )
                            except Exception:
                                continue
                except Exception as ex:
                    logger.warning(f"TradingEconomics calendar failed: {ex}")

            # Finnhub
            if self.finnhub_key:
                try:
                    fh_url = f"https://finnhub.io/api/v1/calendar/economic?from={start}&to={end}&token={self.finnhub_key}"
                    r = requests.get(fh_url, timeout=10)
                    if r.status_code == 200:
                        data = r.json()
                        for e in data.get('economicCalendar', []):
                            try:
                                # Finnhub times are date strings with time; fallback noon UTC if missing
                                date_str = e.get('time', '') or f"{e.get('date','')} 12:00:00"
                                t = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                                impact = (e.get('impact', '') or '').lower()
                                events.append(
                                    NewsEvent(
                                        time_utc=t,
                                        country=e.get('country', ''),
                                        title=e.get('event', ''),
                                        impact=impact,
                                        currency=e.get('currency', ''),
                                        forecast=self._to_float(e.get('estimate')),
                                        actual=self._to_float(e.get('actual')),
                                    )
                                )
                            except Exception:
                                continue
                except Exception as ex:
                    logger.warning(f"Finnhub calendar failed: {ex}")

            # Cache
            self.cached_events = sorted(events, key=lambda x: x.time_utc)
            self.last_refresh = datetime.utcnow()
        except Exception as e:
            logger.warning(f"Calendar refresh error: {e}")

    def get_upcoming_high_impact(self, within_minutes: int = 60) -> List[NewsEvent]:
        if not self.last_refresh or (datetime.utcnow() - self.last_refresh) > timedelta(minutes=10):
            self.refresh_calendar()
        now = datetime.utcnow()
        horizon = now + timedelta(minutes=within_minutes)
        return [e for e in self.cached_events if e.time_utc >= now and e.time_utc <= horizon and ('high' in e.impact or 'importance:high' in e.impact)]

    def surprise_score(self, event: NewsEvent) -> Optional[float]:
        if event.actual is None or event.forecast is None:
            return None
        try:
            # simple normalized surprise
            denom = max(1e-9, abs(event.forecast))
            return (event.actual - event.forecast) / denom
        except Exception:
            return None

    def fetch_sentiment(self, window_minutes: int = 10) -> Optional[Dict[str, Any]]:
        """Aggregate sentiment over a short window using Marketaux and NewsAPI.
        Returns dict with avg_score, count, entity_hits per currency.
        """
        try:
            now = datetime.utcnow()
            ttl_minutes = max(1, self.sentiment_cache_ttl)
            if self.last_sentiment and self.last_sentiment_time and (now - self.last_sentiment_time) < timedelta(minutes=ttl_minutes):
                return self.last_sentiment

            since = (now - timedelta(minutes=window_minutes)).strftime('%Y-%m-%dT%H:%M:%S')
            total_score = 0.0
            total_count = 0
            entities: Dict[str, int] = { 'USD': 0, 'EUR': 0, 'GBP': 0, 'JPY': 0, 'XAU': 0 }

            # Marketaux
            if self.marketaux_keys:
                attempts = len(self.marketaux_keys)
                for _ in range(attempts):
                    key = self._next_marketaux_key()
                    if not key:
                        break
                    try:
                        q = 'forex OR fx OR currency OR gold OR xau'
                        url = f"https://api.marketaux.com/v1/news/all?filter_entities=true&limit=5&published_after={since}&language=en&api_token={key}&query={q}"
                        r = requests.get(url, timeout=10)
                        if r.status_code == 200:
                            data = r.json().get('data', [])
                            for item in data:
                                s = item.get('sentiment_score')
                                if isinstance(s, (int, float)):
                                    total_score += float(s)
                                    total_count += 1
                                for ent in (item.get('entities') or []):
                                    sym = (ent.get('symbol') or '').upper()
                                    name = (ent.get('name') or '').upper()
                                    text = f"{sym} {name}"
                                    if 'USD' in text:
                                        entities['USD'] += 1
                                    if 'EUR' in text:
                                        entities['EUR'] += 1
                                    if 'GBP' in text:
                                        entities['GBP'] += 1
                                    if 'JPY' in text:
                                        entities['JPY'] += 1
                                    if 'GOLD' in text or 'XAU' in text:
                                        entities['XAU'] += 1
                            self._record_marketaux_usage(key, 200, f"ok ({len(data)} articles)", len(data))
                            break
                        else:
                            try:
                                detail_raw = r.json()
                            except ValueError:
                                detail_raw = r.text
                            detail_str = self._detail_to_str(detail_raw)
                            self._record_marketaux_usage(key, r.status_code, detail_str, 0)
                            if r.status_code in {400, 401, 402, 403, 429, 500}:
                                logger.warning(f"Marketaux sentiment failed [{r.status_code}]: {detail_str}")
                                continue
                            logger.warning(f"Marketaux unexpected status {r.status_code}: {detail_str}")
                            break
                    except Exception as ex:
                        self._record_marketaux_usage(key, None, str(ex), 0)
                        logger.warning(f"Marketaux sentiment error: {ex}")
                        continue

            # NewsAPI (headline only sentiment proxy via polarity words – minimal)
            if self.newsapi_key:
                try:
                    url = f"https://newsapi.org/v2/everything?q=forex%20OR%20currency%20OR%20gold&language=en&from={since}&pageSize=25&apiKey={self.newsapi_key}"
                    r = requests.get(url, timeout=10)
                    if r.status_code == 200:
                        for art in r.json().get('articles', []):
                            title = (art.get('title') or '') + ' ' + (art.get('description') or '')
                            title_u = title.upper()
                            # crude polarity proxy
                            neg = sum(1 for w in ['PLUNGE','SLUMP','SURGE IN CPI','HAWKISH','CUTS GROWTH'] if w in title_u)
                            pos = sum(1 for w in ['BEAT','COOLING','DOVISH','RISE IN JOBS','EXPANDS'] if w in title_u)
                            score = (pos - neg) * 0.1
                            if score != 0:
                                total_score += score
                                total_count += 1
                            if 'USD' in title_u:
                                entities['USD'] += 1
                            if 'EUR' in title_u:
                                entities['EUR'] += 1
                            if 'GBP' in title_u:
                                entities['GBP'] += 1
                            if 'JPY' in title_u:
                                entities['JPY'] += 1
                            if 'GOLD' in title_u or 'XAU' in title_u:
                                entities['XAU'] += 1
                except Exception as ex:
                    logger.warning(f"NewsAPI fetch failed: {ex}")

            avg = (total_score / max(1, total_count)) if total_count else 0.0
            out = { 'avg_score': avg, 'count': total_count, 'entities': entities }
            self.last_sentiment = out
            self.last_sentiment_time = now
            return out
        except Exception as e:
            logger.warning(f"fetch_sentiment error: {e}")
            return None

    @staticmethod
    def _to_float(val: Any) -> Optional[float]:
        try:
            if val is None:
                return None
            return float(str(val).replace('%',''))
        except Exception:
            return None

    @staticmethod
    def impacted_instruments(currency: str) -> List[str]:
        mapping = {
            'USD': ['EUR_USD', 'GBP_USD', 'XAU_USD', 'USD_JPY'],
            'EUR': ['EUR_USD'],
            'GBP': ['GBP_USD'],
            'JPY': ['USD_JPY'],
        }
        return mapping.get(currency.upper(), [])


